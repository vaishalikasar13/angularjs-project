
if ($('#section-menu-btn').length > 0) {
  $('.section-top').on('click', '#section-menu-btn', function () {
    if ($(this).hasClass('opened')) {
      $(this).removeClass('opened').html('<i class="menu-icon fa fa-shopping-cart"></i> products');
      $('#section-menu-wrap').fadeOut(200);
      $('.section-menu-overlay').fadeOut(200).remove();
    } else {
      $(this).addClass('opened').width($(this).width()).text('Close');
      $('#section-menu-wrap').fadeIn(200);
      $('body').append('<div class="section-menu-overlay"></div>');
      $('.section-menu-overlay').fadeIn(200);

      $('body').on('click', '.section-menu-overlay', function () {
        $('#section-menu-btn').removeClass('opened').html('<i class="menu-icon fa fa-shopping-cart"></i> products');
        $('#section-menu-wrap').fadeOut(200);
        $('.section-menu-overlay').fadeOut(200).remove();
        return false;
      });
    }
    return false;
  });
}


$(document).ready(function(){

  $('.add_cart').click(function() {

  if($("input:radio[name='flavours']").is(":checked")) {
     var product_flavour = $("input[name='flavours']:checked").val();
     var product_flavour_name = $("input[name='flavours']:checked").data("name");
     $.ajax({
        url:base_url+"shoping_cart/add",
        method: "POST",
        data:{
          product_id: $(this).data("productid"),
          product_name:$(this).data("productname"),
          product_price:$(this).data("price"),
          quantity:1,
          product_image:$(this).data("image"),
          product_flavour: product_flavour,
          product_flavour_name:  product_flavour_name
        },
        success:function (data) {
         document.getElementById("notify").innerHTML='Product Added into the cart';
          var x = document.getElementById("notify");
            x.className = "show";
            setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
              $("#added-cart").css("display", "inline-block");
             $(".add_cart").css("display", "none");
              $( "#cart-count" ).text(data);
             }

       });
 }    else { 
  $(".select-flavours").addClass("select-flavour-error");
  $(".validation").css("display", "block");
 }

});


$(document).on('click', '#remove_cart_product', function() {

    var row_id = $(this).data("cart_row");
    if (confirm("Are you sure you want to remove this product?"))
    {
      data={
       row_id:row_id
     },
     console.log(data);
      $.ajax({
        url:base_url+"shoping_cart/remove",
         method: "POST",
         data:data,
         dataType:"JSON",
        success:function (data) {
            // alert("Product Removed From Cart");
             // document.getElementById('counthead').innerHTML=data;
             location.reload();
             
           }

         });


    }else{
      return false;
    }
    
  });


  $(document).on('click', '#clear_cart', function() {

    if (confirm("Are you sure.You want clear cart?"))
    {

      $.ajax({
        url:base_url+"shoping_cart/clear",

        success:function (data) {

          window.location.href=base_url+'home';

        }

      });


    }else{
      return false;
    }
    
  });

});
function valueChanged(current_tag) {
  this.updateCart(current_tag);
}

function updateCartModal(type,thisElement)
{
  var cart_id      = $(thisElement).data('cart_row');
   var cart_flavour = $(thisElement).data('cart_flavour');
   var cart_qty     = $(thisElement).data('cart_qty');
   var cart_prd_id = $(thisElement).data('cart_prd_id');
  var title        = '';
   var type_title   = '';
   clearData();
   switch(type)
   {
    case 'flavour':
                $('#modal-title').html('Change Flavour');
                  type_title = "Flavour";
                   $('#change-flavour').css('display','block');
                   $('#change-qty').css('display','none');
                   getProdFlavours(cart_prd_id,cart_flavour);
                  break;
    case 'qty':
              $('#modal-title').html('Change Quantity');
                  type_title = "qty";
                   $('#change-qty').css('display','block');
                   $('#change-flavour').css('display','none');
                    getQty(cart_qty);
                  break;
    default:
                  type_title='';
                  break;
   }
   title = 'Update '+type_title;
   $('.update-cart-title').html(title);
   $('#cart_type').val(type);
   $('#cart_id').val(cart_id);
   $('#cart_flavour').val(cart_flavour);
   $('#cart_qty').val(cart_qty);
}
function clearData()
{
   $('#cart_type').val();
   $('#cart_id').val();
   $('#cart_flavour').val();
   $('#cart_qty').val();
  return true;
}
// $('#cart_flavour,#cart_qty').change(function(){
//   updateCart();
// });

function updateCart(current_tag) 
{
   
   var cart_type     = $('#cart_type').val();
   var cart_id       = $('#cart_id').val();
   var cart_flavour  = '';
   var cart_qty      = '';
   var cart_flavour_name = '';
   var cart_flavour_name = '';
  switch(cart_type)
   {
    case 'flavour':
                  cart_flavour  = $(current_tag).data("id");
                  cart_flavour_name  = $(current_tag).data("name");
                  break;
    case 'qty':
                 
                  cart_qty      =  $(current_tag).data("qty");
                  break;
    default:
                  cart_flavour='';
                  cart_qty='';
                  break;
   }
   var cart_flavour  = cart_flavour;
   var cart_qty      = cart_qty;
 data={
       cart_type:cart_type,
       cart_id:cart_id,
       cart_flavour:cart_flavour,
       cart_flavour_name:cart_flavour_name,
       cart_qty:cart_qty
   
     },
     console.log(data);
   $.ajax({
      url:base_url+"shoping_cart/updateCart",
     method: "POST",
     data:data,
     dataType:"JSON",
     success:function (data) {
     $('.close_modal').click();
       location.reload();
        
      }

    });
 }

function placeOrder(argument)
 {
 var prs_id = document.getElementById('prs_id').value; 
 if(prs_id=='')
 {
  window.location.href=base_url+'login';
 }
 else
 {
 window.location.href=base_url+'user-address';
 }
}
function flavourSelected(current_tag) {
 window.location.href= base_url+'product-detail/'+ $( "#product_slug" ).val()+'/'+ $(current_tag).data("slug");
 //  var product_flavour = $("input[name='flavours']:checked").val();
 // $( "#product_flavour_name" ).val(value );
 //   this.loadZoomImg(product_flavour);
 //  this.loadSmallImg(product_flavour);
}
function getProdFlavours(prd_id,flavour)
{
    data={
       prd_id:prd_id,
       flavour: flavour
     },
    $.ajax({
          url:base_url+"product/getProdFlavoursById",
         method: "POST",
         data:data,
         dataType:"JSON",
         success:function (data) {
            $('#change-flavour').html('');
            $('#change-flavour').html(data);
          }

        });
}
function getQty(qty)
{
    data={
       qty:qty,
      },
    $.ajax({
          url:base_url+"product/getQuantity",
         method: "POST",
         data:data,
         dataType:"JSON",
         success:function (data) {
            $('#change-qty').html('');
            $('#change-qty').html(data);
          }

        });
}