var prs_id = $('#prs_id').val();
$("#person_update_form").validate(
    {
        errorClass: "errormesssage",
        rules:
        {
           prs_name: "required",
           prs_mob:
          {
              required: true,
                remote: {
                        url: base_url+'login/personContactValidation/mobile',
                        type: "post",
                        data: 
                        {
                          value:function()
                          {
                            return $('#prs_mob').val();
                          },
                          prs_id:function()
                          {
                            return $('#prs_id').val();
                          },
                        },
            },
          },
           prs_email:
          {
                remote: {
                        url: base_url+'login/personContactValidation/email',
                        type: "post",
                        data: 
                        {
                          value:function()
                          {
                            return $('#prs_email').val();
                          },
                           prs_id:function()
                          {
                            return $('#prs_id').val();
                          },
                        },
            },
          },
        },
        messages:
        {
             prs_mob: {
                  remote: function() { return $.validator.format("{0} is already taken", $("#prs_mob").val()); },
              },
              prs_email: {
                  remote: function() { return $.validator.format("{0} is already taken", $("#prs_email").val()); },
              },
        },
        submitHandler: function(form)
        {
          alert(document.getElementById('prs_dob').value);
            try
            {
                var prs_id = document.getElementById('prs_id').value;
                var prs_name = document.getElementById('prs_name').value;
                var prs_mob = document.getElementById('prs_mob').value;
                var prs_old_mob = document.getElementById('prs_old_mob').value;
             data = {
                    prs_id:prs_id,
                    prs_name: prs_name,
                    prs_mob: prs_mob,
                    prs_old_mob:prs_old_mob,
                    prs_location: document.getElementById('prs_location').value,
                    prs_bio: document.getElementById('prs_bio').value,
                    prs_dob: document.getElementById('prs_dob').value,
                    prs_gender: document.getElementById('prs_gender').value,
                    ref:  document.getElementById('ref').value
                    }

              $.ajax(
                {
                    type: "POST",
                    url: base_url + "person/updatePerson",
                    data: data,
                    dataType: "json",
                    beforeSend: function()
                    {
                        //$("#login_form").html('<i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Connecting');
                    },
                    success: function(response)
                    {
                        if (response.success == true)
                        {
                               $("#btn-dave").html('<i class="fa fa-circle-o-notch fa-spin spinner"></i> Save');
                             $('#btn-dave').attr('disabled','disabled');
                              if(response.linkn != '')
                              {
                                window.location.href = response.linkn;
                              }
                              else
                              {
                                location.reload();
                              }
                        }
                        else
                        {
                              $("#btn-dave").html('Save');
                            $('#btn-dave').removeAttr('disabled','disabled');
                            alert(response.message);
                        }
                    }
                });
            }
            catch (e)
            {
                console.log(e);
            }
        }
    });
function clearData()
{
  $('#prs_id').val('');
  $('#prs_name').val('');
  $('#prs_username').val('');
  $('#prs_mob').val('');
  $('#prs_old_mob').val('');
  $('#prs_email').val('');
  return true;
}   
$('.user_update').click(function(){
  getUserData();
});
function getUserData()
{
  $.ajax(
    {
        type: "POST",
        url: base_url + "person/getUserData",
        dataType: "json",
        async:false,
        beforeSend: function()
        {
            //$("#login_form").html('<i class="fa fa-spinner fa-spin" style="font-size:18px"></i> Connecting');
        },
        success: function(response)
        {
          console.log(response);
          $('#prs_id').val(response.prs_id);
          $('#prs_name').val(response.prs_name);
          $('#prs_username').val(response.prs_username);
          $('#prs_mob').val(response.prs_mob);
          $('#prs_old_mob').val(response.prs_mob);
          $('#prs_email').val(response.prs_email);
        }
    });
}