$('.place-order').click(function(){
  place_order();
});

function place_order()
{
    try
     {

           var ord_deliver_address = $('#ord_address').val();
            var ord_shipping_charges = $('#ord_shipping_charges').val();
            var ord_payment_mode = $('input[name="ord_payment_mode"]:checked').val();
            data={
              ord_deliver_address:ord_deliver_address,
              ord_shipping_charges:ord_shipping_charges,
              ord_payment_mode:ord_payment_mode
            }
                $.ajax(
                {
                    type: "POST",
                    url: base_url + "order/place_order",
                    dataType: "json",
                    data:data,
                    beforeSend: function()
                {
                    $(".btn_save").html('<i class="fa fa-circle-o-notch fa-spin spinner"></i> Pay Now');
                    $('.btn_save').attr('disabled','disabled');
                },
                    success: function(response)
                    {
                        if (response.success == true)
                        {
                              $(".btn_save").html('Pay Now');
                          $('.btn_save').removeAttr('disabled','disabled');
                               window.location.href= response.linkn;
                        }
                        else
                        {
                          $(".btn_save").html('Pay Now');
                        $('.btn_save').removeAttr('disabled','disabled');
                            alert(response.message);
                        }
                    }
                });
            }
            catch (e)
            {
                console.log(e);
            }
}