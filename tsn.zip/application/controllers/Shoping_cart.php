<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shoping_cart extends CI_Controller {


			public function __construct()
	    {
	        parent::__construct();
	     
	        
	    }
	    
	    private function _set_headers() {
    header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' ); 
    header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i(worry)' ) . ' GMT' ); 
    header( 'Cache-Control: no-store, no-cache, must-revalidate' ); 
    header( 'Cache-Control: post-check=0, pre-check=0', false ); 
    header( 'Pragma: no-cache' );
}
	

	public function add($value='')
	{
		$this->load->library('cart');
		$name=ucfirst(url_title(convert_accented_characters($_POST['product_name']), ' ', TRUE));
		$data  = array(
			'id' => $_POST['product_id'],
			'name' => $name,
			'qty' => $_POST['quantity'],
			'price' => $_POST['product_price'],
			'image' => $_POST['product_image'],
			'flavour' => $_POST['product_flavour'],
			'flavour_name' => $_POST['product_flavour_name'],
		 );
		$this->cart->insert($data);
		echo $this->view();
	}
	public function updateCart()
	{
		$updateType = $this->input->post('cart_type');
		$success_msg = 'Cart';
		$cart_array = array();
		$cart_array['rowid']      = $this->input->post('cart_id');
		switch ($updateType) {
			case 'flavour':
					$cart_array['flavour']      = $this->input->post('cart_flavour');
					$cart_array['flavour_name'] = $this->input->post('cart_flavour_name');
					$success_msg = 'Flavour ';
				    break;
		    case 'qty':
					$cart_array['qty'] = $this->input->post('cart_qty');
					$cart_array['qty'] = $this->input->post('cart_qty');
					$success_msg = 'Qty ';
				    break;
		}
		$this->cart->update($cart_array);  
		echo json_encode(array('message'=>$success_msg.'Updated Successfully'));
	}
	public function load($value='')
	{
		
    
		echo $this->view();
	}

	public function remove($value='')
	{
		$this->load->library('cart');
		$row_id = $_POST['row_id'];

		$data  = array(
			'rowid' => $row_id,
			'qty' => 0
		 );
		$this->cart->update($data);
		
		echo json_encode(array('message'=>'Product removed Successfully from cart'));

	}

	public function clear($value='')
	{
		$this->load->library('cart');
		$this->cart->destroy();

		echo json_encode(array('message'=>'Cart cleared Successfully'));

	}

	public function view($value='')
	{
	$this->_set_headers();
		$this->load->library('cart');
	return count($this->cart->contents());
		

	}
	
}