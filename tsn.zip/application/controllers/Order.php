<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {
public function __construct()
	{
		parent::__construct();
		$this->load->model('person_model');
		$this->load->model('order_model');
		 $this->load->model('communication_model'); 
	}
	public function address_select()
	{
		$prs_id = $this->session->userdata(PROJECT_SESSION_ID);
		if(!$prs_id)
		{
			redirect('login','refresh');
		}
		$data['title']="TSN | Address Select";
		$data['person_address']=$this->person_model->getPersonAddress($prs_id);
		$data['default_address']=$this->person_model->getPersonDefaultAddress($prs_id);
		$this->load->view('address_select',$data);
	}
	public function selectAddress($value='')
	{
		$ord_adress_id = $this->input->post('ord_adress_id');
		$this->session->set_userdata('selected_address',$ord_adress_id);
		echo json_encode(array("success"=>true,'linkn'=>base_url().'order-review'));
		
	}
	public function order_review()
	{
		  $this->load->library('cart');
		  $cart_count = count($this->cart->contents());
		  $pad_id = $this->session->userdata('selected_address');
		  if($cart_count == '0' || $cart_count == '')
		  {
		  	redirect('home');
		  }
		  if($pad_id == '' )
		  {	
		  	redirect('address-select');
		  }
		$data['title']="TSN | Order Review";
		$data['shipping_address']=$this->person_model->getPersonAddressById($pad_id);
		 $this->load->view('order_review',$data);
	}
	public function place_order()
	{
		
		 $this->session->unset_userdata('order');
        $ord_reference_no         = $this->home_model->getNewCode(
                             		array(
                             	 		'column'	=> 'ord_reference_no',
                             	 		'table'		=> 'person_order',
                             	 		'type'		=> 'order_code',
                             	 		'where'		=> ''
                             		)
                             	);
        $addressData = $this->person_model->getPersonAddressById($this->input->post('ord_deliver_address'));
		$ord_id =$this->order_model->place_order($ord_reference_no, $addressData->pad_mobile);
		if($ord_id != '-1')
	    {
          $ord_payment_mode = $this->input->post('ord_payment_mode');

	      $success = true;
	      $message = 'Order Placed successfully';
	      $ord_encrypted_id = $this->url_encrypt->encrypt_openssl($ord_id);
	      $ord_reference_no_encrypted = $this->url_encrypt->encrypt_openssl($ord_reference_no);
	      // Destroy cart
	      $this->load->library('cart');
		  $this->cart->destroy();
	      // Destroy cart

	      if($ord_payment_mode == PAYMENT_TYPE_PAYTM)
          {
          	  $linkn    = base_url().'paytm/pay/'.$ord_encrypted_id;
          }else {
          	$receiver_data = array(
                    'email' => $this->session->userdata(PROJECT_SESSION_EMAIL),
                    'name' =>   $addressData->pad_name,
                    'mobile' =>   $addressData->pad_mobile,
                    'alt_mobile' =>    $addressData->pad_alt_phone
                    );
          	// $this->communication_model->communication('order_placed', $receiver_data,$this->order_model->getOrderDetail($ord_reference_no)); 
          	$this->order_model->sendOrderSuccessMail($ord_reference_no);
          $mail = $this->session->set_userdata('order','success');
		 $linkn = base_url('my-orders');
          }
	    }
	    else
	    {
	      $success = false;
	      $message = 'Oops !! Some error occured while placing order';
	      $linkn   = '';
	    }
		echo json_encode(array("success"=>$success,'message'=>$message,'linkn'=>$linkn));
	}
	public function order_summary($ord_reference_encrypted_id)
	{
		$data['title']="TSN | Order Summary";
	     $ord_reference_no = $this->url_encrypt->decrypt_openssl($ord_reference_encrypted_id);

		$data['order']=$this->order_model->getOrderData($ord_reference_no,'ord_reference_no');
		$data['order_address']=$this->person_model->getPersonAddressById($data['order']->ord_delivery_adddress);
		$data['order_products']=$this->order_model->getOrderProducts($data['order']->ord_id);
		$this->load->view('order_summary',$data);
	}
	public function getnewCode()
	{
		echo 'ord_reference_no :'.$ord_reference_no         = $this->home_model->getNewCode(
                             		array(
                             	 		'column'	=> 'ord_reference_no',
                             	 		'table'		=> 'person_order',
                             	 		'type'		=> 'order_code',
                             	 		'where'		=> ''
                             		)
                             	);
	}
	public function order_list()
	{
		$this->load->model('order_model');
		if($this->session->userdata('order')) {
			$data['order'] = $this->session->userdata('order');
		} else {
			$data['order'] = '';
		}
		$data['title']="TSN | Order History";
		$data['orders']=$this->order_model->getOrderListData();
		$data['orderProducts']=$this->order_model->getOrderAllProducts();
		// $data['orderProductStatus']=$this->order_model->getOrderAllProductsStatus();
		 $this->load->view('order_list',$data);
	}
		public function orderDetail($ord_reference_no)
	{
		$data['title']="TSN | order ".$ord_reference_no;
		$data['order']=$this->order_model->getOrderDetail($ord_reference_no);
		if(!empty($data['order'])) {
			$data['orderProducts']=$this->order_model->getOrderAllProducts($data['order']->ord_id);

		}
		
		 $this->load->view('order_detail',$data);
	}
	public function sendOrderSuccessMail($ord_reference_no)
	{
		$this->order_model->sendOrderSuccessMail($ord_reference_no);
	}
}
?>