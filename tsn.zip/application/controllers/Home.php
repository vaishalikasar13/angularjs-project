<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');		
		$this->load->model('home_model');		
		$this->load->model('person_model');
		require_once(APPPATH . "/config/mail_template.php");	
	}
	public function index()
	{
		$data['title']="TSN | Home";
		$data['products']=$this->product_model->getFeaturedProducts();
		$data['banner_images']=$this->home_model->getBannerImages(GALLERY_SET_BANNER);
		$this->load->view('home',$data);
	}
	public function about()
	{
		$data['title']="TSN | About";
		$this->load->view('about',$data);
	}
	public function privacyPolicy()
	{
		$data['title']="TSN | Privacy Policy";
		$this->load->view('privacy_policy',$data);
	}
		public function terms()
	{
		$data['title']="TSN | Terms & Conditions";
		$this->load->view('terms',$data);
	}
	public function callUs()
	{
		$data['title']="TSN | call us";
		$this->load->view('call_us',$data);
	}
		public function returnPolicy()
	{
		$data['title']="TSN | Return Policy";
		$this->load->view('return_policy',$data);
	}
	public function contact()
	{
		$data['title']="TSN | Contact";
		$this->load->view('contact',$data);
	}
	public function dashboard()
	{
		$prs_id = $this->session->userdata(PROJECT_SESSION_ID);
		if($prs_id == '')
		{
			redirect('login','refresh');
			exit();
		}
		$data['title']="TSN | Profile";
		$data['userData'] = $this->person_model->getUserDataById($prs_id);
		$this->load->view('dashboard',$data);
	}
		 public function contact_us_form()
  {
  	 // Admin Contact Us
      $adminEmaildata['contact_name']               = $this->input->post('contact_name');
      $adminEmaildata['contact_email']              = $this->input->post('contact_email');
      $adminEmaildata['contact_mob']                = $this->input->post('contact_mob');
      $adminEmaildata['contact_sub']                = $this->input->post('contact_sub');
      $adminEmaildata['contact_msg']                = $this->input->post('contact_msg');
      $adminEmaildata['email']                 = ADMIN_EMAIL_VALUE;
      $adminEmaildata['subject']               = ADMIN_SUBJECT;
      $adminEmaildata['message']               = '';
      $adminEmaildata['template']              = 'email_template/adminContactUs';
      $adminEmaildata['email_cc']              = '';
  	 // Admin Contact Us
       // User Contact Us
      $userEmaildata['email']                 = $adminEmaildata['contact_email'];
      $userEmaildata['subject']               = USER_SUBJECT;
      $userEmaildata['message']               = '';
      $userEmaildata['template']              = 'email_template/userContactUs';
      $userEmaildata['email_cc']              = '';
  	 // User Contact Us
      $admin_mail = $this->home_model->sendMail($adminEmaildata);
      $user_email = $this->home_model->sendMail($userEmaildata);
    if($admin_mail)
    {
      $success = true;
      $message = 'Thank you for contacting us, we will get back to you shortly';
      $linkn    = base_url('home');
    }
    else
    {
      $success = false;
      $message = 'Oops !! Some error occured';
      $linkn   = '';
    }
    echo json_encode(array('success'=>$success,'message'=>$message,'linkn'=>$linkn));
  }
  public function editProfile()
  {
  	$prs_id = $this->session->userdata(PROJECT_SESSION_ID);
		if($prs_id == '')
		{
			redirect('login','refresh');
			exit();
		} else {
		$data['ref']= base_url().'profile';
		if(isset($_SERVER['HTTP_REFERER']))
		{
			$data['ref']= $_SERVER['HTTP_REFERER'];
		}
		
		$data['title']="TSN | Profile Edit";
		$data['userData'] = $this->person_model->getUserDataById($prs_id);
		$this->load->view('edit_profile',$data);
		}

  }
}
