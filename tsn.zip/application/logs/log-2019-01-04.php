<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-04 19:00:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-04 19:00:30 --> Unable to connect to the database
ERROR - 2019-01-04 19:00:50 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-04 19:08:02 --> Paytm ::Request code-{"MID":"qUPMpN58490220623881","ORDER_ID":"ORD0001","CUST_ID":"1","INDUSTRY_TYPE_ID":"Retail109","CHANNEL_ID":"WEB","TXN_AMOUNT":"1600","CALLBACK_URL":"http:\/\/localhost\/tsn\/tsn\/paytm\/response","WEBSITE":"WEBPROD","MSISDN":"8828416999","EMAIL":"vkasar.videsh25@gmail.com","VERIFIED_BY":"EMAIL","IS_USER_VERIFIED":"YES"}checksum"L4jrIQ+VVD8QNLaGKbr4bVrdtfPfl67\/srCEx9oA9yMvib6K4ZSVNG9RoRJujm0o+nm6ZVefQSSGUgUUgqwJEJTtj\/PKcOYDxRF2luz3usk="Print IdORD0001
ERROR - 2019-01-04 19:08:04 --> Paytm ::Response code-{"ORDERID":"ORD0001","MID":"qUPMpN58490220623881","TXNAMOUNT":"1600.00","CURRENCY":"INR","STATUS":"TXN_FAILURE","RESPCODE":"330","RESPMSG":"Paytm checksum mismatch.","BANKTXNID":"","CHECKSUMHASH":"0a0SP7drz7SbuNNTitLhT0Y7K7Woh+rg8dQVyKg7TySXp9yO16UaGPlxYKz37GflXfoKA5w3tAF8ZTbjcmazNytZlHGQ89RaVVSTwaXUTdo="}checksum"0a0SP7drz7SbuNNTitLhT0Y7K7Woh+rg8dQVyKg7TySXp9yO16UaGPlxYKz37GflXfoKA5w3tAF8ZTbjcmazNytZlHGQ89RaVVSTwaXUTdo="ORDERID : ORD0001
ERROR - 2019-01-04 19:08:04 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 181
ERROR - 2019-01-04 19:08:04 --> payment failure through paytm >> null
