<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-19 14:24:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:24:41 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:23 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:31 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:36 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:40 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:48 --> Unable to connect to the database
ERROR - 2019-01-19 14:25:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-19 14:25:52 --> Unable to connect to the database
ERROR - 2019-01-19 15:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:03:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:04:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:04:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:04:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:04:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:05:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:06 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-19 15:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:05:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:05:12 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0073 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0073 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:05:12 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:05:12 --> CRIMINAL SUBJECTYour order #ORD0073 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0073 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:05:12 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:05:22 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 14:04:59 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkrF6-000oCi-Oa
</pre>The following SMTP error was encountered: 250 OK id=1gkrF6-000oCi-Oa
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:05:12 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=33?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432e98a4192@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432e98a41de&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432e98a41de
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0073 has
been confirmed.
 Amount: RS. 10
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c432e98a41de
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

&lt;!DOCTYPE html&gt;=0A&lt;html&gt;=0A&lt;head&gt;=0A &lt;style type=3D&quot;text/css&quot;&gt;=0A  body {=
=0A    color: #4d4d4d;=0A    font-family: Montserrat,sans-serif,Helvetica,A=
rial;=0A  }=0A=0A    .content {=0A      border: 1px solid #eaeaec;=0A    bo=
x-shadow: 0 0 4px rgba(40,44,63,.08);=0A    max-width: 640px;=0A        mar=
gin: 0 auto;=0A    }=0A    .header,.info {=0A      padding: 15px;=0A      b=
order-bottom: 2px solid #eaeaec;=0A    }=0A    h3 {=0A      font-size: 20px=
;=0A      font-weight: bold;=0A      margin: 5px 0 2px 0;=0A    }=0A    .li=
ne {=0A          border-bottom-width: 4px;=0A    border-bottom-color: rgb(2=
09, 50, 49);=0A    border-bottom-style: solid;=0A    line-height: 1.5;=0A  =
  display: inline-block;=0A    }=0A    p{=0A      margin: 10px 0;=0A      }=
=0A  &lt;/style&gt;=0A&lt;/head&gt;=0A&lt;body &gt;=0A&lt;div class=3D&quot;content&quot;&gt;=0A  &lt;div class=
=3D&quot;header&quot;&gt;=0A    &lt;img src=3D&quot;https://transformsportsnutrition.com/assets/=
images/logo.png&quot;&gt;=0A  &lt;/div&gt;  =0A  &lt;div class=3D&quot;info&quot;&gt;=0A  &lt;h3&gt;Order&lt;/h3&gt;=
=0A  &lt;h3 class=3D&quot;line&quot;&gt;Confirmed&lt;/h3&gt; =0A  &lt;div class=3D&quot;temp&quot;&gt;=0A    &lt;p&gt;H=
ey vaishali kasar,&lt;/p&gt;=0A    &lt;p&gt;Thank you for shopping at Transform Sports =
Nutrition.Your order ORD0073 has been confirmed.&lt;/p&gt;=0A    &lt;p&gt;Amount: &lt;stro=
ng&gt;RS. 10&lt;/strong&gt;&lt;/p&gt;=0A    &lt;p&gt;vaishali kasar&lt;/p&gt;=0A&lt;p&gt;E wing, 702 Mandaki=
ni  building rawalpada dahisar(East)&lt;/p&gt;=0A&lt;p&gt;298 last stop &lt;/p&gt;=0A&lt;p&gt;mumba=
i- 400068 &lt;/p&gt;&lt;/p&gt;=0A  &lt;/div&gt;=0A  &lt;/div&gt;=0A&lt;/div&gt;=0A&lt;/body&gt;=0A&lt;/html&gt;

--B_ALT_5c432e98a41de--</pre>
ERROR - 2019-01-19 15:05:22 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0073">View Order</></strong>
ERROR - 2019-01-19 15:05:22 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:05:22 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0073">View Order</></strong>
ERROR - 2019-01-19 15:05:22 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:05:22 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:05:22 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432ea2eff3c@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432ea2effa6&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432ea2effa6
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c432ea2effa6
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,&lt;br&gt;&lt;br&gt;=0A=09New order has been placed&lt;br&gt;=0A=09Link: &lt;strong&gt;&lt;a =
href=3D&quot;https://transformsportsnutrition.com/app/ordersORD0073&quot;&gt;View Order&lt;=
/&gt;&lt;/strong&gt;

--B_ALT_5c432ea2effa6--</pre>
ERROR - 2019-01-19 15:05:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:28 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:28 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:28 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:28 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:29 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:05:29 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 15:07:54 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0074 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0074 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:07:54 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:07:54 --> CRIMINAL SUBJECTYour order #ORD0074 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0074 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:07:54 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:08:04 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 14:07:39 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkrHg-000qtZ-Qq
</pre>The following SMTP error was encountered: 250 OK id=1gkrHg-000qtZ-Qq
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:07:54 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=34?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432f3ac6aaf@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432f3ac6ac5&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432f3ac6ac5
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0074 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c432f3ac6ac5
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

&lt;!DOCTYPE html&gt;=0A&lt;html&gt;=0A&lt;head&gt;=0A &lt;style type=3D&quot;text/css&quot;&gt;=0A  body {=
=0A    color: #4d4d4d;=0A    font-family: Montserrat,sans-serif,Helvetica,A=
rial;=0A  }=0A=0A    .content {=0A      border: 1px solid #eaeaec;=0A    bo=
x-shadow: 0 0 4px rgba(40,44,63,.08);=0A    max-width: 640px;=0A        mar=
gin: 0 auto;=0A    }=0A    .header,.info {=0A      padding: 15px;=0A      b=
order-bottom: 2px solid #eaeaec;=0A    }=0A    h3 {=0A      font-size: 20px=
;=0A      font-weight: bold;=0A      margin: 5px 0 2px 0;=0A    }=0A    .li=
ne {=0A          border-bottom-width: 4px;=0A    border-bottom-color: rgb(2=
09, 50, 49);=0A    border-bottom-style: solid;=0A    line-height: 1.5;=0A  =
  display: inline-block;=0A    }=0A    p{=0A      margin: 10px 0;=0A      }=
=0A  &lt;/style&gt;=0A&lt;/head&gt;=0A&lt;body &gt;=0A&lt;div class=3D&quot;content&quot;&gt;=0A  &lt;div class=
=3D&quot;header&quot;&gt;=0A    &lt;img src=3D&quot;https://transformsportsnutrition.com/assets/=
images/logo.png&quot;&gt;=0A  &lt;/div&gt;  =0A  &lt;div class=3D&quot;info&quot;&gt;=0A  &lt;h3&gt;Order&lt;/h3&gt;=
=0A  &lt;h3 class=3D&quot;line&quot;&gt;Confirmed&lt;/h3&gt; =0A  &lt;div class=3D&quot;temp&quot;&gt;=0A    &lt;p&gt;H=
ey vaishali kasar,&lt;/p&gt;=0A    &lt;p&gt;Thank you for shopping at Transform Sports =
Nutrition.Your order ORD0074 has been confirmed.&lt;/p&gt;=0A    &lt;p&gt;Amount: &lt;stro=
ng&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;=0A    &lt;p&gt;vaishali kasar&lt;/p&gt;=0A&lt;p&gt;E wing, 702 Mandakin=
i  building rawalpada dahisar(East)&lt;/p&gt;=0A&lt;p&gt;298 last stop &lt;/p&gt;=0A&lt;p&gt;mumbai=
- 400068 &lt;/p&gt;&lt;/p&gt;=0A  &lt;/div&gt;=0A  &lt;/div&gt;=0A&lt;/div&gt;=0A&lt;/body&gt;=0A&lt;/html&gt;

--B_ALT_5c432f3ac6ac5--</pre>
ERROR - 2019-01-19 15:08:04 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0074">View Order</></strong>
ERROR - 2019-01-19 15:08:04 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:08:04 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0074">View Order</></strong>
ERROR - 2019-01-19 15:08:04 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:08:04 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:08:04 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432f44ec54a@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432f44ec576&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432f44ec576
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c432f44ec576
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,&lt;br&gt;&lt;br&gt;=0A=09New order has been placed&lt;br&gt;=0A=09Link: &lt;strong&gt;&lt;a =
href=3D&quot;https://transformsportsnutrition.com/app/ordersORD0074&quot;&gt;View Order&lt;=
/&gt;&lt;/strong&gt;

--B_ALT_5c432f44ec576--</pre>
ERROR - 2019-01-19 15:08:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:07 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:07 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:07 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:07 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:08 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:08 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:08 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:08 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:09 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:09 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:09 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:09 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:11 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:11 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 15:08:46 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0075 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0075 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:08:46 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:08:46 --> CRIMINAL SUBJECTYour order #ORD0075 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0075 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:08:46 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:08:54 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 14:08:31 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkrIW-000rd9-HE
</pre>The following SMTP error was encountered: 250 OK id=1gkrIW-000rd9-HE
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:08:46 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=35?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432f6e9971d@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432f6e99730&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432f6e99730
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0075 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c432f6e99730
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0075 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c432f6e99730--</pre>
ERROR - 2019-01-19 15:08:54 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0075">View Order</></strong>
ERROR - 2019-01-19 15:08:54 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:08:54 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0075">View Order</></strong>
ERROR - 2019-01-19 15:08:54 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:08:54 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:08:54 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432f76959ec@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432f7695a45&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432f7695a45
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c432f7695a45
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0075=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c432f7695a45--</pre>
ERROR - 2019-01-19 15:08:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:08:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:09:00 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:09:00 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 15:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:10:41 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0076 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0076 has been confirmed.</p>
    <p>Amount: <strong>RS. 2150</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:10:41 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:10:41 --> CRIMINAL SUBJECTYour order #ORD0076 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0076 has been confirmed.</p>
    <p>Amount: <strong>RS. 2150</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:10:41 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:10:49 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 14:10:26 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkrKN-000ti6-DV
</pre>The following SMTP error was encountered: 250 OK id=1gkrKN-000ti6-DV
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:10:41 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=36?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432fe124130@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432fe12413f&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432fe12413f
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0076 has
been confirmed.
 Amount: RS. 2150
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c432fe12413f
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0076 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2150=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c432fe12413f--</pre>
ERROR - 2019-01-19 15:10:49 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0076">View Order</></strong>
ERROR - 2019-01-19 15:10:49 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:10:49 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0076">View Order</></strong>
ERROR - 2019-01-19 15:10:49 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:10:49 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:10:49 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c432fe9a3a3f@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c432fe9a3a99&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c432fe9a3a99
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c432fe9a3a99
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0076=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c432fe9a3a99--</pre>
ERROR - 2019-01-19 15:10:49 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:50 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:50 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:50 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:50 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:10:55 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 15:12:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 15:12:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:12:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 15:13:01 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0077 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0077 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:13:01 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:13:01 --> CRIMINAL SUBJECTYour order #ORD0077 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0077 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 15:13:01 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:13:10 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 14:12:47 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkrMe-000vVp-AZ
</pre>The following SMTP error was encountered: 250 OK id=1gkrMe-000vVp-AZ
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:13:01 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=37?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c43306dd81c0@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c43306dd8243&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c43306dd8243
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0077 has
been confirmed.
 Amount: RS. 10
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c43306dd8243
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0077 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 10=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c43306dd8243--</pre>
ERROR - 2019-01-19 15:13:10 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0077">View Order</></strong>
ERROR - 2019-01-19 15:13:10 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 15:13:10 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0077">View Order</></strong>
ERROR - 2019-01-19 15:13:10 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 15:13:10 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 15:13:10 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c43307669a68@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c43307669a78&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c43307669a78
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c43307669a78
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0077=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c43307669a78--</pre>
ERROR - 2019-01-19 15:13:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:10 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:11 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:11 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:11 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:11 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:12 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:12 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:12 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:12 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:13 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:13 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:13 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:13 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:14 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:14 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:14 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:14 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:15 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:15 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:15 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:15 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:16 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 15:13:16 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 21:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:51:50 --> Severity: error --> Exception: syntax error, unexpected '=' D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 17
ERROR - 2019-01-19 21:52:02 --> Severity: error --> Exception: syntax error, unexpected '=' D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 17
ERROR - 2019-01-19 21:52:18 --> Query error: Unknown column 'prd_menu' in 'where clause' - Invalid query: SELECT * FROM `product_category` where cat_status=1 and prd_menu=1  order by cat_order
ERROR - 2019-01-19 21:52:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:52:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:52:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:52:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:57:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:57:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 21:58:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:58:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:58:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 21:58:26 --> 404 Page Not Found: Shop/post-workout
ERROR - 2019-01-19 21:59:13 --> 404 Page Not Found: Shop/post-workout
ERROR - 2019-01-19 22:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:08:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:08:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:08:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:24 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 48
ERROR - 2019-01-19 22:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:42 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-19 22:09:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:09:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:09:50 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0078 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0078 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 22:09:50 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 22:09:50 --> CRIMINAL SUBJECTYour order #ORD0078 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0078 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-19 22:09:50 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 22:10:00 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 19 Jan 2019 21:09:37 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.45.214]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gkxs2-002rNz-C8
</pre>The following SMTP error was encountered: 250 OK id=1gkxs2-002rNz-C8
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 22:09:50 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=38?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c43921e299dc@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c43921e29ae2&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c43921e29ae2
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0078 has
been confirmed.
 Amount: RS. 10
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c43921e29ae2
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0078 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 10=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c43921e29ae2--</pre>
ERROR - 2019-01-19 22:10:01 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0078">View Order</></strong>
ERROR - 2019-01-19 22:10:01 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-19 22:10:01 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0078">View Order</></strong>
ERROR - 2019-01-19 22:10:01 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-19 22:10:01 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 19 Jan 2019 22:10:01 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c43922900f40@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c43922900f68&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c43922900f68
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c43922900f68
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0078=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c43922900f68--</pre>
ERROR - 2019-01-19 22:10:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:02 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:02 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:02 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:02 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:03 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:03 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:03 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:03 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:04 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:04 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:04 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:04 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:05 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:06 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:07 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-19 22:10:07 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-19 22:10:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:10:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:10:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-19 22:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-19 22:18:53 --> 404 Page Not Found: Shop/meal-replacement
