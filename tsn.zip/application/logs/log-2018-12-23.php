<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-23 19:31:52 --> Paytm ::Request code-{"MID":"qUPMpN58490220623881","ORDER_ID":"ORD0001","CUST_ID":"4","INDUSTRY_TYPE_ID":"Retail","CHANNEL_ID":"WEB","TXN_AMOUNT":"2000","CALLBACK_URL":"http:\/\/localhost\/tsn\/tsn\/paytm\/response","WEBSITE":"WEBSTAGING","MSISDN":"8655385802","EMAIL":"vaishalikasar13@gmail.com","VERIFIED_BY":"EMAIL","IS_USER_VERIFIED":"YES"}checksum"wHCr8aq7Z1KnfolpHq3zib9VFrOX4HbjjGe7e9PWy6R3MOOI+3oDQpVRRgbkwGergU4QIHXXuLgCwZ7iySocZyttkAD21zzvkG6Oe\/VSnss="Print IdORD0001
ERROR - 2018-12-23 19:31:54 --> Paytm ::Response code-{"ORDERID":"ORD0001","MID":"qUPMpN58490220623881","TXNID":"20181224111212800110168686750190941","TXNAMOUNT":"2000.00","CURRENCY":"INR","TXNDATE":"2018-12-24 00:01:47.0","STATUS":"PENDING","RESPCODE":"402","RESPMSG":"Looks like the payment is not complete. Please wait while we confirm the status with your bank","BANKTXNID":"","CHECKSUMHASH":"DUjWd0AR+vBL71Si5jYTzy9XcXfXdnOrrcnfNclOLiDSe4T0B3DcZfjMwcnUaVLoTjza3DSHEmSFWrdCwx+B4UCNerf\/gWUvgPmLMSrVA+k="}checksum"DUjWd0AR+vBL71Si5jYTzy9XcXfXdnOrrcnfNclOLiDSe4T0B3DcZfjMwcnUaVLoTjza3DSHEmSFWrdCwx+B4UCNerf\/gWUvgPmLMSrVA+k="ORDERID : ORD0001
ERROR - 2018-12-23 19:31:54 --> db_check_txn1 >> false
ERROR - 2018-12-23 19:31:54 --> Severity: Notice --> Undefined index: PAYMENTMODE D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 140
ERROR - 2018-12-23 19:31:54 --> Severity: Notice --> Undefined index: GATEWAYNAME D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 146
ERROR - 2018-12-23 19:31:54 --> Severity: Notice --> Undefined index: BANKNAME D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 148
ERROR - 2018-12-23 19:31:55 --> payment failure through paytm >> {"scontent1":{"PAYTM_PAY_RESPONSE_CODE":"402"},"scontent":{"PAYTM_PAY_STATUS":"PENDING"},"status":{"ORDERID":"ORD0001","MID":"qUPMpN58490220623881","TXNID":"20181224111212800110168686750190941","TXNAMOUNT":"2000.00","CURRENCY":"INR","TXNDATE":"2018-12-24 00:01:47.0","STATUS":"PENDING","RESPCODE":"402","RESPMSG":"Looks like the payment is not complete. Please wait while we confirm the status with your bank","BANKTXNID":"","CHECKSUMHASH":"DUjWd0AR+vBL71Si5jYTzy9XcXfXdnOrrcnfNclOLiDSe4T0B3DcZfjMwcnUaVLoTjza3DSHEmSFWrdCwx+B4UCNerf\/gWUvgPmLMSrVA+k="}}
ERROR - 2018-12-23 19:46:21 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0001 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-23 19:46:21 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-23 19:46:21 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-23 19:46:21 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-23 19:46:29 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 23 Dec 2018 18:46:15 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.164]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gb8lU-002veL-LA
</pre>The following SMTP error was encountered: 250 OK id=1gb8lU-002veL-LA
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 23 Dec 2018 19:46:21 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c1fd7fdc257b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c1fd7fdc25eb&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c1fd7fdc25eb
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001
has been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c1fd7fdc25eb
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0001 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c1fd7fdc25eb--</pre>
ERROR - 2018-12-23 19:47:25 --> Paytm ::Request code-{"MID":"UEyXxW16238925300179","ORDER_ID":"ORD0151","CUST_ID":"4","INDUSTRY_TYPE_ID":"Retail","CHANNEL_ID":"WEB","TXN_AMOUNT":"2000","CALLBACK_URL":"http:\/\/localhost\/tsn\/tsn\/paytm\/response","WEBSITE":"WEBSTAGING","MSISDN":"8655385802","EMAIL":"vaishalikasar13@gmail.com","VERIFIED_BY":"EMAIL","IS_USER_VERIFIED":"YES"}checksum"yzkOCuZ6JRERN\/wch4tVZEKVCpWob+lzgdmQZdBapXuwxWCYJcZ0GO6IIYIUadN6sYgudc0nQA643VpM7A7sSVGNvm1xwV1WmEq\/mRg0OCE="Print IdORD0151
ERROR - 2018-12-23 19:48:09 --> Paytm ::Response code-{"ORDERID":"ORD0151","MID":"UEyXxW16238925300179","TXNID":"20181224111212800110168189100133868","TXNAMOUNT":"2000.00","PAYMENTMODE":"PPI","CURRENCY":"INR","TXNDATE":"2018-12-24 00:17:21.0","STATUS":"TXN_SUCCESS","RESPCODE":"01","RESPMSG":"Txn Success","GATEWAYNAME":"WALLET","BANKTXNID":"5976804","BANKNAME":"WALLET","CHECKSUMHASH":"uVXIRd+AS9i1eRHoohdScNclDuHAyMZfpIlO24R\/MoTBwlOR8KLtKQdb11r0e16HG+TbnrGNMCmbfZbme2k2zb\/sArIM+d+5qC2B4UylAYM="}checksum"uVXIRd+AS9i1eRHoohdScNclDuHAyMZfpIlO24R\/MoTBwlOR8KLtKQdb11r0e16HG+TbnrGNMCmbfZbme2k2zb\/sArIM+d+5qC2B4UylAYM="ORDERID : ORD0151
ERROR - 2018-12-23 19:48:09 --> db_check_txn1 >> "5"
ERROR - 2018-12-23 19:48:09 --> payment success through paytm >> {"scontent1":{"PAYTM_PAY_RESPONSE_CODE":"01"},"scontent":{"PAYTM_PAY_STATUS":"TXN_SUCCESS"},"status":{"ORDERID":"ORD0151","MID":"UEyXxW16238925300179","TXNID":"20181224111212800110168189100133868","TXNAMOUNT":"2000.00","PAYMENTMODE":"PPI","CURRENCY":"INR","TXNDATE":"2018-12-24 00:17:21.0","STATUS":"TXN_SUCCESS","RESPCODE":"01","RESPMSG":"Txn Success","GATEWAYNAME":"WALLET","BANKTXNID":"5976804","BANKNAME":"WALLET","CHECKSUMHASH":"uVXIRd+AS9i1eRHoohdScNclDuHAyMZfpIlO24R\/MoTBwlOR8KLtKQdb11r0e16HG+TbnrGNMCmbfZbme2k2zb\/sArIM+d+5qC2B4UylAYM="},"message":"Success"}
ERROR - 2018-12-23 19:48:09 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0151 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-23 19:48:09 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-23 19:48:09 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0151 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-23 19:48:09 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-23 19:48:15 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 23 Dec 2018 18:48:02 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.164]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gb8nD-0032kK-1H
</pre>The following SMTP error was encountered: 250 OK id=1gb8nD-0032kK-1H
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 23 Dec 2018 19:48:09 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=31=35=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c1fd869343ec@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c1fd869343ff&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c1fd869343ff
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0151
has been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c1fd869343ff
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0151 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c1fd869343ff--</pre>
