ERROR - 2019-01-12 16:31:00 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0025 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 16:31:00 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 16:31:00 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : df
ERROR - 2019-01-12 16:31:00 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 16:31:01 --> error occured in people insert Communication_model/send_mail421 Too many concurrent SMTP connections; please try again later.
<br /><pre>hello: </pre>The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 16:31:00 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=32=35=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a0834ead0b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a0834ead57&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a0834ead57
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

df


--B_ALT_5c3a0834ead57
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

df

--B_ALT_5c3a0834ead57--</pre>
ERROR - 2019-01-12 19:59:52 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-12 19:59:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 19:59:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 19:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:00:02 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0001 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:00:02 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:00:02 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : df
ERROR - 2019-01-12 20:00:02 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:52 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-12 20:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:58 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0002 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:01:58 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:01:58 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 2 item (Order No.:  ORD0002)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0002"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:01:58 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:02:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:02:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:02:55 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-12 20:02:55 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-12 20:02:55 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-12 20:02:56 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-12 20:03:06 -->  check login ref = http://localhost/tsn/tsn/order-detail/ORD0002
ERROR - 2019-01-12 20:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:31 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0003 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:03:31 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:03:31 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 2 item (Order No.:  ORD0003)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0003"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:03:31 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:03:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:03:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:04:31 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0004 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:04:31 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:04:31 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0004 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:04:31 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:04:38 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:04:18 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giOZv-000tbZ-Gg
</pre>The following SMTP error was encountered: 250 OK id=1giOZv-000tbZ-Gg
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:04:31 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=34?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3a3fc5c1b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3a3fc5c58&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3a3fc5c58
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0004
has been confirmed.
 Amount: RS. 1600

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3a3fc5c58
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0004 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 1600=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3a3fc5c58--</pre>
ERROR - 2019-01-12 20:04:39 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0004 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:04:39 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:04:39 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 1 item (Order No.:  ORD0004)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0004"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:04:39 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:04:39 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:04:39 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=34=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3a4701304@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3a4701335&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3a4701335
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 1 item (Order No.:
ORD0004)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3a4701335
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 1 item (Order No.: ORD00=
04)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0004=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3a4701335--</pre>
ERROR - 2019-01-12 20:05:04 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0005 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:05:04 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:05:04 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0005 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:05:04 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:05:11 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:04:51 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giOaR-000twF-Q1
</pre>The following SMTP error was encountered: 250 OK id=1giOaR-000twF-Q1
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:05:04 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=35?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3a60e907b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3a60e9090&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3a60e9090
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0005
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3a60e9090
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0005 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3a60e9090--</pre>
ERROR - 2019-01-12 20:05:11 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0005 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:05:11 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:05:11 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0005)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0005"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:05:11 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:05:11 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:05:11 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=35=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3a673680c@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3a673681f&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3a673681f
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0005)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3a673681f
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
05)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0005=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3a673681f--</pre>
ERROR - 2019-01-12 20:12:34 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0006 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:12:34 --> Email configurations -- ssmtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:12:34 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0006 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:12:34 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"mail","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:12:35 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-12 20:12:35 --> error occured in people insert Communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:12:34 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3c2256387@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3c22563a3&quot;
=?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=36?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3c22563a3
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0006
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3c22563a3
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0006 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3c22563a3--</pre>
ERROR - 2019-01-12 20:12:35 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0006 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:12:35 --> Email configurations -- ssmtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:12:35 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0006)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0006"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:12:35 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"mail","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:12:36 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-12 20:12:36 --> error occured in people insert Communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:12:35 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3c23a6a96@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3c23a6abe&quot;
=?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=36=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3c23a6abe
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0006)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3c23a6abe
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
06)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0006=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3c23a6abe--</pre>
ERROR - 2019-01-12 20:13:27 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0007 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:13:27 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:13:27 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0007 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:13:27 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:13:35 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:13:14 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giOiZ-00101q-Ep
</pre>The following SMTP error was encountered: 250 OK id=1giOiZ-00101q-Ep
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:13:27 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=37?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3c577d150@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3c577d193&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3c577d193
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0007
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3c577d193
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0007 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3c577d193--</pre>
ERROR - 2019-01-12 20:13:35 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0007 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:13:35 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:13:35 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0007)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0007"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:13:35 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:13:35 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:13:35 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=37=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3c5f327ed@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3c5f3282a&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3c5f3282a
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0007)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3c5f3282a
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
07)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0007=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3c5f3282a--</pre>
ERROR - 2019-01-12 20:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:18:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:18:21 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0008 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:18:21 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:18:21 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0008 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:18:21 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:18:26 --> error occured in people insert Communication_model/send_mail<br /><pre>hello: </pre>The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:18:21 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=38?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3d7d6d6d1@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3d7d6d6ed&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3d7d6d6ed
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0008
has been confirmed.
 Amount: RS. 1600

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3d7d6d6ed
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0008 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 1600=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3d7d6d6ed--</pre>
ERROR - 2019-01-12 20:18:26 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0008 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:18:26 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:18:26 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 1 item (Order No.:  ORD0008)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0008"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:18:26 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:18:26 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:26 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:26 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:27 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:27 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:27 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:27 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:28 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:28 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:28 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:29 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:29 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:29 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:29 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:30 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:30 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:30 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:31 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:31 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:31 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:32 --> Severity: Notice --> fwrite(): send of 12 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:32 --> error occured in people insert Communication_model/send_mailUnable to send data: AUTH LOGIN
<br />Failed to send AUTH LOGIN command. Error: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:18:26 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=38=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3d827516b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3d8275179&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3d8275179
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 1 item (Order No.:
ORD0008)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3d8275179
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 1 item (Order No.: ORD00=
08)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0008=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3d8275179--</pre>
ERROR - 2019-01-12 20:18:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:18:38 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-12 20:23:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:23:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:23:38 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0009 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:23:38 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:23:38 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0009 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:23:38 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":456,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:23:43 --> Severity: Warning --> fsockopen(): unable to connect to mail.transformsportsnutrition.com:456 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-12 20:23:43 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 10060 A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:23:38 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=39?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3eba34cf8@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3eba34d0b&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3eba34d0b
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0009
has been confirmed.
 Amount: RS. 1600

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3eba34d0b
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0009 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 1600=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3eba34d0b--</pre>
ERROR - 2019-01-12 20:23:43 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0009 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:23:43 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:23:43 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 1 item (Order No.:  ORD0009)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0009"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:23:43 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":456,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:23:48 --> Severity: Warning --> fsockopen(): unable to connect to mail.transformsportsnutrition.com:456 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-12 20:23:48 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 10060 A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:23:43 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=39=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3ebf3b418@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3ebf3b43c&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3ebf3b43c
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 1 item (Order No.:
ORD0009)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3ebf3b43c
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 1 item (Order No.: ORD00=
09)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0009=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3ebf3b43c--</pre>
ERROR - 2019-01-12 20:24:54 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0010 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:24:54 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:24:54 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0010 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:24:54 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":25,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:24:59 --> error occured in people insert Communication_model/send_mail<br /><pre>hello: 220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:24:46 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
</pre>The following SMTP error was encountered: 220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:24:46 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:24:54 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=30?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3f0660700@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3f0660733&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3f0660733
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0010
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3f0660733
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0010 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3f0660733--</pre>
ERROR - 2019-01-12 20:24:59 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0010 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:24:59 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:24:59 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0010)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0010"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:24:59 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":25,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:24:59 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:24:59 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=30=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3f0b6dda2@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3f0b6ddb5&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3f0b6ddb5
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0010)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3f0b6ddb5
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
10)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0010=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3f0b6ddb5--</pre>
ERROR - 2019-01-12 20:25:26 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0011 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:25:26 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:25:26 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0011 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:25:26 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:25:34 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:25:13 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giOu9-001NyF-Os
</pre>The following SMTP error was encountered: 250 OK id=1giOu9-001NyF-Os
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:25:26 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3f26e0c06@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3f26e0c27&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3f26e0c27
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0011
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a3f26e0c27
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0011 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a3f26e0c27--</pre>
ERROR - 2019-01-12 20:25:34 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0011 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:25:34 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:25:34 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0011)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0011"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:25:34 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:25:34 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:25:34 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=31=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a3f2e4f3ad@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a3f2e4f3d0&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a3f2e4f3d0
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0011)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a3f2e4f3d0
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
11)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0011=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a3f2e4f3d0--</pre>
ERROR - 2019-01-12 20:32:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 20:32:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-12 20:32:34 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0012 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:32:34 --> Email configurations -- smtp -- ssl://smtp.googlemail.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:32:34 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0012 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:32:34 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/smtp.googlemail.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:32:38 --> error occured in people insert Communication_model/send_mail220 smtp.googlemail.com ESMTP l19sm183913176pfi.71 - gsmtp
<br /><pre>hello: 250-smtp.googlemail.com at your service, [1.23.250.244]
250-SIZE 35882577
250-8BITMIME
250-AUTH LOGIN PLAIN XOAUTH2 PLAIN-CLIENTTOKEN OAUTHBEARER XOAUTH
250-ENHANCEDSTATUSCODES
250-PIPELINING
250-CHUNKING
250 SMTPUTF8
</pre>Failed to authenticate password. Error: 535-5.7.8 Username and Password not accepted. Learn more at
535 5.7.8  https://support.google.com/mail/?p=BadCredentials l19sm183913176pfi.71 - gsmtp
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:32:34 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=32?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a40d260d68@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a40d260d7c&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a40d260d7c
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0012
has been confirmed.
 Amount: RS. 1600

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a40d260d7c
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0012 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 1600=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a40d260d7c--</pre>
ERROR - 2019-01-12 20:32:38 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0012 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:32:38 --> Email configurations -- smtp -- ssl://smtp.googlemail.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:32:38 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 1 item (Order No.:  ORD0012)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0012"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:32:38 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/smtp.googlemail.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:32:38 --> Severity: Warning --> fgets(): SSL operation failed with code 1. OpenSSL Error messages:
error:0607A082:digital envelope routines:EVP_CIPHER_CTX_set_key_length:invalid key length D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-12 20:32:38 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:32:38 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=32=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a40d6965d0@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a40d6965fa&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a40d6965fa
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 1 item (Order No.:
ORD0012)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a40d6965fa
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 1 item (Order No.: ORD00=
12)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0012=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a40d6965fa--</pre>
ERROR - 2019-01-12 20:34:03 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0013 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:34:03 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:34:03 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0013 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:34:03 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:34:10 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:33:50 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giP2U-001iDn-M3
</pre>The following SMTP error was encountered: 250 OK id=1giP2U-001iDn-M3
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:34:03 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=33?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a412b39eeb@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a412b39f22&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a412b39f22
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0013
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a412b39f22
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0013 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a412b39f22--</pre>
ERROR - 2019-01-12 20:34:10 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0013 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:34:10 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:34:10 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0013)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0013"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:34:10 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:34:10 --> Severity: Warning --> fgets(): SSL operation failed with code 1. OpenSSL Error messages:
error:0607A082:digital envelope routines:EVP_CIPHER_CTX_set_key_length:invalid key length D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-12 20:34:10 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:34:10 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=33=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a413207582@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a41320759e&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a41320759e
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0013)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a41320759e
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
13)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0013=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a41320759e--</pre>
ERROR - 2019-01-12 20:44:31 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0014 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-12 20:44:31 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:44:31 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0014 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-12 20:44:31 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:44:37 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sat, 12 Jan 2019 19:44:18 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.250.244]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giPCc-001p4M-Aj
</pre>The following SMTP error was encountered: 250 OK id=1giPCc-001p4M-Aj
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:44:31 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=34?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a439f63367@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a439f63378&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a439f63378
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0014
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3a439f63378
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0014 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3a439f63378--</pre>
ERROR - 2019-01-12 20:44:37 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0014 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-12 20:44:37 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-12 20:44:37 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0014)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0014"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-12 20:44:37 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-12 20:44:37 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sat, 12 Jan 2019 20:44:37 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=31=34=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3a43a5cb080@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3a43a5cb098&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3a43a5cb098
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0014)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3a43a5cb098
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
14)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0014=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3a43a5cb098--</pre>
ERROR - 2019-01-12 20:44:37 --> Severity: Warning --> fgets(): SSL operation failed with code 1. OpenSSL Error messages:
error:0607A082:digital envelope routines:EVP_CIPHER_CTX_set_key_length:invalid key length D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
