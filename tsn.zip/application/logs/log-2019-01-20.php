<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-20 06:31:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-20 06:31:26 --> Unable to connect to the database
ERROR - 2019-01-20 06:32:07 --> 404 Page Not Found: Shop/meal-replacement
ERROR - 2019-01-20 06:44:16 --> Severity: error --> Exception: Unable to locate the model you have specified: GetCatDataBySlug D:\xampp\htdocs\tsn\tsn\system\core\Loader.php 344
ERROR - 2019-01-20 11:30:03 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-20 11:30:03 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-20 11:30:03 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-20 11:30:03 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-20 11:45:45 --> Severity: Notice --> Undefined variable: sql D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 49
ERROR - 2019-01-20 11:45:45 --> Severity: Warning --> mysqli::query(): Empty query D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-01-20 11:45:45 --> Query error:  - Invalid query: 
ERROR - 2019-01-20 11:45:49 --> Severity: Notice --> Undefined variable: sql D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 49
ERROR - 2019-01-20 11:45:49 --> Severity: Warning --> mysqli::query(): Empty query D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-01-20 11:45:49 --> Query error:  - Invalid query: 
ERROR - 2019-01-20 11:45:51 --> Severity: Notice --> Undefined variable: sql D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 49
ERROR - 2019-01-20 11:45:51 --> Severity: Warning --> mysqli::query(): Empty query D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-01-20 11:45:51 --> Query error:  - Invalid query: 
ERROR - 2019-01-20 11:45:53 --> Severity: Notice --> Undefined variable: sql D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 49
ERROR - 2019-01-20 11:45:53 --> Severity: Warning --> mysqli::query(): Empty query D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-01-20 11:45:53 --> Query error:  - Invalid query: 
ERROR - 2019-01-20 11:45:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:45:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:45:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:46:37 --> Severity: Notice --> Undefined variable: sql D:\xampp\htdocs\tsn\tsn\application\models\Product_model.php 49
ERROR - 2019-01-20 11:46:37 --> Severity: Warning --> mysqli::query(): Empty query D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-01-20 11:46:37 --> Query error:  - Invalid query: 
ERROR - 2019-01-20 11:47:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:49:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:53:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:53:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:55:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:55:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:55:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:55:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:56:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:56:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:56:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:56:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:58:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:58:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:58:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:59:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:59:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 11:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 11:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:28:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:28:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:31:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:44:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:27 -->  check login ref = http://localhost/tsn/tsn/cart
ERROR - 2019-01-20 12:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:44:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:44:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:44:37 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0079 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0079 has been confirmed.</p>
    <p>Amount: <strong>RS. 8600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
<p>You can view your order updates by clicking on below link: <br>
<a href="https://www.transformsportsnutrition.com/my-orders">https://www.transformsportsnutrition.com/my-orders</a>
</p>
<p>Thanks for shopping with Transform Sports Nutrition, We appreciate it.<br> Follow us on Instagram for more offers and updates: <br>
    https://www.instagram.com/transformsportsnutrition/<br><br>Thank you, <br> Team Transform Sports Nutrition <br></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-20 12:44:37 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-20 12:44:37 --> CRIMINAL SUBJECTYour order #ORD0079 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0079 has been confirmed.</p>
    <p>Amount: <strong>RS. 8600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
<p>You can view your order updates by clicking on below link: <br>
<a href="https://www.transformsportsnutrition.com/my-orders">https://www.transformsportsnutrition.com/my-orders</a>
</p>
<p>Thanks for shopping with Transform Sports Nutrition, We appreciate it.<br> Follow us on Instagram for more offers and updates: <br>
    https://www.instagram.com/transformsportsnutrition/<br><br>Thank you, <br> Team Transform Sports Nutrition <br></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-20 12:44:37 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-20 12:44:44 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 20 Jan 2019 11:44:21 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.158]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1glBWY-00065Y-0c
</pre>The following SMTP error was encountered: 250 OK id=1glBWY-00065Y-0c
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 20 Jan 2019 12:44:37 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=39?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c445f252515f@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c445f2525174&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c445f2525174
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0079 has
been confirmed.
 Amount: RS. 8600
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
You can view your order updates by clicking on below link:
https://www.transformsportsnutrition.com/my-orders

Thanks for shopping with Transform Sports Nutrition, We appreciate it.
Follow us on Instagram for more offers and updates:
 https://www.instagram.com/transformsportsnutrition/Thank you, Team
Transform Sports Nutrition


--B_ALT_5c445f2525174
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0079 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 8600=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
=3Cp=3EYou can view your order updates by clicking on below link: =3Cbr=3E
=3Ca href=3D=22https://www.transformsportsnutrition.com/my-orders=22=3Ehttp=
s://www.transformsportsnutrition.com/my-orders=3C/a=3E
=3C/p=3E
=3Cp=3EThanks for shopping with Transform Sports Nutrition, We appreciate i=
t.=3Cbr=3E Follow us on Instagram for more offers and updates: =3Cbr=3E
 https://www.instagram.com/transformsportsnutrition/=3Cbr=3E=3Cbr=3EThank y=
ou, =3Cbr=3E Team Transform Sports Nutrition =3Cbr=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c445f2525174--</pre>
ERROR - 2019-01-20 12:44:44 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0079">View Order</></strong>
ERROR - 2019-01-20 12:44:44 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-20 12:44:44 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0079">View Order</></strong>
ERROR - 2019-01-20 12:44:44 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-20 12:44:44 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 20 Jan 2019 12:44:44 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c445f2c8429e@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c445f2c842bc&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c445f2c842bc
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c445f2c842bc
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0079=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c445f2c842bc--</pre>
ERROR - 2019-01-20 12:44:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:45 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:45 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:45 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:45 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:46 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:46 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:46 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:46 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:47 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:47 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:47 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:47 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:48 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:48 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:48 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:48 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:49 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:49 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:49 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:50 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-20 12:44:50 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-20 12:53:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-20 12:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-20 12:53:06 --> 404 Page Not Found: Assets/js
