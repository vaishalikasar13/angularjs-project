<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-25 13:05:25 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2018-12-25 13:05:36 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0001 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-25 13:05:36 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-25 13:05:36 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-25 13:05:36 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-25 13:05:44 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Tue, 25 Dec 2018 12:05:30 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.69]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gblSl-001CyP-N0
</pre>The following SMTP error was encountered: 250 OK id=1gblSl-001CyP-N0
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Tue, 25 Dec 2018 13:05:36 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c221d10ac240@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c221d10ac264&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c221d10ac264
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001
has been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c221d10ac264
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0001 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c221d10ac264--</pre>
ERROR - 2018-12-25 13:07:10 --> Paytm ::Request code-{"MID":"UEyXxW16238925300179","ORDER_ID":"ORD0002","CUST_ID":"4","INDUSTRY_TYPE_ID":"Retail","CHANNEL_ID":"WEB","TXN_AMOUNT":"2000","CALLBACK_URL":"http:\/\/localhost\/tsn\/tsn\/paytm\/response","WEBSITE":"WEBSTAGING","MSISDN":"8655385802","EMAIL":"vaishalikasar13@gmail.com","VERIFIED_BY":"EMAIL","IS_USER_VERIFIED":"YES"}checksum"1IwWDHlp5Zqr5+V0AF+IZWlND1BGev2sG25L660e2xhz\/yXl8ehkHNjd4G+b0EAq4vsI4MEC8thaBur24n4qDrudhokqPNzPJeIx+PTAEDk="Print IdORD0002
ERROR - 2018-12-25 13:07:15 --> Paytm ::Response code-{"ORDERID":"ORD0002","MID":"UEyXxW16238925300179","TXNAMOUNT":"2000.00","CURRENCY":"INR","STATUS":"TXN_FAILURE","RESPCODE":"325","RESPMSG":"Duplicate order id.","BANKTXNID":"","CHECKSUMHASH":"op0NR+Q\/A\/OOH5tovVryZLzzEjZqgcVlnjDu2I0VdHgBe9LqHgnnyNbfExalBWWkzhMe8JlXK8j4pZtZfFcLJb7Ey46k\/RkDifkogdQ3fJk="}checksum"op0NR+Q\/A\/OOH5tovVryZLzzEjZqgcVlnjDu2I0VdHgBe9LqHgnnyNbfExalBWWkzhMe8JlXK8j4pZtZfFcLJb7Ey46k\/RkDifkogdQ3fJk="ORDERID : ORD0002
ERROR - 2018-12-25 13:07:15 --> db_check_txn1 >> false
ERROR - 2018-12-25 13:07:15 --> Severity: Notice --> Undefined index: TXNID D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 138
ERROR - 2018-12-25 13:07:15 --> Severity: Notice --> Undefined index: PAYMENTMODE D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 140
ERROR - 2018-12-25 13:07:15 --> Severity: Notice --> Undefined index: TXNDATE D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 142
ERROR - 2018-12-25 13:07:15 --> Severity: Notice --> Undefined index: GATEWAYNAME D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 146
ERROR - 2018-12-25 13:07:15 --> Severity: Notice --> Undefined index: BANKNAME D:\xampp\htdocs\tsn\tsn\application\controllers\Paytm.php 148
ERROR - 2018-12-25 13:07:15 --> Query error: Unknown column 'pyt_pay_response_code' in 'field list' - Invalid query: INSERT INTO `paytm_transactions` (`pyt_pay_response_code`, `pyt_pay_status`, `pyt_order_reference_no`, `pyt_mid_no`, `pyt_txn_id`, `pyt_txn_amt`, `pyt_payment_mode`, `pyt_currency`, `pyt_txn_date`, `pyt_txn_status`, `pyt_resp_code`, `pyt_resp_message`, `pyt_gateway_name`, `pyt_bnk_txn_id`, `pyt_bnk_name`) VALUES ('325', 'TXN_FAILURE', 'ORD0002', 'UEyXxW16238925300179', NULL, '2000.00', NULL, 'INR', NULL, 'TXN_FAILURE', '325', 'Duplicate order id.', NULL, '', NULL)
ERROR - 2018-12-25 13:08:33 --> Paytm ::Request code-{"MID":"UEyXxW16238925300179","ORDER_ID":"ORD0201","CUST_ID":"4","INDUSTRY_TYPE_ID":"Retail","CHANNEL_ID":"WEB","TXN_AMOUNT":"2000","CALLBACK_URL":"http:\/\/localhost\/tsn\/tsn\/paytm\/response","WEBSITE":"WEBSTAGING","MSISDN":"8655385802","EMAIL":"vaishalikasar13@gmail.com","VERIFIED_BY":"EMAIL","IS_USER_VERIFIED":"YES"}checksum"o87k1ylGjzadh1iy46DbxcKCl3J3wQNNE5600FKQR\/KtkjJD8RLnC2ahnZZ22YLuTeHuTmebHidzoLbx7tod5UN\/EDAL1JWFAgqYWLWOFQI="Print IdORD0201
ERROR - 2018-12-25 13:09:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:09:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:09:28 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0202 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-25 13:09:28 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-25 13:09:29 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0202 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-25 13:09:29 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-25 13:09:36 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Tue, 25 Dec 2018 12:09:22 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.69]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gblWV-001Fr1-C1
</pre>The following SMTP error was encountered: 250 OK id=1gblWV-001Fr1-C1
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Tue, 25 Dec 2018 13:09:29 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=32=30=32?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c221df901f91@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c221df901fd7&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c221df901fd7
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0202
has been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c221df901fd7
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0202 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c221df901fd7--</pre>
ERROR - 2018-12-25 13:11:57 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 58
ERROR - 2018-12-25 13:15:11 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 167
ERROR - 2018-12-25 13:15:11 --> Severity: Notice --> Undefined variable: generated_code D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 174
ERROR - 2018-12-25 13:15:22 --> Severity: Notice --> Undefined variable: generated_code D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 174
ERROR - 2018-12-25 13:18:30 --> Severity: error --> Exception: Unsupported operand types D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 168
ERROR - 2018-12-25 13:20:59 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 169
ERROR - 2018-12-25 13:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:22:46 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 169
ERROR - 2018-12-25 13:27:03 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD1 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-25 13:27:03 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-25 13:27:03 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD1 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-25 13:27:03 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-25 13:27:10 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Tue, 25 Dec 2018 12:26:57 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.69]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gblnV-001hCH-FQ
</pre>The following SMTP error was encountered: 250 OK id=1gblnV-001hCH-FQ
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Tue, 25 Dec 2018 13:27:03 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=31=20=68=61?= =?ISO-8859-1?Q?=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75=63=63=65?= =?ISO-8859-1?Q?=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c222217d51fb@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c222217d5232&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c222217d5232
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD1 has
been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c222217d5232
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD1 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c222217d5232--</pre>
ERROR - 2018-12-25 13:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:42 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0201 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2018-12-25 13:27:42 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2018-12-25 13:27:42 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0201 has been confirmed.</p>
    <p>Amount: <strong>RS. 2000</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2018-12-25 13:27:42 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":587,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2018-12-25 13:27:48 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Tue, 25 Dec 2018 12:27:36 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [113.193.44.69]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250-STARTTLS
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gblo8-001hch-7D
</pre>The following SMTP error was encountered: 250 OK id=1gblo8-001hch-7D
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Tue, 25 Dec 2018 13:27:42 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=32=30=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c22223e94760@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c22223e947e5&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c22223e947e5
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0201
has been confirmed.
 Amount: RS. 2000

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c22223e947e5
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0201 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 2000=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c22223e947e5--</pre>
ERROR - 2018-12-25 13:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:30:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:30:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:30:05 --> Query error: Column 'ord_reference_no' cannot be null - Invalid query: INSERT INTO `person_order` (`ord_reference_no`, `ord_source`, `ord_prs_id`, `ord_delivery_adddress`, `ord_payment_mode`, `ord_sub_total`, `ord_shipping_charges`, `ord_update_sent_mobile`, `ord_update_sent_email`, `ord_total_amt`, `ord_date`, `ord_status`, `ord_crtd_dt`, `ord_crtd_by`) VALUES (NULL, 1, '4', '1', '1', 2000, NULL, '9967215433', 'vaishalikasar13@gmail.com', 2000, '2018-12-25', 1, '2018-12-25 13:30:05', '4')
ERROR - 2018-12-25 13:30:46 --> Query error: Column 'ord_reference_no' cannot be null - Invalid query: INSERT INTO `person_order` (`ord_reference_no`, `ord_source`, `ord_prs_id`, `ord_delivery_adddress`, `ord_payment_mode`, `ord_sub_total`, `ord_shipping_charges`, `ord_update_sent_mobile`, `ord_update_sent_email`, `ord_total_amt`, `ord_date`, `ord_status`, `ord_crtd_dt`, `ord_crtd_by`) VALUES (NULL, 1, '4', '1', '1', 2000, NULL, '9967215433', 'vaishalikasar13@gmail.com', 2000, '2018-12-25', 1, '2018-12-25 13:30:46', '4')
ERROR - 2018-12-25 13:31:03 --> Query error: Column 'ord_reference_no' cannot be null - Invalid query: INSERT INTO `person_order` (`ord_reference_no`, `ord_source`, `ord_prs_id`, `ord_delivery_adddress`, `ord_payment_mode`, `ord_sub_total`, `ord_shipping_charges`, `ord_update_sent_mobile`, `ord_update_sent_email`, `ord_total_amt`, `ord_date`, `ord_status`, `ord_crtd_dt`, `ord_crtd_by`) VALUES (NULL, 1, '4', '1', '1', 2000, NULL, '9967215433', 'vaishalikasar13@gmail.com', 2000, '2018-12-25', 1, '2018-12-25 13:31:03', '4')
ERROR - 2018-12-25 13:31:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:32:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 13:32:47 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 13:32:47 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:35:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:36:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:36:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:36:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:36:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:50:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-12-25 14:50:01 --> Unable to connect to the database
ERROR - 2018-12-25 14:50:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-12-25 14:50:10 --> Unable to connect to the database
ERROR - 2018-12-25 14:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:50:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:52:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:52:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:52:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:54:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:57:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:57:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:57:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:58:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:59:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 14:59:43 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:59:43 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 14:59:43 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 15:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 15:09:17 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:09:17 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 15:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 15:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 15:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:22:34 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2018-12-25 17:22:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:22:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:22:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:23:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:23:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:24:40 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:24:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:25:07 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:25:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:26:14 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:26:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:21 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:21 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:25 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:25 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:29 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:29 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:30:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:30:33 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\tsn\tsn\system\database\DB_driver.php 1477
ERROR - 2018-12-25 17:30:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `person_order_products` (0) VALUES (Array)
ERROR - 2018-12-25 17:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:31:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:32:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:32:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:32:15 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:15 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:32:16 --> Query error: Column 'ops_crtd_by' cannot be null - Invalid query: INSERT INTO `person_order_product_status` (`ops_status`, `ops_odp_id`, `ops_crtd_dt`, `ops_crtd_by`) VALUES (1, 2, '2018-12-25 17:32:16', NULL)
ERROR - 2018-12-25 17:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:24 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:33:27 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:33:27 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:45 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:45 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:34:48 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:34:48 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:58:54 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:58:54 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:58:54 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:58:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:58:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:59:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:59:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:07 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2018-12-25 17:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:59:09 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-25 17:59:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 17:59:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-12-25 19:18:46 -->  check login ref = http://localhost/tsn/tsn/my-orders
ERROR - 2018-12-25 19:24:27 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 143
ERROR - 2018-12-25 19:24:48 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 144
ERROR - 2018-12-25 19:31:22 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 143
ERROR - 2018-12-25 19:31:34 --> Severity: Notice --> Undefined variable: orderProductStatus D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 95
ERROR - 2018-12-25 19:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 95
ERROR - 2018-12-25 19:32:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `person_order_product_status`' at line 3 - Invalid query: SELECT *,
    (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=odp_status and gen_prm.gnp_group='order_prd_status') prd_status,
   FROM `person_order_product_status`
ERROR - 2018-12-25 19:32:37 --> Query error: Unknown column 'odp_status' in 'where clause' - Invalid query: SELECT *,
    (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=odp_status and gen_prm.gnp_group='order_prd_status') prd_status FROM `person_order_product_status`
ERROR - 2018-12-25 19:33:16 --> Severity: Notice --> Undefined property: stdClass::$ord_id D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 97
ERROR - 2018-12-25 19:39:18 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 122
ERROR - 2018-12-25 19:39:41 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 122
ERROR - 2018-12-25 19:39:52 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 122
ERROR - 2018-12-25 19:40:07 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 122
ERROR - 2018-12-25 19:40:14 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 122
ERROR - 2018-12-25 19:47:50 --> Severity: Notice --> Undefined property: stdClass::$gnp_value D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 168
ERROR - 2018-12-25 19:51:14 -->  check login ref = http://localhost/tsn/tsn/my-orders
ERROR - 2018-12-25 19:54:31 --> Severity: Notice --> Undefined variable: class D:\xampp\htdocs\tsn\tsn\application\views\order_list.php 103
