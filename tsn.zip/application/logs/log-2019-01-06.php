<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-06 06:11:02 -->  check login ref = http://localhost/tsn/tsn/
ERROR - 2019-01-06 06:16:57 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-06 06:16:57 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-06 06:16:57 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-06 06:16:57 --> 404 Page Not Found: Assets/pages
ERROR - 2019-01-06 06:17:08 -->  check login ref = http://localhost/tsn/tsn/my-orders
