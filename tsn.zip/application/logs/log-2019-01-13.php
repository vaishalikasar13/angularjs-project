<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-13 04:04:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 04:05:00 --> Unable to connect to the database
ERROR - 2019-01-13 04:05:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 04:05:37 --> Unable to connect to the database
ERROR - 2019-01-13 04:06:48 -->  check login ref = http://localhost/tsn/tsn/
ERROR - 2019-01-13 07:47:32 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-13 07:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:48:14 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0001 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-13 07:48:14 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 07:48:14 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001 has been confirmed.</p>
    <p>Amount: <strong>RS. 3170</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 07:48:14 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 07:48:22 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 06:48:01 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giZYv-000Gn0-VS
</pre>The following SMTP error was encountered: 250 OK id=1giZYv-000Gn0-VS
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 07:48:14 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3adf2e3f308@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3adf2e3f31e&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3adf2e3f31e
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0001
has been confirmed.
 Amount: RS. 3170

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3adf2e3f31e
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0001 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 3170=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3adf2e3f31e--</pre>
ERROR - 2019-01-13 07:48:22 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0001 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-13 07:48:22 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 07:48:22 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 2 item (Order No.:  ORD0001)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0001"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-13 07:48:22 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 07:48:22 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 07:48:22 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=30=31=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3adf363792f@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3adf3637944&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3adf3637944
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 2 item (Order No.:
ORD0001)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3adf3637944
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 2 item (Order No.: ORD00=
01)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0001=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3adf3637944--</pre>
ERROR - 2019-01-13 07:48:22 --> Severity: Warning --> fgets(): SSL operation failed with code 1. OpenSSL Error messages:
error:0607A082:digital envelope routines:EVP_CIPHER_CTX_set_key_length:invalid key length D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 07:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:13 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0002 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-13 07:49:13 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 07:49:13 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0002 has been confirmed.</p>
    <p>Amount: <strong>RS. 1580</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 07:49:13 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 07:49:19 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order #ORD0002 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-13 07:49:19 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 07:49:19 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 2 item (Order No.:  ORD0002)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0002"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-13 07:49:19 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 07:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 07:49:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 07:49:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 09:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 09:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 09:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:03 --> Severity: Notice --> Constant ADMIN_EMAIL already defined D:\xampp\htdocs\tsn\tsn\application\config\mail_template.php 14
ERROR - 2019-01-13 10:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:11:02 --> Sending Email to vaishalikasar13@gmail.com || Subject: TSN | Enquiry Received||  Message: ,  || TEMPLATE: email_template/adminContactUs
ERROR - 2019-01-13 10:11:02 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 10:11:02 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     You have received a new Enquiry
    <br>
    Name     : vaishali kasar    <br>
    Email    : <a href="mailto:vaishalikasar13@gmail.com">vaishalikasar13@gmail.com</a>
    <br>
    Mobile : <a href="tel:8655385802">8655385802</a>
    <br>
    Subject :     <br>

    Message  : fgg    <br>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-13 10:11:02 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 10:11:06 --> Sending Email to vaishalikasar13@gmail.com || Subject: TSN | Thank you for contacting us||  Message: ,  || TEMPLATE: email_template/userContactUs
ERROR - 2019-01-13 10:11:06 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 10:11:06 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Hi,
    <br>
    Greetings from TSN!
    <br>
    <br>
    You recently gave us some really helpful comments .<br>
    We really appreciate the time you took.
    <br>
   Thanks for contacting us!!!
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->


    <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'> Best Wishes,<br>
    TSN   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-13 10:11:06 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 10:11:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:11:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:11:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:52:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:52:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:52:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:26 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-13 10:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 10:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 10:53:31 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 79
ERROR - 2019-01-13 10:53:31 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 80
ERROR - 2019-01-13 10:53:31 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 81
ERROR - 2019-01-13 10:53:31 --> Severity: Notice --> Undefined property: Order::$communication_model D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 83
ERROR - 2019-01-13 10:53:31 --> Severity: error --> Exception: Call to a member function communication() on null D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 83
ERROR - 2019-01-13 10:54:12 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 79
ERROR - 2019-01-13 10:54:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 79
ERROR - 2019-01-13 10:54:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 80
ERROR - 2019-01-13 10:55:05 --> Severity: Notice --> Undefined property: Order::$communication_model D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 83
ERROR - 2019-01-13 10:55:05 --> Severity: error --> Exception: Call to a member function communication() on null D:\xampp\htdocs\tsn\tsn\application\controllers\Order.php 83
ERROR - 2019-01-13 10:55:44 --> >> communication
ERROR - 2019-01-13 10:55:44 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:55:44 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:55:44 --> >> sendMail sub = Something went wrong
ERROR - 2019-01-13 10:55:44 --> >> sendMail message = Something went wrong
ERROR - 2019-01-13 10:55:45 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 10:55:45 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 10:55:44 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0b205d106@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Something=20went=20wrong?=
Something went wrong
</pre>
ERROR - 2019-01-13 10:58:34 --> >> communication
ERROR - 2019-01-13 10:58:34 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:58:34 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:58:34 --> >> sendMail sub = Something went wrong
ERROR - 2019-01-13 10:58:34 --> >> sendMail message = Something went wrong
ERROR - 2019-01-13 10:58:35 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 10:58:35 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 10:58:34 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0bca9849f@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Something=20went=20wrong?=
Something went wrong
</pre>
ERROR - 2019-01-13 10:59:06 --> >> communication
ERROR - 2019-01-13 10:59:06 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:59:06 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 10:59:06 --> >> sendMail sub = Something went wrong
ERROR - 2019-01-13 10:59:06 --> >> sendMail message = Something went wrong
ERROR - 2019-01-13 10:59:07 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 10:59:07 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 10:59:06 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0bea71ef1@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Something=20went=20wrong?=
Something went wrong
</pre>
ERROR - 2019-01-13 11:00:38 --> >> communication
ERROR - 2019-01-13 11:00:38 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:00:38 --> Severity: Notice --> Undefined variable: body D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 142
ERROR - 2019-01-13 11:01:09 --> >> communication
ERROR - 2019-01-13 11:01:09 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:01:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:01:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:01:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:02:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:02:13 --> >> communication
ERROR - 2019-01-13 11:02:13 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:02:13 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:02:13 --> >> sendMail sub = 
ERROR - 2019-01-13 11:02:13 --> >> sendMail message = 
ERROR - 2019-01-13 11:02:14 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:02:14 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:02:13 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0ca56f37e@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q??=

</pre>
ERROR - 2019-01-13 11:03:39 --> >> communication
ERROR - 2019-01-13 11:03:39 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:03:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 119
ERROR - 2019-01-13 11:04:26 --> >> communication
ERROR - 2019-01-13 11:04:26 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:04:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 121
ERROR - 2019-01-13 11:04:26 --> Severity: Notice --> Undefined property: stdClass::$customer_name D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 124
ERROR - 2019-01-13 11:04:26 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:04:26 --> >> sendMail sub = Your order #ORD0015 has been placed successfully
ERROR - 2019-01-13 11:04:26 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey ,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0015 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p></p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:04:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:04:27 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:04:26 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0d2a8d06a@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0015=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey ,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0015 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:04:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\tsn\tsn\system\core\Exceptions.php:271) D:\xampp\htdocs\tsn\tsn\system\core\Common.php 570
ERROR - 2019-01-13 11:04:50 --> >> communication
ERROR - 2019-01-13 11:04:50 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$customer_name D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 124
ERROR - 2019-01-13 11:04:50 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:04:50 --> >> sendMail sub = Your order #ORD0016 has been placed successfully
ERROR - 2019-01-13 11:04:50 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0016 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p></p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:04:51 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:04:51 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:04:49 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0d4208046@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0016=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0016 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:05:20 --> >> communication
ERROR - 2019-01-13 11:05:20 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:05:20 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:05:20 --> >> sendMail sub = Your order #ORD0017 has been placed successfully
ERROR - 2019-01-13 11:05:20 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0017 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:05:21 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:05:21 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:05:20 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0d60888da@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0017=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0017 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:05:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:05:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:05:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:05:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:05:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:05:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:05:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:06:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:06:10 --> >> communication
ERROR - 2019-01-13 11:06:10 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:06:10 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:06:10 --> >> sendMail sub = Your order #ORD0018 has been placed successfully
ERROR - 2019-01-13 11:06:10 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0018 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:06:11 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:06:11 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:06:10 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0d9268d67@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0018=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0018 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 10&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:07:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:07:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:07:38 --> >> communication
ERROR - 2019-01-13 11:07:38 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:07:38 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:07:38 --> >> sendMail sub = Your order #ORD0019 has been placed successfully
ERROR - 2019-01-13 11:07:38 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0019 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:07:39 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:07:39 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:07:37 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0dea3600c@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0019=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0019 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 10&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:08:57 --> >> communication
ERROR - 2019-01-13 11:08:57 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:08:57 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:08:57 --> >> sendMail sub = Your order #ORD0020 has been placed successfully
ERROR - 2019-01-13 11:08:57 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0020 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:08:58 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:08:58 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:08:57 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0e398de05@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0020=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0020 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:12:27 --> >> communication
ERROR - 2019-01-13 11:12:27 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:12:27 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:12:27 --> >> sendMail sub = Your order #ORD0021 has been placed successfully
ERROR - 2019-01-13 11:12:27 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0021 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:12:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:12:28 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:12:27 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0f0bb8f2a@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0021=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
test
</pre>
ERROR - 2019-01-13 11:13:40 --> >> communication
ERROR - 2019-01-13 11:13:40 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:13:40 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:13:40 --> >> sendMail sub = Your order #ORD0022 has been placed successfully
ERROR - 2019-01-13 11:13:40 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0022 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:13:41 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:13:41 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:13:40 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0f5462380@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0022=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
test
</pre>
ERROR - 2019-01-13 11:15:29 --> >> communication
ERROR - 2019-01-13 11:15:29 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:15:29 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:15:29 --> >> sendMail sub = Your order #ORD0023 has been placed successfully
ERROR - 2019-01-13 11:15:29 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0023 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:15:30 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:15:30 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:15:28 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b0fc10a830@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0023=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0023 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:16:48 --> >> communication
ERROR - 2019-01-13 11:16:48 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:16:48 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:16:48 --> >> sendMail sub = Your order #ORD0024 has been placed successfully
ERROR - 2019-01-13 11:16:48 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0024 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:16:49 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:16:49 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:16:48 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b1010c368d@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0024=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0024 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:19:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:19:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:19:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:19:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:20:00 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:20:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:20:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:20:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:20:03 --> >> communication
ERROR - 2019-01-13 11:20:03 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:20:03 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:20:03 --> >> sendMail sub = Your order #ORD0025 has been placed successfully
ERROR - 2019-01-13 11:20:03 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0025 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:20:04 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:20:04 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:20:03 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Bcc: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b10d382d98@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0025=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0025 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 1600&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:51 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:58 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-13 11:50:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:50:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:50:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:51:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:51:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:51:04 --> >> communication
ERROR - 2019-01-13 11:51:04 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:51:04 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:51:04 --> >> sendMail sub = Your order #ORD0026 has been placed successfully
ERROR - 2019-01-13 11:51:04 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0026 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:51:05 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:51:05 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:51:04 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b181857eb6@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0026=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
HII
</pre>
ERROR - 2019-01-13 11:51:58 --> >> communication
ERROR - 2019-01-13 11:51:58 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:51:58 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:51:58 --> >> sendMail sub = Your order #ORD0027 has been placed successfully
ERROR - 2019-01-13 11:51:58 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0027 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 11:51:59 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:51:59 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:51:58 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b184ebd3fa@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0027=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
HII
</pre>
ERROR - 2019-01-13 11:54:11 --> >> communication
ERROR - 2019-01-13 11:54:11 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:54:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:54:12 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:54:10 +0100
From: &quot;saddsd&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b18d31b9be@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0028=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0028 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:54:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 11:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 11:54:40 --> >> communication
ERROR - 2019-01-13 11:54:40 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:54:41 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:54:41 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:54:39 +0100
From: &quot;saddsd&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b18f022726@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0029=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0029 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 1600&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:54:41 --> >> communication
ERROR - 2019-01-13 11:54:41 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:54:42 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:54:42 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:54:41 +0100
From: &quot;saddsd&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b18f1a3336@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0030=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0030 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:55:05 --> >> communication
ERROR - 2019-01-13 11:55:05 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:55:06 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:55:06 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:55:05 +0100
From: &quot;saddsd&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b190988a2d@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0031=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0031 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 11:56:05 --> >> communication
ERROR - 2019-01-13 11:56:05 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:56:25 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 45
ERROR - 2019-01-13 11:56:36 --> >> communication
ERROR - 2019-01-13 11:56:36 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:56:49 --> >> communication
ERROR - 2019-01-13 11:56:49 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:57:04 --> >> communication
ERROR - 2019-01-13 11:57:04 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:58:05 --> >> communication
ERROR - 2019-01-13 11:58:05 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:58:35 --> >> communication
ERROR - 2019-01-13 11:58:35 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:58:36 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 11:58:36 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 11:58:35 +0100
From: &quot;saddsd&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b19dba4ca4@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?email=5Fsub?=
sad
</pre>
ERROR - 2019-01-13 11:59:10 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 198
ERROR - 2019-01-13 11:59:18 --> >> communication
ERROR - 2019-01-13 11:59:18 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 11:59:19 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:01:11 --> >> communication
ERROR - 2019-01-13 12:01:11 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:01:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:04:53 --> >> communication
ERROR - 2019-01-13 12:04:53 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:04:55 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:05:44 --> >> communication
ERROR - 2019-01-13 12:05:44 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:05:45 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:06:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:06:49 --> >> communication
ERROR - 2019-01-13 12:06:49 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:06:50 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:13:56 --> >> communication
ERROR - 2019-01-13 12:13:56 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:13:56 --> Severity: Notice --> Use of undefined constant EMAIL_SOURCE - assumed 'EMAIL_SOURCE' D:\xampp\htdocs\tsn\tsn\application\models\Communication_model.php 176
ERROR - 2019-01-13 12:13:57 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1882
ERROR - 2019-01-13 12:13:57 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:13:56 +0100
From: &quot;MODE ARCH&quot; &lt;EMAIL_SOURCE&gt;
Return-Path: &lt;EMAIL_SOURCE&gt;
Reply-To: &lt;EMAIL_SOURCE&gt;
User-Agent: CodeIgniter
X-Sender: EMAIL_SOURCE
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b1d746b98c&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0043=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0043 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 12:14:57 --> >> communication
ERROR - 2019-01-13 12:14:57 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:14:58 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:14:58 --> error occured in people insert home_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:14:57 +0100
From: &quot;MODE ARCH&quot; &lt;info@modearch.in&gt;
Return-Path: &lt;info@modearch.in&gt;
Reply-To: &lt;info@modearch.in&gt;
User-Agent: CodeIgniter
X-Sender: info@modearch.in
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b1db1e7569@modearch.in&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0044=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0044 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 12:16:59 --> >> communication
ERROR - 2019-01-13 12:16:59 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:16:59 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:16:59 --> >> sendMail sub = Your order #ORD0045 has been placed successfully
ERROR - 2019-01-13 12:16:59 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0045 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 12:17:00 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:17:00 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:16:58 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b1e2b1af2b@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0045=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0045 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 0&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 12:19:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:19:48 --> Unable to connect to the database
ERROR - 2019-01-13 12:19:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:19:48 --> Unable to connect to the database
ERROR - 2019-01-13 12:19:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:19:54 --> Unable to connect to the database
ERROR - 2019-01-13 12:19:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:19:58 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:02 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:07 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:18 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:23 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:31 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:37 --> Unable to connect to the database
ERROR - 2019-01-13 12:20:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:20:56 --> Unable to connect to the database
ERROR - 2019-01-13 12:21:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:21:29 --> Unable to connect to the database
ERROR - 2019-01-13 12:22:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:22:09 --> Unable to connect to the database
ERROR - 2019-01-13 12:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:22:13 --> Unable to connect to the database
ERROR - 2019-01-13 12:22:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:22:40 --> Unable to connect to the database
ERROR - 2019-01-13 12:22:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\tsn\tsn\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-13 12:22:46 --> Unable to connect to the database
ERROR - 2019-01-13 12:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:28:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:28:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:28:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 12:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 12:28:22 --> >> communication
ERROR - 2019-01-13 12:28:22 --> >> communication user email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:28:22 --> >> sendMail email id = vaishalikasar13@gmail.com
ERROR - 2019-01-13 12:28:22 --> >> sendMail sub = Your order #ORD0046 has been placed successfully
ERROR - 2019-01-13 12:28:22 --> >> sendMail message = <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0046 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 12:28:23 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 1888
ERROR - 2019-01-13 12:28:23 --> error occured in people insert communication_model/send_mailUnable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:28:21 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b20d64599f@transformsportsnutrition.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Your=20order=20#ORD0046=20?==?UTF-8?Q?has=20been?= =?UTF-8?Q?=20placed=20successfully?=
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
 &lt;style type=&quot;text/css&quot;&gt;
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  &lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;
&lt;div class=&quot;content&quot;&gt;
  &lt;div class=&quot;header&quot;&gt;
    &lt;img src=&quot;https://transformsportsnutrition.com/assets/images/logo.png&quot;&gt;
  &lt;/div&gt;
  &lt;div class=&quot;info&quot;&gt;
  &lt;h3&gt;Order&lt;/h3&gt;
  &lt;h3 class=&quot;line&quot;&gt;Confirmed&lt;/h3&gt;
  &lt;div class=&quot;temp&quot;&gt;
    &lt;p&gt;Hey vaishali kasar,&lt;/p&gt;
    &lt;p&gt;Thank you for shopping at %WEBSITE_NAME%.Your order ORD0046 has been
confirmed.&lt;/p&gt;
    &lt;p&gt;Amount: &lt;strong&gt;RS. 1600&lt;/strong&gt;&lt;/p&gt;
    &lt;p&gt;vaishali kasar&lt;/p&gt;
&lt;p&gt;E wing, 702 Mandakini  building rawalpada dahisar(East)&lt;/p&gt;
&lt;p&gt;298 last stop &lt;/p&gt;
&lt;p&gt;mumbai- 400068 &lt;/p&gt;&lt;/p&gt;
  &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
ERROR - 2019-01-13 12:33:52 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0047 has been placed successfully||  Message: ,  || TEMPLATE: client_order_placed
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_PROTOCOL - assumed 'EMAIL_PROTOCOL' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_HOST - assumed 'EMAIL_HOST' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_USERNAME - assumed 'EMAIL_USERNAME' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_PASSWORD - assumed 'EMAIL_PASSWORD' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_TYPE - assumed 'EMAIL_TYPE' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_CHARSET - assumed 'EMAIL_CHARSET' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_WORDWRAP - assumed 'EMAIL_WORDWRAP' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 47
ERROR - 2019-01-13 12:33:52 --> Email configurations -- EMAIL_PROTOCOL -- EMAIL_HOST -- EMAIL_USERNAME -- EMAIL_PASSWORD -- EMAIL_TYPE -- EMAIL_CHARSET -- EMAIL_WORDWRAP
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_PROTOCOL - assumed 'EMAIL_PROTOCOL' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 54
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_HOST - assumed 'EMAIL_HOST' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 55
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_PORT - assumed 'EMAIL_PORT' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 56
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_USERNAME - assumed 'EMAIL_USERNAME' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 57
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_PASSWORD - assumed 'EMAIL_PASSWORD' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 58
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_TYPE - assumed 'EMAIL_TYPE' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 59
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_CHARSET - assumed 'EMAIL_CHARSET' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 60
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_WORDWRAP - assumed 'EMAIL_WORDWRAP' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 61
ERROR - 2019-01-13 12:33:52 --> Severity: Notice --> Use of undefined constant EMAIL_USERNAME - assumed 'EMAIL_USERNAME' D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 68
ERROR - 2019-01-13 12:33:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\tsn\tsn\system\core\Exceptions.php:271) D:\xampp\htdocs\tsn\tsn\system\core\Common.php 570
ERROR - 2019-01-13 12:35:02 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0048 has been placed successfully||  Message: ,  || TEMPLATE: client_order_placed
ERROR - 2019-01-13 12:35:02 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 12:36:42 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0049 has been placed successfully||  Message: ,  || TEMPLATE: email_template/order_success
ERROR - 2019-01-13 12:36:42 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 12:36:42 --> CRIMINAL SUBJECTvaishalikasar13@gmail.com || MESSAGE : <!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey Vaishali Kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition. Your order #ORD0049 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <!-- <p>Estimated Delivery: <strong>23 Dec,2018</strong></p> -->
    <p><strong>Shipping/Billing Address:</strong></p>
    <p>Vaishali Kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East) </p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  <p>Landmark: MAHARASHTRA</p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 12:36:42 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 12:36:50 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 11:36:28 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gie45-000EXx-TX
</pre>The following SMTP error was encountered: 250 OK id=1gie45-000EXx-TX
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:36:42 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=34=39?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b22ca1ab79@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b22ca1abba&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b22ca1abba
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey Vaishali Kasar,
 Thank you for shopping at Transform Sports Nutrition. Your order #ORD0049
has been confirmed.
 Amount: RS. 0

 Shipping/Billing Address:
 Vaishali Kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068
 Landmark: MAHARASHTRA


--B_ALT_5c3b22ca1abba
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Ctitle=3E=3C/title=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey Vaishali Kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition. Your order =
=23ORD0049 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3C=21-- =3Cp=3EEstimated Delivery: =3Cstrong=3E23 Dec,2018=3C/strong=3E=
=3C/p=3E --=3E
 =3Cp=3E=3Cstrong=3EShipping/Billing Address:=3C/strong=3E=3C/p=3E
 =3Cp=3EVaishali Kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East) =3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3Cp=3ELandmark: MAHARASHTRA=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b22ca1abba--</pre>
ERROR - 2019-01-13 12:36:50 --> Sending Email to admin_email || Subject: New order #ORD0049 has been placed.||  Message: ,  || TEMPLATE: email_template/admin_order_success
ERROR - 2019-01-13 12:36:50 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 12:36:50 --> CRIMINAL SUBJECTadmin_email || MESSAGE : <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 12 (filtered medium)">
<style>

 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Lucida Sans";
	panose-1:2 11 6 2 3 5 4 2 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#fff;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
span.EmailStyle17
	{mso-style-type:personal-reply;
	font-family:"Calibri","sans-serif";
	color:#1F497D;}
.MsoChpDefault
	{mso-style-type:export-only;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.Section1
	{page:Section1;}
.track_button
{
      background-color: rgb(209, 50, 49);
    border: medium none;
    border-radius: 0;
    color: #fff;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    padding: 13px 42px 14px;
    text-transform: uppercase;
    /*margin: 3px 339px;*/
}

</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1" />
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US link=blue vlink=purple>

<div class=Section1>



<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<div>

<div>

<p class=MsoNormal><span style='font-family:"Verdana","sans-serif";color:#0B5394'><o:p>&nbsp;</o:p></span></p>

</div>

<div>

<div>

<div>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%"
 style='width:100.0%;background:#F2F2F2'>
 <tr>
  <td valign=top style='padding:22.5pt 15.0pt 22.5pt 15.0pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="90%"
   style='width:90.0%;'>
   <tr>
    <td valign=top style='border:solid #DADADA 1.0pt;background:white;
    padding:22.5pt 22.5pt 22.5pt 22.5pt'>
    <div>
    <p class=MsoNormal style='margin-bottom:12.0pt;line-height:18.0pt'><span
    style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif";color:#222222'>Dear Admin,
     <br>
     An Order has been placed through your website for 0 item (Order No.:  ORD0049)
     <br>
    <br>
    <br>
    <a class="track_button" href="http://localhost/tsn/tsn/order-detail/ORD0049"> View Order Details here</a>
    <br>
    <div style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>
     <!--  Track your ticket here - -->
   <!--  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     style='border-collapse:collapse;display: inline-block;
    vertical-align: middle;'>
     <tr>
      <td style='border:solid #3B6E22 1.0pt;border-bottom:solid #2C5115 1.0pt;
      background:#69A74E;padding:0in 0in 0in 0in'>
      <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
       style='border-collapse:collapse'>
       <tr>
        <td style='padding:0in 0in 0in 0in'>
        <div style='border:none;border-top:solid #95BF82 1.0pt;padding:2.0pt 0in 0in 0in'>
        <p class=MsoNormal><span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'><a
        href="https://support.lancer.co.in/portal/ticket/1969" target="_blank"><span
        style='color:white'>View ticket</span></a><o:p></o:p></span></p>
        </div>
        </td>
       </tr>
      </table>
      </td>
     </tr>
    </table> -->



    <!--  <img src="http://localhost/stanley/care/v1/public/logo_image/nextasy_1.png"> -->
     <span style='font-size:10.5pt;font-family:"Lucida Sans","sans-serif"'>Thanks and regards, <br>
    TSN  </span></p>
    </div>
    </div>
    </td>
   </tr>
   <tr>
    <td valign=top style='padding:3.75pt 0in 0in 0in'>
    </td>
   </tr>
  </table>
  </td>
 </tr>
</table>

</div>

</div>

</div>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</div>

</body>

</html>

ERROR - 2019-01-13 12:36:50 --> CRIMINAL EMAIL{"useragent":"CodeIgniter","mailpath":"\/usr\/sbin\/sendmail","protocol":"smtp","smtp_host":"ssl:\/\/mail.transformsportsnutrition.com","smtp_user":"info@transformsportsnutrition.com","smtp_pass":"info@tsn2018","smtp_port":465,"smtp_timeout":5,"smtp_keepalive":false,"smtp_crypto":"","wordwrap":true,"wrapchars":76,"mailtype":"html","charset":"ISO-8859-1","alt_message":"","validate":false,"priority":3,"newline":"\r\n","crlf":"\n","dsn":false,"send_multipart":true,"bcc_batch_mode":false,"bcc_batch_size":200}
ERROR - 2019-01-13 12:36:50 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 12:36:50 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=23=4F=52=44=30=30=34=39=20?= =?ISO-8859-1?Q?=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=2E?=
To: admin_email
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b22d2b604c@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b22d2b607e&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b22d2b607e
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

&amp;nbsp;

&amp;nbsp;







 Dear Admin,

 An Order has been placed through your website for 0 item (Order No.:
ORD0049)



 View Order Details here






 Thanks and regards,
 TSN












&amp;nbsp;


--B_ALT_5c3b22d2b607e
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3Chtml xmlns:v=3D=22urn:schemas-microsoft-com:vml=22 xmlns:o=3D=22urn:sche=
mas-microsoft-com:office:office=22 xmlns:w=3D=22urn:schemas-microsoft-com:o=
ffice:word=22 xmlns:m=3D=22http://schemas.microsoft.com/office/2004/12/omml=
=22 xmlns=3D=22http://www.w3.org/TR/REC-html40=22=3E

=3Chead=3E
=3Cmeta http-equiv=3DContent-Type content=3D=22text/html=3B charset=3Dutf-8=
=22=3E
=3Cmeta name=3DGenerator content=3D=22Microsoft Word 12 (filtered medium)=
=22=3E
=3Cstyle=3E

 /=2A Font Definitions =2A/
 =40font-face
	=7Bfont-family:=22Cambria Math=22=3B
	panose-1:0 0 0 0 0 0 0 0 0 0=3B=7D
=40font-face
	=7Bfont-family:Calibri=3B
	panose-1:2 15 5 2 2 2 4 3 2 4=3B=7D
=40font-face
	=7Bfont-family:Tahoma=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
=40font-face
	=7Bfont-family:=22Lucida Sans=22=3B
	panose-1:2 11 6 2 3 5 4 2 2 4=3B=7D
=40font-face
	=7Bfont-family:Verdana=3B
	panose-1:2 11 6 4 3 5 4 4 2 4=3B=7D
 /=2A Style Definitions =2A/
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	=7Bmargin:0in=3B
	margin-bottom:.0001pt=3B
	font-size:12.0pt=3B
	font-family:=22Times New Roman=22,=22serif=22=3B=7D
a:link, span.MsoHyperlink
	=7Bmso-style-priority:99=3B
	color:=23fff=3B
	text-decoration:underline=3B=7D
a:visited, span.MsoHyperlinkFollowed
	=7Bmso-style-priority:99=3B
	color:purple=3B
	text-decoration:underline=3B=7D
span.EmailStyle17
	=7Bmso-style-type:personal-reply=3B
	font-family:=22Calibri=22,=22sans-serif=22=3B
	color:=231F497D=3B=7D
.MsoChpDefault
	=7Bmso-style-type:export-only=3B=7D
=40page Section1
	=7Bsize:8.5in 11.0in=3B
	margin:1.0in 1.0in 1.0in 1.0in=3B=7D
div.Section1
	=7Bpage:Section1=3B=7D
.track=5Fbutton
=7B
 background-color: rgb(209, 50, 49)=3B
 border: medium none=3B
 border-radius: 0=3B
 color: =23fff=3B
 cursor: pointer=3B
 font-size: 13px=3B
 font-weight: 500=3B
 padding: 13px 42px 14px=3B
 text-transform: uppercase=3B
 /=2Amargin: 3px 339px=3B=2A/
=7D

=3C/style=3E
=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapedefaults v:ext=3D=22edit=22 spidmax=3D=221026=22 /=3E
=3C/xml=3E=3C=21=5Bendif=5D--=3E=3C=21--=5Bif gte mso 9=5D=3E=3Cxml=3E
 =3Co:shapelayout v:ext=3D=22edit=22=3E
 =3Co:idmap v:ext=3D=22edit=22 data=3D=221=22 /=3E
 =3C/o:shapelayout=3E=3C/xml=3E=3C=21=5Bendif=5D--=3E
=3C/head=3E

=3Cbody lang=3DEN-US link=3Dblue vlink=3Dpurple=3E

=3Cdiv class=3DSection1=3E



=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-family:=22Verdana=22,=22sans=
-serif=22=3Bcolor:=230B5394'=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/span=3E=3C/=
p=3E

=3C/div=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv=3E

=3Cdiv align=3Dcenter=3E

=3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0 =
width=3D=22100=25=22
 style=3D'width:100.0=25=3Bbackground:=23F2F2F2'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:22.5pt 15.0pt 22.5pt 15.0pt'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0=
 width=3D=2290=25=22
 style=3D'width:90.0=25=3B'=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'border:solid =23DADADA 1.0pt=3Bbackground:whit=
e=3B
 padding:22.5pt 22.5pt 22.5pt 22.5pt'=3E
 =3Cdiv=3E
 =3Cp class=3DMsoNormal style=3D'margin-bottom:12.0pt=3Bline-height:18.0pt'=
=3E=3Cspan
 style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-serif=22=
=3Bcolor:=23222222'=3EDear Admin,
 =3Cbr=3E
 An Order has been placed through your website for 0 item (Order No.: ORD00=
49)
 =3Cbr=3E
 =3Cbr=3E
 =3Cbr=3E
 =3Ca class=3D=22track=5Fbutton=22 href=3D=22http://localhost/tsn/tsn/order=
-detail/ORD0049=22=3E View Order Details here=3C/a=3E
 =3Cbr=3E
 =3Cdiv style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-s=
erif=22'=3E
 =3C=21-- Track your ticket here - --=3E
 =3C=21-- =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpa=
dding=3D0
 style=3D'border-collapse:collapse=3Bdisplay: inline-block=3B
 vertical-align: middle=3B'=3E
 =3Ctr=3E
 =3Ctd style=3D'border:solid =233B6E22 1.0pt=3Bborder-bottom:solid =232C511=
5 1.0pt=3B
 background:=2369A74E=3Bpadding:0in 0in 0in 0in'=3E
 =3Ctable class=3DMsoNormalTable border=3D0 cellspacing=3D0 cellpadding=3D0
 style=3D'border-collapse:collapse'=3E
 =3Ctr=3E
 =3Ctd style=3D'padding:0in 0in 0in 0in'=3E
 =3Cdiv style=3D'border:none=3Bborder-top:solid =2395BF82 1.0pt=3Bpadding:2=
.0pt 0in 0in 0in'=3E
 =3Cp class=3DMsoNormal=3E=3Cspan style=3D'font-size:10.5pt=3Bfont-family:=
=22Lucida Sans=22,=22sans-serif=22'=3E=3Ca
 href=3D=22https://support.lancer.co.in/portal/ticket/1969=22 target=3D=22=
=5Fblank=22=3E=3Cspan
 style=3D'color:white'=3EView ticket=3C/span=3E=3C/a=3E=3Co:p=3E=3C/o:p=3E=
=3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E --=3E



 =3C=21-- =3Cimg src=3D=22http://localhost/stanley/care/v1/public/logo=5Fim=
age/nextasy=5F1.png=22=3E --=3E
 =3Cspan style=3D'font-size:10.5pt=3Bfont-family:=22Lucida Sans=22,=22sans-=
serif=22'=3EThanks and regards, =3Cbr=3E
 TSN =3C/span=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
 =3C/td=3E
 =3C/tr=3E
 =3Ctr=3E
 =3Ctd valign=3Dtop style=3D'padding:3.75pt 0in 0in 0in'=3E
 =3C/td=3E
 =3C/tr=3E
 =3C/table=3E
 =3C/td=3E
 =3C/tr=3E
=3C/table=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3C/div=3E

=3Cp class=3DMsoNormal=3E=3Co:p=3E=26nbsp=3B=3C/o:p=3E=3C/p=3E

=3C/div=3E

=3C/div=3E

=3C/body=3E

=3C/html=3E

--B_ALT_5c3b22d2b607e--</pre>
ERROR - 2019-01-13 12:36:50 --> Severity: Warning --> fgets(): SSL operation failed with code 1. OpenSSL Error messages:
error:0607A082:digital envelope routines:EVP_CIPHER_CTX_set_key_length:invalid key length D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 13:58:50 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 10
ERROR - 2019-01-13 13:59:03 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 189
ERROR - 2019-01-13 13:59:03 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 190
ERROR - 2019-01-13 13:59:03 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 191
ERROR - 2019-01-13 13:59:03 --> Severity: Notice --> Undefined property: Order::$content_model D:\xampp\htdocs\tsn\tsn\system\core\Model.php 77
ERROR - 2019-01-13 13:59:03 --> Severity: error --> Exception: Call to a member function getContent() on null D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 193
ERROR - 2019-01-13 13:59:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\tsn\tsn\system\core\Exceptions.php:271) D:\xampp\htdocs\tsn\tsn\system\core\Common.php 570
ERROR - 2019-01-13 14:10:30 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\tsn\tsn\application\models\Content_model.php 30
ERROR - 2019-01-13 14:10:44 --> Severity: Notice --> Undefined property: Order::$content_model D:\xampp\htdocs\tsn\tsn\system\core\Model.php 77
ERROR - 2019-01-13 14:10:44 --> Severity: error --> Exception: Call to a member function getContent() on null D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 194
ERROR - 2019-01-13 14:11:10 --> Sending Email to vaishalikasar13@gmail.com || Subject: hi||  Message: hi
ERROR - 2019-01-13 14:11:10 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:11:10 --> Severity: Notice --> Undefined index: email D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 50
ERROR - 2019-01-13 14:11:10 --> Severity: Notice --> Undefined index: email D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 51
ERROR - 2019-01-13 14:13:18 --> Sending Email to vaishalikasar13@gmail.com || Subject: hi||  Message: hi
ERROR - 2019-01-13 14:13:18 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:13:18 --> Severity: Notice --> Undefined index: email D:\xampp\htdocs\tsn\tsn\application\models\Home_model.php 50
ERROR - 2019-01-13 14:13:30 --> Sending Email to vaishalikasar13@gmail.com || Subject: hi||  Message: hi
ERROR - 2019-01-13 14:13:30 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:13:30 --> CRIMINAL SUBJECThi || MESSAGE : hi
ERROR - 2019-01-13 14:13:30 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:16:34 --> Sending Email to vaishalikasar13@gmail.com || Subject: hi||  Message: hi
ERROR - 2019-01-13 14:16:34 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:16:34 --> CRIMINAL SUBJECThi || MESSAGE : hi
ERROR - 2019-01-13 14:16:34 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:16:41 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 13:16:21 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gifck-003KTE-6Q
</pre>The following SMTP error was encountered: 250 OK id=1gifck-003KTE-6Q
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 14:16:34 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=68=69?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b3a3298d39@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b3a3298d60&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b3a3298d60
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

hi


--B_ALT_5c3b3a3298d60
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

hi

--B_ALT_5c3b3a3298d60--</pre>
ERROR - 2019-01-13 14:18:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:18:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:18:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:19:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:19:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:19:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:19:17 --> Sending Email to vaishalikasar13@gmail.com || Subject: ||  Message: 
ERROR - 2019-01-13 14:19:17 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:19:17 --> CRIMINAL SUBJECT || MESSAGE : 
ERROR - 2019-01-13 14:19:17 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:20:00 --> Sending Email to vaishalikasar13@gmail.com || Subject: ||  Message: 
ERROR - 2019-01-13 14:20:00 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:20:00 --> CRIMINAL SUBJECT || MESSAGE : 
ERROR - 2019-01-13 14:20:00 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:21:25 --> Sending Email to vaishalikasar13@gmail.com || Subject: ||  Message: 
ERROR - 2019-01-13 14:21:25 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:21:25 --> CRIMINAL SUBJECT || MESSAGE : 
ERROR - 2019-01-13 14:21:25 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:23:16 --> Severity: Notice --> Undefined variable: subject D:\xampp\htdocs\tsn\tsn\application\models\Content_model.php 19
ERROR - 2019-01-13 14:23:16 --> Sending Email to vaishalikasar13@gmail.com || Subject: ||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0059 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:23:16 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:23:16 --> CRIMINAL SUBJECT || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0059 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:23:16 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:23:31 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 13:23:03 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: </pre>The following SMTP error was encountered: <br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 14:23:16 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q??=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b3bc4ec0e5@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b3bc4ec0fc&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b3bc4ec0fc
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at %WEBSITE_NAME%.Your order ORD0059 has been
confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b3bc4ec0fc
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at =25WEBSITE=5FNAME=25.Your order ORD0059 h=
as been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b3bc4ec0fc--</pre>
ERROR - 2019-01-13 14:25:23 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0060 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0060 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:25:23 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:25:23 --> CRIMINAL SUBJECTYour order #ORD0060 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0060 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:25:23 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:25:32 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 13:25:09 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1giflG-003Xyi-N1
</pre>The following SMTP error was encountered: 250 OK id=1giflG-003Xyi-N1
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 14:25:23 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=30?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b3c4324a84@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b3c4324a9e&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b3c4324a9e
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at %WEBSITE_NAME%.Your order ORD0060 has been
confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b3c4324a9e
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at =25WEBSITE=5FNAME=25.Your order ORD0060 h=
as been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b3c4324a9e--</pre>
ERROR - 2019-01-13 14:25:51 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0061 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0061 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:25:51 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:25:51 --> CRIMINAL SUBJECTYour order #ORD0061 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order ORD0061 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:25:51 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:25:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:25:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 14:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 14:29:45 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0062 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0062 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:29:45 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 14:29:45 --> CRIMINAL SUBJECTYour order #ORD0062 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0062 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 14:29:45 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 14:29:53 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 13:29:31 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gifpU-003b68-OP
</pre>The following SMTP error was encountered: 250 OK id=1gifpU-003b68-OP
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 14:29:45 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=32?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b3d4914cdc@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b3d4914cef&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b3d4914cef
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0062 has
been confirmed.
 Amount: RS. 10
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b3d4914cef
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0062 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 10=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b3d4914cef--</pre>
ERROR - 2019-01-13 18:00:21 --> Query error: Column 'ord_prs_id' cannot be null - Invalid query: INSERT INTO `person_order` (`ord_reference_no`, `ord_prs_id`, `ord_delivery_adddress`, `ord_payment_mode`, `ord_sub_total`, `ord_shipping_charges`, `ord_update_sent_mobile`, `ord_update_sent_email`, `ord_total_amt`, `ord_date`, `ord_status`, `ord_crtd_dt`, `ord_crtd_by`) VALUES ('ORD0063', NULL, '4', '1', 0, NULL, '8655385802', NULL, 0, '2019-01-13', 1, '2019-01-13 18:00:21', NULL)
ERROR - 2019-01-13 18:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:52 -->  check login ref = http://localhost/tsn/tsn/address-select
ERROR - 2019-01-13 18:00:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:00:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:00:57 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0063 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0063 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:00:57 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:00:57 --> CRIMINAL SUBJECTYour order #ORD0063 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0063 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:00:57 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:01:08 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:00:45 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gij7u-003E7Z-EF
</pre>The following SMTP error was encountered: 250 OK id=1gij7u-003E7Z-EF
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:00:57 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=33?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b6ec9f084f@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b6ec9f087d&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b6ec9f087d
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0063 has
been confirmed.
 Amount: RS. 1600
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b6ec9f087d
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0063 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 1600=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b6ec9f087d--</pre>
ERROR - 2019-01-13 18:01:58 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0064 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0064 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:01:58 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:01:58 --> CRIMINAL SUBJECTYour order #ORD0064 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0064 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:01:58 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:02:08 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:01:44 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gij8r-003Kgs-UJ
</pre>The following SMTP error was encountered: 250 OK id=1gij8r-003Kgs-UJ
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:01:58 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=34?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b6f06346a9@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b6f06346dd&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b6f06346dd
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0064 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b6f06346dd
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0064 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b6f06346dd--</pre>
ERROR - 2019-01-13 18:15:09 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\tsn\tsn\application\models\Order_model.php 197
ERROR - 2019-01-13 18:15:47 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0065 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0065 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:15:47 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:15:47 --> CRIMINAL SUBJECTYour order #ORD0065 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0065 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:15:47 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:15:55 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:15:33 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijME-003e68-Kv
</pre>The following SMTP error was encountered: 250 OK id=1gijME-003e68-Kv
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:15:47 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=35?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b724325878@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b724325898&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b724325898
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0065 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b724325898
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0065 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b724325898--</pre>
ERROR - 2019-01-13 18:15:55 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0065">View Order</></strong>
ERROR - 2019-01-13 18:15:55 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:15:55 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0065">View Order</></strong>
ERROR - 2019-01-13 18:15:55 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:15:55 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:15:55 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b724be2780@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b724be27c7&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b724be27c7
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b724be27c7
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0065=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b724be27c7--</pre>
ERROR - 2019-01-13 18:15:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:58 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:15:59 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:00 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:00 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:00 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:01 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:02 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:02 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 18:16:30 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0066 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0066 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:16:30 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:16:30 --> CRIMINAL SUBJECTYour order #ORD0066 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0066 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:16:30 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:16:39 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:16:16 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijMw-003iiW-C4
</pre>The following SMTP error was encountered: 250 OK id=1gijMw-003iiW-C4
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:16:30 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=36?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b726eda77b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b726eda7ab&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b726eda7ab
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0066 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b726eda7ab
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0066 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b726eda7ab--</pre>
ERROR - 2019-01-13 18:16:39 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0066">View Order</></strong>
ERROR - 2019-01-13 18:16:39 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:16:39 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0066">View Order</></strong>
ERROR - 2019-01-13 18:16:39 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:16:39 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:16:39 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b7277863d2@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b727786407&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b727786407
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b727786407
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0066=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b727786407--</pre>
ERROR - 2019-01-13 18:16:39 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:40 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:40 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:40 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:40 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:41 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:41 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:41 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:41 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:42 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:42 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:42 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:42 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:43 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:43 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:43 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:44 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:45 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:16:45 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 18:17:12 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0067 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0067 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:17:12 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:17:12 --> CRIMINAL SUBJECTYour order #ORD0067 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0067 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:17:12 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:17:21 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:16:59 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijNc-003nQK-LP
</pre>The following SMTP error was encountered: 250 OK id=1gijNc-003nQK-LP
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:17:12 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=37?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b7298812c3@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b7298812fc&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b7298812fc
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0067 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b7298812fc
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0067 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b7298812fc--</pre>
ERROR - 2019-01-13 18:17:21 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0067">View Order</></strong>
ERROR - 2019-01-13 18:17:21 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:17:21 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0067">View Order</></strong>
ERROR - 2019-01-13 18:17:21 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:17:21 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:17:21 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b72a1e5468@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b72a1e5486&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b72a1e5486
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b72a1e5486
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0067=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b72a1e5486--</pre>
ERROR - 2019-01-13 18:17:22 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:22 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:22 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:22 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:23 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:24 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:25 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:26 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:27 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:28 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:17:28 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 18:20:24 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0068 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0068 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:20:24 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:20:24 --> CRIMINAL SUBJECTYour order #ORD0068 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0068 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:20:24 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:20:26 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:20:26 --> Severity: Warning --> fsockopen(): unable to connect to ssl://ssl://mail.transformsportsnutrition.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:20:26 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 0 php_network_getaddresses: getaddrinfo failed: No such host is known. <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:20:24 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=38?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b73582cea7@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b73582ced6&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b73582ced6
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0068 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b73582ced6
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0068 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b73582ced6--</pre>
ERROR - 2019-01-13 18:20:26 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0068">View Order</></strong>
ERROR - 2019-01-13 18:20:26 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:20:26 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0068">View Order</></strong>
ERROR - 2019-01-13 18:20:26 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:20:29 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:20:29 --> Severity: Warning --> fsockopen(): unable to connect to ssl://ssl://mail.transformsportsnutrition.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:20:29 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 0 php_network_getaddresses: getaddrinfo failed: No such host is known. <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:20:26 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b735abe634@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b735abe654&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b735abe654
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b735abe654
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0068=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b735abe654--</pre>
ERROR - 2019-01-13 18:23:58 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0069 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0069 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:23:58 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:23:58 --> CRIMINAL SUBJECTYour order #ORD0069 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0069 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:23:58 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:24:00 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:24:00 --> Severity: Warning --> fsockopen(): unable to connect to ssl://ssl://mail.transformsportsnutrition.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:24:00 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 0 php_network_getaddresses: getaddrinfo failed: No such host is known. <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:23:58 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=36=39?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b742e49fb7@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b742e4a018&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b742e4a018
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0069 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b742e4a018
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0069 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b742e4a018--</pre>
ERROR - 2019-01-13 18:24:01 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0069">View Order</></strong>
ERROR - 2019-01-13 18:24:01 --> Email configurations -- smtp -- ssl://mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:24:01 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0069">View Order</></strong>
ERROR - 2019-01-13 18:24:01 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:24:03 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:24:03 --> Severity: Warning --> fsockopen(): unable to connect to ssl://ssl://mail.transformsportsnutrition.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2055
ERROR - 2019-01-13 18:24:03 --> error occured in people insert Communication_model/send_mailThe following SMTP error was encountered: 0 php_network_getaddresses: getaddrinfo failed: No such host is known. <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:24:01 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b74312efb1@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b74312efcc&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b74312efcc
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b74312efcc
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0069=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b74312efcc--</pre>
ERROR - 2019-01-13 18:24:42 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0070 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0070 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:24:42 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:24:42 --> CRIMINAL SUBJECTYour order #ORD0070 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0070 has been confirmed.</p>
    <p>Amount: <strong>RS. 0</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:24:42 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:24:50 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:24:28 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijUr-003x2N-Sp
</pre>The following SMTP error was encountered: 250 OK id=1gijUr-003x2N-Sp
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:24:42 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=30?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b745a0b707@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b745a0b728&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b745a0b728
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0070 has
been confirmed.
 Amount: RS. 0
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b745a0b728
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

=3C=21DOCTYPE html=3E
=3Chtml=3E
=3Chead=3E
 =3Cstyle type=3D=22text/css=22=3E
 body =7B
 color: =234d4d4d=3B
 font-family: Montserrat,sans-serif,Helvetica,Arial=3B
 =7D

 .content =7B
 border: 1px solid =23eaeaec=3B
 box-shadow: 0 0 4px rgba(40,44,63,.08)=3B
 max-width: 640px=3B
 margin: 0 auto=3B
 =7D
 .header,.info =7B
 padding: 15px=3B
 border-bottom: 2px solid =23eaeaec=3B
 =7D
 h3 =7B
 font-size: 20px=3B
 font-weight: bold=3B
 margin: 5px 0 2px 0=3B
 =7D
 .line =7B
 border-bottom-width: 4px=3B
 border-bottom-color: rgb(209, 50, 49)=3B
 border-bottom-style: solid=3B
 line-height: 1.5=3B
 display: inline-block=3B
 =7D
 p=7B
 margin: 10px 0=3B
 =7D
 =3C/style=3E
=3C/head=3E
=3Cbody =3E
=3Cdiv class=3D=22content=22=3E
 =3Cdiv class=3D=22header=22=3E
 =3Cimg src=3D=22https://transformsportsnutrition.com/assets/images/logo.pn=
g=22=3E
 =3C/div=3E=20
 =3Cdiv class=3D=22info=22=3E
 =3Ch3=3EOrder=3C/h3=3E
 =3Ch3 class=3D=22line=22=3EConfirmed=3C/h3=3E=20
 =3Cdiv class=3D=22temp=22=3E
 =3Cp=3EHey vaishali kasar,=3C/p=3E
 =3Cp=3EThank you for shopping at Transform Sports Nutrition.Your order ORD=
0070 has been confirmed.=3C/p=3E
 =3Cp=3EAmount: =3Cstrong=3ERS. 0=3C/strong=3E=3C/p=3E
 =3Cp=3Evaishali kasar=3C/p=3E
=3Cp=3EE wing, 702 Mandakini building rawalpada dahisar(East)=3C/p=3E
=3Cp=3E298 last stop =3C/p=3E
=3Cp=3Emumbai- 400068 =3C/p=3E=3C/p=3E
 =3C/div=3E
 =3C/div=3E
=3C/div=3E
=3C/body=3E
=3C/html=3E

--B_ALT_5c3b745a0b728--</pre>
ERROR - 2019-01-13 18:24:50 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0070">View Order</></strong>
ERROR - 2019-01-13 18:24:50 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:24:50 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0070">View Order</></strong>
ERROR - 2019-01-13 18:24:50 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:24:50 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:24:50 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b7462d7386@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b7462d73c1&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b7462d73c1
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b7462d73c1
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,=3Cbr=3E=3Cbr=3E
	New order has been placed=3Cbr=3E
	Link: =3Cstrong=3E=3Ca href=3D=22https://transformsportsnutrition.com/app/=
ordersORD0070=22=3EView Order=3C/=3E=3C/strong=3E

--B_ALT_5c3b7462d73c1--</pre>
ERROR - 2019-01-13 18:24:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:51 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:52 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:53 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:54 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:55 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:56 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:57 --> Severity: Warning --> fwrite(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2242
ERROR - 2019-01-13 18:24:57 --> Severity: Warning --> fgets(): SSL: The operation completed successfully.
 D:\xampp\htdocs\tsn\tsn\system\libraries\Email.php 2288
ERROR - 2019-01-13 18:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:26:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:27:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:15 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0071 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0071 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:27:15 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:27:15 --> CRIMINAL SUBJECTYour order #ORD0071 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0071 has been confirmed.</p>
    <p>Amount: <strong>RS. 1600</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:27:15 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:27:23 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:27:01 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijXK-003z9n-SN
</pre>The following SMTP error was encountered: 250 OK id=1gijXK-003z9n-SN
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:27:15 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=31?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b74f332e7b@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b74f332eee&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b74f332eee
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0071 has
been confirmed.
 Amount: RS. 1600
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b74f332eee
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

&lt;!DOCTYPE html&gt;=0A&lt;html&gt;=0A&lt;head&gt;=0A &lt;style type=3D&quot;text/css&quot;&gt;=0A  body {=
=0A    color: #4d4d4d;=0A    font-family: Montserrat,sans-serif,Helvetica,A=
rial;=0A  }=0A=0A    .content {=0A      border: 1px solid #eaeaec;=0A    bo=
x-shadow: 0 0 4px rgba(40,44,63,.08);=0A    max-width: 640px;=0A        mar=
gin: 0 auto;=0A    }=0A    .header,.info {=0A      padding: 15px;=0A      b=
order-bottom: 2px solid #eaeaec;=0A    }=0A    h3 {=0A      font-size: 20px=
;=0A      font-weight: bold;=0A      margin: 5px 0 2px 0;=0A    }=0A    .li=
ne {=0A          border-bottom-width: 4px;=0A    border-bottom-color: rgb(2=
09, 50, 49);=0A    border-bottom-style: solid;=0A    line-height: 1.5;=0A  =
  display: inline-block;=0A    }=0A    p{=0A      margin: 10px 0;=0A      }=
=0A  &lt;/style&gt;=0A&lt;/head&gt;=0A&lt;body &gt;=0A&lt;div class=3D&quot;content&quot;&gt;=0A  &lt;div class=
=3D&quot;header&quot;&gt;=0A    &lt;img src=3D&quot;https://transformsportsnutrition.com/assets/=
images/logo.png&quot;&gt;=0A  &lt;/div&gt;  =0A  &lt;div class=3D&quot;info&quot;&gt;=0A  &lt;h3&gt;Order&lt;/h3&gt;=
=0A  &lt;h3 class=3D&quot;line&quot;&gt;Confirmed&lt;/h3&gt; =0A  &lt;div class=3D&quot;temp&quot;&gt;=0A    &lt;p&gt;H=
ey vaishali kasar,&lt;/p&gt;=0A    &lt;p&gt;Thank you for shopping at Transform Sports =
Nutrition.Your order ORD0071 has been confirmed.&lt;/p&gt;=0A    &lt;p&gt;Amount: &lt;stro=
ng&gt;RS. 1600&lt;/strong&gt;&lt;/p&gt;=0A    &lt;p&gt;vaishali kasar&lt;/p&gt;=0A&lt;p&gt;E wing, 702 Manda=
kini  building rawalpada dahisar(East)&lt;/p&gt;=0A&lt;p&gt;298 last stop &lt;/p&gt;=0A&lt;p&gt;mum=
bai- 400068 &lt;/p&gt;&lt;/p&gt;=0A  &lt;/div&gt;=0A  &lt;/div&gt;=0A&lt;/div&gt;=0A&lt;/body&gt;=0A&lt;/html&gt;

--B_ALT_5c3b74f332eee--</pre>
ERROR - 2019-01-13 18:27:23 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0071">View Order</></strong>
ERROR - 2019-01-13 18:27:23 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:27:23 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0071">View Order</></strong>
ERROR - 2019-01-13 18:27:23 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:27:23 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:27:23 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b74fbe8971@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b74fbe89c0&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b74fbe89c0
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b74fbe89c0
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,&lt;br&gt;&lt;br&gt;=0A=09New order has been placed&lt;br&gt;=0A=09Link: &lt;strong&gt;&lt;a =
href=3D&quot;https://transformsportsnutrition.com/app/ordersORD0071&quot;&gt;View Order&lt;=
/&gt;&lt;/strong&gt;

--B_ALT_5c3b74fbe89c0--</pre>
ERROR - 2019-01-13 18:27:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:27:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:27:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-13 18:28:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-01-13 18:28:31 --> Sending Email to vaishalikasar13@gmail.com || Subject: Your order #ORD0072 has been placed successfully||  Message: <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0072 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:28:31 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:28:31 --> CRIMINAL SUBJECTYour order #ORD0072 has been placed successfully || MESSAGE : <!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey vaishali kasar,</p>
    <p>Thank you for shopping at Transform Sports Nutrition.Your order ORD0072 has been confirmed.</p>
    <p>Amount: <strong>RS. 10</strong></p>
    <p>vaishali kasar</p>
<p>E wing, 702 Mandakini  building rawalpada dahisar(East)</p>
<p>298 last stop </p>
<p>mumbai- 400068 </p></p>
  </div>
  </div>
</div>
</body>
</html>
ERROR - 2019-01-13 18:28:31 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:28:40 --> error occured in people insert Communication_model/send_mail220-md-in-40.webhostbox.net ESMTP Exim 4.91 #1 Sun, 13 Jan 2019 17:28:17 +0000 
220-We do not authorize the use of this system to transport unsolicited, 
220 and/or bulk e-mail.
<br /><pre>hello: 250-md-in-40.webhostbox.net Hello localhost [1.23.90.130]
250-SIZE 52428800
250-8BITMIME
250-PIPELINING
250-AUTH PLAIN LOGIN
250 HELP
</pre><pre>from: 250 OK
</pre><pre>to: 250 Accepted
</pre><pre>data: 354 Enter message, ending with "." on a line by itself
</pre><br /><pre>quit: 250 OK id=1gijYZ-0040A3-8h
</pre>The following SMTP error was encountered: 250 OK id=1gijYZ-0040A3-8h
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:28:31 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=59=6F=75=72=20=6F=72=64=65=72=20=23=4F=52=44=30=30=37=32?= =?ISO-8859-1?Q?=20=68=61=73=20=62=65=65=6E=20=70=6C=61=63=65=64=20=73=75?= =?ISO-8859-1?Q?=63=63=65=73=73=66=75=6C=6C=79?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b753f96525@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b753f965c9&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b753f965c9
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Order
 Confirmed

 Hey vaishali kasar,
 Thank you for shopping at Transform Sports Nutrition.Your order ORD0072 has
been confirmed.
 Amount: RS. 10
 vaishali kasar
E wing, 702 Mandakini building rawalpada dahisar(East)
298 last stop
mumbai- 400068


--B_ALT_5c3b753f965c9
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

&lt;!DOCTYPE html&gt;=0A&lt;html&gt;=0A&lt;head&gt;=0A &lt;style type=3D&quot;text/css&quot;&gt;=0A  body {=
=0A    color: #4d4d4d;=0A    font-family: Montserrat,sans-serif,Helvetica,A=
rial;=0A  }=0A=0A    .content {=0A      border: 1px solid #eaeaec;=0A    bo=
x-shadow: 0 0 4px rgba(40,44,63,.08);=0A    max-width: 640px;=0A        mar=
gin: 0 auto;=0A    }=0A    .header,.info {=0A      padding: 15px;=0A      b=
order-bottom: 2px solid #eaeaec;=0A    }=0A    h3 {=0A      font-size: 20px=
;=0A      font-weight: bold;=0A      margin: 5px 0 2px 0;=0A    }=0A    .li=
ne {=0A          border-bottom-width: 4px;=0A    border-bottom-color: rgb(2=
09, 50, 49);=0A    border-bottom-style: solid;=0A    line-height: 1.5;=0A  =
  display: inline-block;=0A    }=0A    p{=0A      margin: 10px 0;=0A      }=
=0A  &lt;/style&gt;=0A&lt;/head&gt;=0A&lt;body &gt;=0A&lt;div class=3D&quot;content&quot;&gt;=0A  &lt;div class=
=3D&quot;header&quot;&gt;=0A    &lt;img src=3D&quot;https://transformsportsnutrition.com/assets/=
images/logo.png&quot;&gt;=0A  &lt;/div&gt;  =0A  &lt;div class=3D&quot;info&quot;&gt;=0A  &lt;h3&gt;Order&lt;/h3&gt;=
=0A  &lt;h3 class=3D&quot;line&quot;&gt;Confirmed&lt;/h3&gt; =0A  &lt;div class=3D&quot;temp&quot;&gt;=0A    &lt;p&gt;H=
ey vaishali kasar,&lt;/p&gt;=0A    &lt;p&gt;Thank you for shopping at Transform Sports =
Nutrition.Your order ORD0072 has been confirmed.&lt;/p&gt;=0A    &lt;p&gt;Amount: &lt;stro=
ng&gt;RS. 10&lt;/strong&gt;&lt;/p&gt;=0A    &lt;p&gt;vaishali kasar&lt;/p&gt;=0A&lt;p&gt;E wing, 702 Mandaki=
ni  building rawalpada dahisar(East)&lt;/p&gt;=0A&lt;p&gt;298 last stop &lt;/p&gt;=0A&lt;p&gt;mumba=
i- 400068 &lt;/p&gt;&lt;/p&gt;=0A  &lt;/div&gt;=0A  &lt;/div&gt;=0A&lt;/div&gt;=0A&lt;/body&gt;=0A&lt;/html&gt;

--B_ALT_5c3b753f965c9--</pre>
ERROR - 2019-01-13 18:28:40 --> Sending Email to vaishalikasar13@gmail.com || Subject: New order %ORDER_NUMBER% has placed.||  Message: Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0072">View Order</></strong>
ERROR - 2019-01-13 18:28:40 --> Email configurations -- smtp -- mail.transformsportsnutrition.com -- info@transformsportsnutrition.com -- info@tsn2018 -- html -- iso-8859-1 -- 1
ERROR - 2019-01-13 18:28:40 --> CRIMINAL SUBJECTNew order %ORDER_NUMBER% has placed. || MESSAGE : Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="https://transformsportsnutrition.com/app/ordersORD0072">View Order</></strong>
ERROR - 2019-01-13 18:28:40 --> CRIMINAL EMAIL"vaishalikasar13@gmail.com"
ERROR - 2019-01-13 18:28:40 --> error occured in people insert Communication_model/send_mailFailed to send AUTH LOGIN command. Error: 221 md-in-40.webhostbox.net closing connection
<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 13 Jan 2019 18:28:40 +0100
From: &quot;TSN&quot; &lt;info@transformsportsnutrition.com&gt;
Return-Path: &lt;info@transformsportsnutrition.com&gt;
Subject: =?ISO-8859-1?Q?=4E=65=77=20=6F=72=64=65=72=20=25=4F=52=44=45=52=5F=4E=55?= =?ISO-8859-1?Q?=4D=42=45=52=25=20=68=61=73=20=70=6C=61=63=65=64=2E?=
To: vaishalikasar13@gmail.com
Reply-To: &lt;info@transformsportsnutrition.com&gt;
User-Agent: CodeIgniter
X-Sender: info@transformsportsnutrition.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5c3b754807896@transformsportsnutrition.com&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_5c3b7548078ac&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5c3b7548078ac
Content-Type: text/plain; charset=ISO-8859-1
Content-Transfer-Encoding: 8bit

Hi Admin,
New order has been placed
Link: View Order


--B_ALT_5c3b7548078ac
Content-Type: text/html; charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

Hi Admin,&lt;br&gt;&lt;br&gt;=0A=09New order has been placed&lt;br&gt;=0A=09Link: &lt;strong&gt;&lt;a =
href=3D&quot;https://transformsportsnutrition.com/app/ordersORD0072&quot;&gt;View Order&lt;=
/&gt;&lt;/strong&gt;

--B_ALT_5c3b7548078ac--</pre>
