<?php
define('ADMIN_SUBJECT','TSN | Enquiry Received');
define('USER_SUBJECT','TSN | Thank you for contacting us');
// define('ADMIN_EMAIL','info@transformsportsnutrition.com');

/**************START COMMUNICATION VALUE **************/
define('ADMIN_EMAIL_VALUE', 'vaishalikasar13@gmail.com');
define('ADMIN_SMS_VALUE', '8655385802');
define('EUS_TYPE_EMAIL', 'email');
define('EUS_TYPE_SMS', 'sms'); 
define('EUS_USR_TYPE_USER', 'user');
define('EUS_USR_TYPE_ADMIN', 'admin'); 
define('ADMIN_EMAIL', 'admin_email');
define('ADMIN_CONTACT', 'admin_contact');
define('ADMIN_SOURCE_EMAIL', 'admin_source_email'); 
define('ADMIN_SOURCE_PASSWORD', 'admin_source_pw');
define('EUS_STATUS_ACTIVE', '1');
define('WEBSITE_NAME', 'Transform Sports Nutrition');
define('APP_LINK', 'https://transformsportsnutrition.com/app/');

/***************END COMMUNICATION VALUE************************/
define('EMAIL_PROTOCOL', 'smtp');
define('EMAIL_HOST', 'ssl://mail.transformsportsnutrition.com');
define('EMAIL_PORT', 465);
define('EMAIL_USERNAME', 'info@transformsportsnutrition.com');
define('EMAIL_PASSWORD', 'info@tsn2018');
define('EMAIL_TYPE', 'html');
define('EMAIL_CHARSET', 'iso-8859-1');
define('EMAIL_WORDWRAP', TRUE);

/***********************************************************
				START EMAIL TEMPLATES
************************************************************/

/*************************START USER PRODUCT OUT FOR DELIVERY**********/
define('USER_ORDER_PLACED_SUBJECT','Your order #%ORDER_NO% has been placed successfully');

define('USER_ORDER_PLACED_BODY','<!DOCTYPE html>
<html>
<head>
 <style type="text/css">
  body {
    color: #4d4d4d;
    font-family: Montserrat,sans-serif,Helvetica,Arial;
  }

    .content {
      border: 1px solid #eaeaec;
    box-shadow: 0 0 4px rgba(40,44,63,.08);
    max-width: 640px;
        margin: 0 auto;
    }
    .header,.info {
      padding: 15px;
      border-bottom: 2px solid #eaeaec;
    }
    h3 {
      font-size: 20px;
      font-weight: bold;
      margin: 5px 0 2px 0;
    }
    .line {
          border-bottom-width: 4px;
    border-bottom-color: rgb(209, 50, 49);
    border-bottom-style: solid;
    line-height: 1.5;
    display: inline-block;
    }
    p{
      margin: 10px 0;
      }
  </style>
</head>
<body >
<div class="content">
  <div class="header">
    <img src="https://transformsportsnutrition.com/assets/images/logo.png">
  </div>  
  <div class="info">
  <h3>Order</h3>
  <h3 class="line">Confirmed</h3> 
  <div class="temp">
    <p>Hey %RECEIVER_NAME%,</p>
    <p>Thank you for shopping at %WEBSITE_NAME%.Your order %ORDER_NUMBER% has been confirmed.</p>
    <p>Amount: <strong>RS. %AMOUNT%</strong></p>
    <p>%CUSTOMER_NAME%</p>
<p>%ADDRESS%</p>
<p>%LOCALITY% </p>
<p>%CITY%- %PINCODE% </p></p>
<p>You can view your order updates by clicking on below link: <br>
<a href="https://www.transformsportsnutrition.com/my-orders">https://www.transformsportsnutrition.com/my-orders</a>
</p>
<p>Follow us on Instagram for more offers and updates: <br>
    https://www.instagram.com/transformsportsnutrition/<br><br>Thank you, <br> Team %WEBSITE_NAME% <br></p>
  </div>
  </div>
</div>
</body>
</html>');

/*************************END USER PRODUCT OUT FOR DELIVERY**********/

/*************************START ADMIN PRODUCT STATUS CHANGED**********/

define('ADMIN_ORDER_PLACED_SUBJECT','New order %ORDER_NUMBER% has placed.');
define('ADMIN_ORDER_PLACED_BODY','Hi Admin,<br><br>
	New order has been placed<br>
	Link: <strong><a href="%ORDER_LINK%">View Order</></strong>');

/*************************END ADMIN PRODUCT STATUS CHANGED**********/


/***********************************************************
				END EMAIL TEMPLATES
************************************************************/

/***********************************************************
				START MSG TEMPLATES
************************************************************/

define('ORDER_PLACED_USER_MSG','Hi %RECEIVER_NAME%, Order Confirmed: ID %ORDER_NO%. Please check your email for more details. Thank you for shopping with Transform Sports Nutrition');

define('ORDER_PLACED_ADMIN_MSG','Hi Admin, New order has placed %ORDER_NO%. Please check your email for more details.');

/***********************************************************
				END MSG TEMPLATES
************************************************************/

?>