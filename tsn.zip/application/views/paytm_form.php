<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Merchant Check Out Page</title>
<meta name="GENERATOR" content="Evrsoft First Page">
</head>
<script>
    function submitPayuForm() {
      var paytmForm = document.forms.paytmForm;
      paytmForm.submit();
    } 
  </script>
 <body onload="submitPayuForm()">
 <h2> Please wait your transaction will start soon... </h2>
   <!--  <br/>
	<h1>Merchant Check Out Page</h1> -->
	<pre>
	</pre>
	<form method="post" name="paytmForm" id="paytmForm" action="<?php echo site_url('paytm/paytmpost') ?>">
		
				<input type="hidden" id="ORDER_ID" name="ORDER_ID"   value="<?php echo  $order->ord_reference_no; ?>">
				<input type="hidden" id="CUST_ID"  name="CUST_ID"    value="<?php echo  $order->ord_prs_id; ?>">
				<input type="hidden" id="MSISDN"  name="MSISDN"      value="<?php echo  $order->ord_prs_mob; ?>">
				<input type="hidden" id="EMAIL"  name="EMAIL"        value="<?php echo  $order->ord_prs_email; ?>">
		     	<input type="hidden" id="INDUSTRY_TYPE_ID" name="INDUSTRY_TYPE_ID"        value="Retail109">
				<input type="hidden" id="CHANNEL_ID"  name="CHANNEL_ID" 	              value="WEB">
				<input type="hidden" title="TXN_AMOUNT" type="text" name="TXN_AMOUNT"     value="<?php echo  $order->ord_total_amt; ?>">
				<input type="hidden" title="CALLBACK_URL" type="text" name="CALLBACK_URL" value="<?php echo  $order->callbckurl; ?>">
			<input type="hidden" value="CheckOut" type="submit" onclick="">
			
	</form>
</body>
</html>