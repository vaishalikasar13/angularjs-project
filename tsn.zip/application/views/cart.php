<?php $this->load->view('header');?>
	
		<!-- About Us Area Start -->
        <div class="about-us-area  pb-100">
            <div class="container">
                 <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li class="active">Cart</li>
                       </ul>
                </div>
                  <?php 
                    if(count($this->cart->contents()) > 0) {

                        ?>
               <div class="row">
                <div class="col-md-8 col-lg-8 col-sm-12">
                   <div class="cart-header">
                    <div class="my-cart-text">
                      <h3>My cart (<?php echo count($this->cart->contents());?> Items)</h3>  
                    </div>
                     <div class="my-cart-price">
                         <h3>Total: Rs. <?php echo $this->cart->total()?></h3>
                    </div>
                    </div>
                      <div class="prod-set">
                     <?php 

             
                $count = 0;
                $i=1;

            foreach ($this->cart->contents() as $items)
             {
              $count++;
              ?> 
                       <div class="prod-item">
                          <div class="col1">
                            <img src="<?php echo $items["image"]?>" alt="<?php echo $items["name"] ;?>" width="86" height="118">
                          </div> 
                          <div class="col2">
                            <div class="row m0">
                                <div class="col-md-7 col-lg-8 col-sm-12">
                                    <div class="prod-name"><?php echo $items["name"] ;?></div>  
                                    <div class="flavour-qty-wrap ptb5">
                                      <div class="flavour-qty">
                                          <span class="flv-drop"  href="#update_cart_modal" data-toggle="modal" s onclick="return updateCartModal('flavour',this);" data-cart_row='<?php echo $items["rowid"] ;?>' data-cart_flavour='<?php echo $items["flavour"] ;?>' data-cart_prd_id='<?php echo $items["id"] ;?>' data-cart_qty='<?php echo $items["qty"] ;?>'>
                                             <span>Flavour: </span> 
                                              <span><?php echo $items["flavour_name"] ;?> </span> 
                                              <span><img src="<?php echo base_url();?>assets/images/caret-down.png"></span>
                                          </span>
                                          <span class="qty-drop"  href="#update_cart_modal" data-toggle="modal"  onclick="return updateCartModal('qty',this);" data-cart_row='<?php echo $items["rowid"] ;?>' data-cart_flavour='<?php echo $items["flavour"] ;?>' data-cart_prd_id='<?php echo $items["id"] ;?>' data-cart_qty='<?php echo $items["qty"] ;?>'>
                                             <span>Qty: </span> 
                                              <span><?php echo $items["qty"] ;?> </span> 
                                              <span><img src="<?php echo base_url();?>assets/images/caret-down.png"></span>
                                          </span>
                                      </div>  
                                    </div>
                                    <div class="edit-move-delete"  id="remove_cart_product"  data-cart_row='<?php echo $items["rowid"] ;?>'><div class="actions"><span class="confirm-delete-item"><span class="text m-gray confirm-delete-item tappable">REMOVE</span></span></div></div>
                                </div>
                                 <div class="col-md-4 col-lg-4 col-sm-12">
                                    <div class="prod-price">Rs. <?php echo $items["price"] ;?></div> 
                                </div>
                                
                            </div>
                         </div>
                       </div> 
                        
                    <?php
          $i++;
           } 
          
          ?>
           </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-12">
                 <div class="grand-totall">
                                   <div class="title-wrap">
                                        <h4 class="cart-bottom-title section-bg-gary-cart">Cart Details</h4>
                                    </div>
                                    <h5>Cart total <span>Rs. <?php echo $this->cart->total()?></span></h5>
                                      <h5 class="border-bottom">Delivery<span>Free</span></h5>
                                     <div class="cart-footer">  
                                      <h5>Order Total<span>Rs. <?php echo $this->cart->total()?></span></h5>
                                       <a class="place-order" href="<?php echo base_url('address-select'); ?>">Checkout</a>
                                   </div>
                                </div>  
                </div>
                   
               </div>
                 <?php } else {
                    echo "<h3 class='page-title empty-cart' >Your Cart is empty</h3>";
                }
                ?>
               </div>
        </div>
		  <div class="modal fade" id="update_cart_modal" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog modal-sm"  role="document">
                <div class="modal-content">
                        <form id="person_address_form">
                  
                    <div class="modal-body"> 
                          <input type="hidden" name="cart_type" id="cart_type" value="">
                         <input type="hidden" name="cart_id" id="cart_id" value="">
                           <div class="bd">
                            <div class="sizes-cont">
                            <div class="title" id="modal-title">Change Flavour</div>
                            <div class="sizes" id="change-flavour">
                            </div>
                            <div class="sizes" id="change-qty">
                             </div>

                        </div>
                        </div>
                               
                            </div>
                    </div>
                   </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
	<?php $this->load->view('footer');?>
       <script src="<?php echo base_url()?>assets/js/cart.js"></script>
    </body>
</html>
