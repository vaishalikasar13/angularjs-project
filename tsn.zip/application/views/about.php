<?php $this->load->view('header');?>

		<!-- About Us Area Start -->
        <div class="about-us-area pb-100">
            <div class="container">
            <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li><a href="<?php echo site_url('about')?>">About</a></li>
                       </ul>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-12 d-flex align-items-center">
                        <div class="overview-content-2">
							<h3  class="pb-20 title" align="center">Welcome To</h3>
                            <h2>TSN- Transform Sports Nutrition</h2>
                            <p class="peragraph-blog">India's most innovating and upfront brand in sport's and health nutrition, here at TSN - Transform Sports Nutrition we pride ourselves in offering only the best sports supplementation and high quality nutrition. Aimed at fuelling the ambition of any fitness enthusiast across India, our ambition is to help any individual who has a goal to achieve higher level performance.
</p>
 <p class="peragraph-blog">The excited journey of TSN started back in 1995, when owner Anthony Joseph, formed <strong> Da Muscle Store Nutrition</strong>, with the aptitude to develop and deliver only the most advanced sports nutrition to those of any discipline, in any sport any goal.
With the increasing importance of maintaining an active lifestyle becoming more and more aware to individuals, it's essential that you're training The right way. Athletes, Sports team and Fitness enthusiasts, they all have one thing in common, they want to improve every day.

</p>

<p class="peragraph-blog">First-class athletes from across various sports codes make up the TSN family and attest to the reputation of our products, Our athletes include champion bodybuilders, other sports winner and fitness competitors, to name a few. We work closely to with these top athletes to ensure they are taking in highly advanced supplementation in line with their training and event programs to produce world-beating result.
</p>
<p class="bold">Transform Sports Nutrition a.k.a TSN - Paving the way for fitness enthusiastic of any level to take on a brand new challenge and perform to their full potential.</p>
                            
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 pt-50">
                        <div class="overview-img text-center">
                            <a href="#">
                                <img src="<?php echo base_url();?>assets/images/about.jpg" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	
		<!-- End Brand Area -->
	<?php $this->load->view('footer');?>
    </body>
</html>
