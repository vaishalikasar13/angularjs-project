<?php $this->load->view('header');?>

<div class="login-register-area pb-100 pt-20">
      <div class="container">
          <div class="row">
              <div class="col-lg-7 col-md-12 ml-auto mr-auto">
                  <div class="login-register-wrapper">
                      <div class="login-register-tab-list nav">
                          <a class="active" data-toggle="tab" href="#lg1" id="login">
                              <h4> login </h4>
                          </a>
                          <a data-toggle="tab" href="#lg2" id="register">
                              <h4> register </h4>
                          </a>
                      </div>
                      <div class="tab-content">
                          <div id="lg1" class="tab-pane active">
                              <div class="login-form-container login-form">
                                  <div class="login-register-form">
                                      <form id="login_form" method="post" >
                                       <input type="hidden" id="ref" value="<?php echo $ref; ?>">
                                          <input type="text" name="usr_username" id="usr_username" placeholder="Email/Mobile number" >
                                          <p id="not-match-error" class="errormesssage" style="display:none" >Your username or password is incorrect</p>
                                          <input type="password" name="usr_password"  id="usr_password" placeholder="Password" >
                                          <div class="button-box">
                                              <div class="login-toggle-btn">
                                                 <a href="javascript:;" class="forget_pass_button">Forgot Password?</a>
                                              </div>
                                              <button type="submit" id="login_btn_save">Login</button>
                                            </div>
                                      </form>
                                  </div>
                              </div>
                          </div>
                          <div id="lg2" class="tab-pane">
                              <div class="login-form-container">
                                  <div class="login-register-form">
                                      <form id="register_form" method="post">
                                       <input type="hidden" id="reg_ref" value="<?php echo $ref; ?>">
                                       <div class="row">
                                           <div class="col-md-6">
                                           <input type="text" name="register_register_prs_name" id="register_prs_name" placeholder="Name *" required="" data-msg="Please Enter Name">
                                           </div>
                                          <div class="col-md-6">
                                            <input name="register_prs_email" id="register_prs_email" placeholder="Email *" type="email" data-msg="Please Enter Email">
                                           </div>
                                           <div class="col-md-6">
                                            <input name="register_prs_mob" id="register_prs_mob" placeholder="Mobile *" type="text" data-msg="Please Enter Mobile No.">
                                           </div>
                                     
                                           <div class="col-md-6">
                                          <input type="password" name="register_prs_password" id="register_prs_password" placeholder="Password *" data-msg="Please enter password" >
                                           </div>
                                         <!--   <div class="col-md-6">
                                          <input type="password" name="register_prs_cnfrm_password" id="register_prs_cnfrm_password" placeholder="Re-Enter Password *" data-msg="Please re-enter password">
                                           </div> -->
                                       </div>
                                          <div class="button-box pt-20">
                                              <button type="submit" id="register_btn_save"><span>Register</span></button>
                                             </div>
                                      </form>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="login-form-container" id="forget_pass_form_div" style="display: none;">
                         <!-- BEGIN FORGOT PASSWORD FORM -->
                         <div class="login-register-form">
                          <form class="forget-form" id="forget_pass_form" method="post">
                              <h4 class="center">Forgot Password ?</h4>
                              <p class="center">We will send you a link to reset your password.</p>
                              <p class="light-blue-color block"  id="error"></p>
                              <input type="email" autocomplete="off" placeholder="Enter email address" name="fpwd_email" id="fpwd_email"  required="" data-msg="Please Enter Email Id">

                              <div class="button-box pt-20">
                                  <button type="button" class="back-btn" id="back-btn">Back </button>
                                 <button type="submit" id="fpwd_btn_save">Submit</button>
                                  </div>
                          </form>
                          </div>
                          <!-- END FORGOT PASSWORD FORM -->
                          
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $this->load->view('footer');?>
  <script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/form_validation/login.js"></script>
</body>
</html>