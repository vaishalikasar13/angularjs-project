<?php $this->load->view('header');?>
		<!-- Slider Start -->
        <div class="slider-area">
            <div class="slider-active owl-dot-style owl-carousel">
                <?php foreach ($banner_images as $banner_images_key) { 
                $link = '';
                if($banner_images_key->gls_link) {
                  $link=  $banner_images_key->gls_link;  
                }
                ?>
             <a href="<?php echo $link?>">
               <div class=" bg-img" >
                    <img src="<?php echo base_url(GALLERY_SET_IMAGE).$banner_images_key->gls_image;?>">
                   <!--  <div class="container">
                        <div class="slider-content slider-animated-1">
                          <p class="animated theme"><?php echo $banner_images_key->gls_name; ?></p>
                        </div>
                    </div> -->
                </div>
                <?php } ?>
                </a>
                
            </div>
        </div>
		<!-- Slider End -->
	
	
		<!-- New Products Start -->
        <div class="product-area gray-bg pt-90 pb-65">
            <div class="container">
                <div class="product-top-bar section-border mb-55">
                    <div class="section-title-wrap text-center">
                        <h3 class="section-title">Our Products</h3>
                    </div>
                </div>
                <div class="tab-content jump">
                  		<!-- Shop Page Area Start -->
        <div class="shop-page-area">
            <div class="container">
                <div class="row flex-row-reverse">
                    <div class="col-lg-12">
                    <div class="grid-list-product-wrapper ">
                            <div class="product-grid product-view pb-20">
                                <div class="row">
                                    <?php foreach($products as $key)
                                        {
                                        ?>
                                         <div class="product-width col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12 mb-30">
                                        <div class="product-wrapper">
                                            <div class="product-img">
                                                <a href="<?php echo site_url('product-detail/'.$key->prd_slug)?>">
                                                    <img alt="" src="<?php echo base_url().CHILD_FOLDER.PRODUCT_BIG_IMAGE_PATH.$key->img_path?>">
                                                </a>
                                             </div>
                                            <div class="product-content text-left">
												<div class="product-hover-style">
													<div class="product-title">
														<h4>
															<a href="<?php echo site_url('product-detail/'.$key->prd_slug)?>"><?php echo $key->prd_name?></a>
														</h4>
													</div>
													<!-- <div class="cart-hover">
														<h4><a href="#">+ Add to cart</a></h4>
													</div> -->
												</div>
												<!-- <div class="product-price-wrapper">
													<span><i class="fa fa-inr" aria-hidden="true"></i><?php echo $key->prd_price?></span>
													</div> -->
                                                     <?php
                                                 if($key->prd_discount > 0) {
                                                    ?>
                                                       <div class="product-price-wrapper" >
                                                    <span><i class="fa fa-inr" aria-hidden="true"></i><span class="price"><?php echo round($key->prd_price * (100-$key->prd_discount)/100)?></span></span>
                                                     <span class="product-price-old">₹<?php echo $key->prd_price?></span>
                                                     <span  class="discount"><?php echo $key->prd_discount?>% Off</span>
                                                    </div>
                                                <?php }
                                                 else {
                                                    echo '  <div class="product-price-wrapper" > <span><i class="fa fa-inr" aria-hidden="true"></i><span class="price">'.$key->prd_price.'</span></span> </div>';
                                                 }
                                                ?>
											</div>
                                           
                                        </div>
                                         </div>
                                        <?php
                                    }
                                        ?>
                                    </div>
                            </div>
                           
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
		<!-- Shop Page Area Start -->
            </div>
        </div>
		<!-- New Products End -->
		<!-- Testimonial Area Start -->
        <!-- <div class="testimonials-area bg-img pt-100 pb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="testimonial-active owl-carousel">
                            <div class="single-testimonial text-center">
                                <div class="testimonial-img">
                                    <img alt="" src="<?php echo base_url();?>assets/img/icon-img/testi.png">
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed do eiusmod tempor incididunt ut labore</p>
                                <h4>Gregory Perkins</h4>
								<h5>Customer</h5>
                            </div>
                            <div class="single-testimonial text-center">
                                <div class="testimonial-img">
                                    <img alt="" src="<?php echo base_url();?>assets/img/icon-img/testi.png">
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed do eiusmod tempor incididunt ut labore</p>
                                <h4>Khabuli Teop</h4>
								<h5>Marketing</h5>
                            </div>
                            <div class="single-testimonial text-center">
                                <div class="testimonial-img">
                                    <img alt="" src="<?php echo base_url();?>assets/img/icon-img/testi.png">
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed do eiusmod tempor incididunt ut labore </p>
                                <h4>Lotan Jopon</h4>
								<h5>Admin</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
		<!-- Testimonial Area End -->
	<?php $this->load->view('footer');?>
    </body>
</html>
