<?php $this->load->view('header');?>

        <!-- header end -->
        <!-- Breadcrumb Area Start -->
    
        <!-- Breadcrumb Area End -->
        <!-- Shop Page Area Start -->
        <div class="shop-page-area pb-100" ng-app="products">
            <div class="container"  ng-controller="productsCtrl">
                <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li  class="active">Supplements</li>
                       </ul>
                </div>
                <input type="hidden" name="cat_id" id="cat_id" value="<?php echo $cat_data->cat_id?>">
                   <input type="hidden" name="menu" id="menu" value="<?php echo $menu?>">
                <!-- HIDDEN FIELDS -->
           <div class="row flex-row-reverse">
                    <div class="col-lg-9">
                        <div class="shop-topbar-wrapper"  style="display: none">
                           <!--  <div class="shop-topbar-left">
                               <p>Showing 1 - 20 of 30 results  </p>
                            </div> -->
                            <div class="product-sorting-wrapper">
                                <div class="product-show shorting-style">
                                    <label>Sort by:</label>
                                    <select  ng-model="sorting">
                                        <option value="">Default</option>
                                        <option value="prd_price"> Price: Low to High</option>
                                        <option value="-prd_price">  Price: High to Low</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="grid-list-product-wrapper">
                            <div class="product-list product-view pb-20">
                                <div class="row">
                                    <div class="product-width col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 mb-30"  ng-repeat="product in products  | filter:catFilter | orderBy:sorting">
                                        <a href="<?php echo site_url('product-detail/{{product.prd_slug}}')?>">
                                        <div class="product-wrapper">
                                            
                                            <div class="product-img">
                                               <img alt="" class="prd-img" src="<?php echo base_url().CHILD_FOLDER.PRODUCT_BIG_IMAGE_PATH?>{{product.img_path}}">
                                               </div>
                                              
                                            <div class="product-list-details">
                                             <h4>
                                                  {{product.prd_name}}
                                                </h4>
                                                <div class="product-price-wrapper" ng-if="product.prd_discount > 0">
                                                    <span><i class="fa fa-inr" aria-hidden="true"></i><span class="price">{{round(product.prd_price * (100-product.prd_discount)/100)}}</span></span>
                                                     <span class="product-price-old">₹{{product.prd_price}}</span>
                                                     <span  class="discount">{{product.prd_discount}}% Off</span>
                                                    </div>
                                                      <div class="product-price-wrapper" ng-if="product.prd_discount == 0">
                                                    <span><i class="fa fa-inr" aria-hidden="true"></i><span class="price">{{product.prd_price}}</span></span>
                                                   </div>
                                                  <!-- {{product.prd_short_desc}} -->
                                                  <p style="margin-left:16px" ng-bind-html="product.prd_short_desc  | to_trusted"></p>
                                                
                                            </div>  
                                        </div>
                                         </a>
                                             
                                    </div>
                                  
                                </div>
                            </div>
                          </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="shop-sidebar-wrapper gray-bg-7 shop-sidebar-mrg">
                            <div class="shop-widget">
                                <h4 class="shop-sidebar-title">Shop By Categories</h4>
                                <div class="sidebar-list-style mt-20">
                                    <ul>
                                        <?php foreach ($categories as $key) {
                                            $selected="";
                                        if($cat_data->cat_id)
                                        {
                                            if($cat_data->cat_id==$key->cat_id)
                                            {
                                                $selected="checked";
                                            }
                                        }
                                           echo '<li><input type="checkbox"  '.$selected.' ng-click="includeCat('.$key->cat_id.')" /> '.$key->cat_name.'</li/>';
                                       }
                                            ?>
                                           
                                       <!--  <li><input type="checkbox"><a href="#">Green </a>
                                        <li><input type="checkbox"><a href="#">Herbal </a></li>
                                        <li><input type="checkbox"><a href="#">Loose </a></li>
                                        <li><input type="checkbox"><a href="#">Mate </a></li>
                                        <li><input type="checkbox"><a href="#">Organic </a></li>
                                        <li><input type="checkbox"><a href="#">White  </a></li>
                                        <li><input type="checkbox"><a href="#">Yellow Tea </a></li>
                                        <li><input type="checkbox"><a href="#">Puer Tea </a></li> -->
                                    </ul>
                                </div>
                            </div>
                           </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Shop Page Area Start -->
    <?php $this->load->view('footer');?>
     <script src="<?php echo base_url();?>assets/js/angular.min.js"></script>
     <script src="<?php echo base_url();?>assets/js/product_list.js"></script>
    </body>
</html>
