<?php $this->load->view('header');?>

		<!-- About Us Area Start -->
        <div class="about-us-area pb-100">
            <div class="container">
            <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li class="active">Place Order</li>
                       </ul>
                </div>
                <!-- <div class="row">
                   <div class="overview-content-2"> -->
							<h5  class="pb-20" align="center">Soon we will accept online payment, Currently we are accepting cheque & COD</h5>
                     <h3  class="pb-20 title" align="center">9867732874 | 9867431010 | 8691994415</h3>
                            
<!--                         </div>
                     </div> -->
            </div>
        </div>
	
		<!-- End Brand Area -->
	<?php $this->load->view('footer');?>
    </body>
</html>
