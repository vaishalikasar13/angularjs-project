<?php $this->load->view('header');?>

        <!-- Contact Area Start -->
        <div class="contact-us pb-100">
            <div class="container">
            <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li>Contact</li>
                       </ul>
                </div>
                <div class="row">
                    <!-- Contact Form Area Start -->
                    <div class="col-lg-6">
                        <div class="small-title mb-30">
                            <h2>Contact Form</h2>
                            <p>Transform Sports Nutrition a.k.a TSN - Paving the way for fitness enthusiastic of any level to take on a brand new challenge and perform to their full potential.</p>
                        </div>
                        <form id="contact_form"  method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="contact-form-style mb-20">
                                        <input name="contact_name" id="contact_name" placeholder="Full Name" type="text" required="" data-msg="Please Enter Name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="contact_email" id="contact_email" placeholder="Email Address" type="email" required="" data-msg="Please Enter Email">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="contact_mob" id="contact_mob" placeholder="Mobile No." type="text" required="" data-msg="Please Enter Mobile No.">
                                    </div>
                                </div>
                               <div class="col-lg-12">
                                    <div class="contact-form-style">
                                        <textarea name="contact_msg" id="contact_msg" placeholder="Message" data-msg="Please Enter Message"></textarea>
                                        
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                      <div class="contact-form-style">
                                    <button type="submit" id="btn_save">SEND MESSAGE</button>
                                       
                                </div>
                            </div>
                            </div>
                        </form>
                        <p class="form-messege"></p>
                    </div>
                    <!-- Contact Form Area End -->
                    <!-- Contact Address Strat -->
                    <div class="col-lg-6">
                        <div class="small-title mb-30">
                            <h3 class="bold">TSN -Discover the warrior within you </h3>
                         </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="contact-information mb-30">
                                    <h4>Our Address</h4>
                                    <p>The Chembers, Unit no. 8,Office no. 89- A/B,Kandivali Inds. Estate,Charkop, Kandivali (W),Mumbai - 400067.</p>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="contact-information contact-mrg mb-30">
                                    <h4>Contact Us</h4>
                                    <p>
                                        <a href="tel:9867732874"><i class="fa fa-phone mr-2" aria-hidden="true"></i> 9136126136 </a>
                                       </p>
                                        <p>
                                        <a href="mailto:transformsportsnutrition.com"><i class="fa fa-envelope mr-2" aria-hidden="true"></i> info@transformsportsnutrition.com</a>
                                       </p>
                                        <p>
                                        <a href="http://transformsportsnutrition.com"><i class="fa fa-globe mr-2" aria-hidden="true"></i> www.transformsportsnutrition.com</a>
                                       </p>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                    <!-- Contact Address Strat -->
                    <!-- Google Map Start -->
                   
                    <!-- Google Map Start -->
                </div>
            </div>
        </div>
        <!-- Contact Area Start -->
            <?php $this->load->view('footer');?>
        <script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/form_validation/contact_us.js"></script>
    </body>
</html>