	<!-- Footer style Start -->
    <footer class="footer-area pt-75 gray-bg-3">
            <div class="footer-top gray-bg-3 pb-35">
                <div class="container">
                    <div class="row">
						<div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-widget mb-40">
                                <div class="footer-title mb-25">
                                    <h4>My Account</h4>
                                </div>
                                <div class="footer-content">
                                    <ul>
                                        <li><a href="<?php echo base_url('profile');?>">My Account</a></li>
                                        <li><a href="<?php echo base_url('my-orders');?>">Orders</a></li>
                                        <!-- <li><a href="<?php echo base_url('profile');?>">WishList</a></li> -->
                                     </ul>
                                </div>
                            </div>
                        </div>
						<div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-widget mb-40">
                                <div class="footer-title mb-25">
                                    <h4>Information</h4>
                                </div>
                                <div class="footer-content">
                                    <ul>
                                        <li><a href="<?php echo site_url('about');?>">About Us</a></li>
                                       <li><a href="<?php echo base_url('privacy-policy');?>">Privacy Policy</a></li>
                                        <li><a href="<?php echo base_url('terms-and-conditions');?>">Terms & Conditions</a></li>
                                     <li><a href="<?php echo base_url('return-policy');?>">Shipping & Return Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
						<div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-widget mb-40">
                                <div class="footer-title mb-25">
                                    <h4>Social</h4>
                                </div>
                                <div class="footer-content">
                                    <ul>
                                        <li><a target="_blank" href="https://www.facebook.com/Transform-Sports-Nutrition-336009693631208/">Facebook</a></li>
                                         <li><a   target="_blank" href="https://www.instagram.com/transformsportsnutrition/">Instagram</a></li>
                                         <li><a   target="_blank" href="https://twitter.com/TransformSport1">Twitter</a></li>
                                       </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-widget footer-widget-red footer-black-color mb-40">
                                <div class="footer-title mb-25">
                                    <h4>Contact Us</h4>
                                </div>
                                <div class="footer-about">
                                    <p>The Chambers, Unit no. 8,Office no. 89- A/B,Kandivali Inds. Estate,Charkop, Kandivali (W),Mumbai - 400067.</p>
                                    <div class="footer-contact mt-20">
                                        <ul>
                                            <li><i class="fa fa-phone mr-2" aria-hidden="true"></i> 9136126136 <li>
                                             <li><i class="fa fa-envelope mr-2" aria-hidden="true"></i> info@transformsportsnutrition.com</li>
                                        </ul>
                                    </div>
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom pb-25 pt-25 gray-bg-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="copyright">
                                <p>Copyright © <a href="<?php echo base_url();?>#">TSN</a>. All Right Reserved.</p>
                            </div>
                        </div>
                         </div>
                </div>
            </div>
        </footer>
		<!-- Footer style End -->
      	<!-- all js here -->
        <script src="<?php echo base_url();?>assets/js/vendor/jquery-1.12.0.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/popper.js"></script>
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
       <script src="<?php echo base_url();?>assets/js/isotope.pkgd.min.js"></script>
       
    <script src="<?php echo base_url();?>assets/js/imagesloaded.pkgd.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/ajax-mail.js"></script>
        <script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/plugins.js"></script>
        <script src="<?php echo base_url();?>assets/js/main.js"></script>
         <script src="<?php echo base_url();?>assets/js/angular.min.js"></script>
           <script src="<?php echo base_url();?>assets/js/product_list.js"></script>
           <script type="text/javascript">
       var base_url='<?php echo base_url()?>';
        $('#btn-cancel').click(function() {
            history.go(-1);
        });
     </script>