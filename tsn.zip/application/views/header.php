<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo $title?></title>
        <meta name="description" content="">
        <meta name="robots" content="noindex, follow" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/img/favicon.png">
		
		<!-- all css here -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slick.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/chosen.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/themify-icons.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/ionicons.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/meanmenu.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">
         <link href="<?php echo base_url();?>assets/css/progress-wizard.min.css" rel="stylesheet">
        <script src="<?php echo base_url();?>assets/js/vendor/modernizr-2.8.3.min.js"></script>
        <style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
    </head>
   
    <body>
        <!-- header start -->
        <header class="header-area gray-bg clearfix">
            <div class="header-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-4 col-6">
                            <div class="logo">
                                <a href="<?php echo site_url('home');?>">
                                    <img alt="" src="<?php echo base_url();?>assets/images/logo.png">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-8 col-6">
                            <div class="header-bottom-right">
                                <div class="main-menu">
                                    <nav>
                                        <ul>
                                            <?php 
                                            $product_category_active = $this->input->get('product_category');
                                            $menuActiveClass = '';
                                            if($product_category_active != '')
                                            {
                                                $menuActiveClass = 'menu-active';
                                            } ?>
                                            <li class="top-hover"><a href="<?php echo site_url('home');?>">home</a>
                                               </li>
                                            <li><a href="<?php echo site_url('about');?>">about</a></li>
                                           <li class="top-hover <?php echo $menuActiveClass; ?>"><a href="">Supplements</a>
                                            <?php 
                                        $product_category=$this->product_model->getProductCategories(SUPPLEMENTS_MENU);
                                             ?>
                                                <ul class="submenu">
                                                    <?php 
                                                    $catActiveClass = '';
                                                    foreach ($product_category as $productCategorykey) { 
                                                    $catActiveClass = '';
                                                        if($productCategorykey->cat_slug == $product_category_active)
                                                        {
                                                            $catActiveClass = 'menu-active';
                                                        } 
                                                        ?>
                                                 <li class="<?php echo $catActiveClass; ?>"> <a href="<?php echo site_url('products/').$productCategorykey->cat_slug; ?>" ><?php echo $productCategorykey->cat_name; ?></a> </li>
                                             <?php } ?>
                                                </ul>
                                            </li>
                                           <?php 
                                        $product_category=$this->product_model->getProductCategories(SHOP_MENU);
                                        if(!empty($product_category)) {

                                             ?>

                                             <li class="top-hover <?php echo $menuActiveClass; ?>"><a href="">Shop</a>

                                                <ul class="submenu">
                                                    <?php 
                                                    $catActiveClass = '';
                                                    foreach ($product_category as $productCategorykey) { 
                                                    $catActiveClass = '';
                                                        if($productCategorykey->cat_slug == $product_category_active)
                                                        {
                                                            $catActiveClass = 'menu-active';
                                                        } 
                                                        ?>
                                                 <li class="<?php echo $catActiveClass; ?>"> <a href="<?php echo site_url('shop/').$productCategorykey->cat_slug; ?>" ><?php echo $productCategorykey->cat_name; ?></a> </li>
                                             <?php } ?>
                                                </ul>
                                            </li>
                                          <?php }
                                          ?>
                                           
                                            <li><a href="<?php echo site_url('contact');?>">contact</a></li>
                                        </ul>
                                    </nav>
                                </div>
							        <div class="header-currency">
                                    <span class="digit"> 
                                    <?php if($this->session->userdata(PROJECT_SESSION_ID))
                                    { ?>
                                         <a ><?php if($this->session->userdata(PROJECT_SESSION_NAME) != '')
                                         {
                                          echo $this->session->userdata(PROJECT_SESSION_NAME); 
                                         }else
                                         { 
                                            echo 'User'; 
                                         } ?>
                                         </a>
                                         <i class="ti-angle-down"></i>
                                    </span>
                                    <div class="dollar-submenu">
                                       <ul>
                                            <li><a href="<?php echo base_url('profile') ?>"> Profile</a></li>
                                             <li><a href="<?php echo base_url('my-orders') ?>"> Orders</a></li>
                                             <li><a href="<?php echo base_url('profile/edit') ?>"> Edit profile</a></li>
                                            <li><a href="<?php echo base_url('logout') ?>"> Logout</a></li>
                                        </ul>
                                    </div>
                                      <?php }else 
                                    { ?>
                                         <a href="<?php echo base_url('login') ?>">Login</a>
                                    <?php } ?>
                                </div>
                                    <div class="header-cart">
                                    <a href="<?php echo site_url('cart');?>">
                                        <div class="cart-icon">
                                            <i class="ti-shopping-cart"></i>
                                            <?php 
                                            if(count($this->cart->contents()) > 0){
                                                echo ' <span  id="cart-count" class="badge">'.count($this->cart->contents()).'</span>';
                                            } else {
                                              echo ' <span  id="cart-count" class="badge"></span>';  
                                            }
                                           ?>
                                          
                                       </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-area">
                        <div class="mobile-menu">
                            <nav id="mobile-menu-active">
                                <ul>
                                            <?php 
                                            $product_category_active = $this->input->get('product_category');
                                            $menuActiveClass = '';
                                            if($product_category_active != '')
                                            {
                                                $menuActiveClass = 'menu-active';
                                            } ?>
                                            <li class="top-hover"><a href="<?php echo site_url('home');?>">home</a>
                                               </li>
                                            <li><a href="<?php echo site_url('about');?>">about</a></li>
                                           <li class="top-hover <?php echo $menuActiveClass; ?>"><a href="">Supplements</a>
                                            <?php 
                                        $product_category=$this->product_model->getProductCategories();
                                             ?>
                                                <ul class="submenu">
                                                    <?php 
                                                    $catActiveClass = '';
                                                    foreach ($product_category as $productCategorykey) { 
                                                    $catActiveClass = '';
                                                        if($productCategorykey->cat_slug == $product_category_active)
                                                        {
                                                            $catActiveClass = 'menu-active';
                                                        } 
                                                        ?>
                                                 <li class="<?php echo $catActiveClass; ?>"> <a href="<?php echo site_url('products/').$productCategorykey->cat_slug; ?>" ><?php echo $productCategorykey->cat_name; ?></a> </li>
                                             <?php } ?>
                                                </ul>
                                            </li>
                                           
                                            <li><a href="<?php echo site_url('contact');?>">contact</a></li>
                                        </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
		<!-- header end -->