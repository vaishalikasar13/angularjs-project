<?php $this->load->view('header');?>

		<!-- About Us Area Start -->
        <div class="about-us-area pb-100">
            <div class="container">
            <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo site_url('home')?>">Home</a></li>
                            <li><a href="<?php echo site_url('my-orders')?>">Orders</a></li>
                               </ul>
                </div>
                 <?php 
                 if(!empty($order))
                 {
           ?>
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                    	<div class="orderInfo-block">
                    	  <div>
                      	<span class="orderInfo-label"> Placed On: </span>
                      <span class="orderInfo-value"><?php echo date("M d, Y", strtotime( $order->ord_crtd_dt))?></span>
                      </div>
                        <div>
                      	<span class="orderInfo-label"> Order No.: </span>
                      <span class="orderInfo-value"><?php echo $order->ord_reference_no?></span>
                      </div>
                      <div>
                      	<span class="orderInfo-label"> Total amount: </span>
                      <span class="orderInfo-value"><?php echo $order->ord_total_amt?></span>
                      </div>	
                    	</div>
                    	<div class="orderInfo-block">
                    		<div class="orderInfo-heading">Updates sent to:</div>
                    	  <div>
                      	<span class="orderInfo-label"><i class="fa fa-phone" aria-hidden="true"></i> </span>
                      <span class="orderInfo-value"><?php echo $order->ord_update_sent_mobile?></span>
                      </div>
                        <div>
                      	<span class="orderInfo-label"><i class="fa fa-envelope" aria-hidden="true"></i> </span>
                      <span class="orderInfo-value"><?php echo $order->ord_update_sent_email?></span>
                      </div>
                     	
                    	</div>
                   <div class="orderInfo-block">
                    		<div class="orderInfo-heading">Shipping Address:</div>
                    	 <div class="bold"><?php echo $order->pad_name?></div>
                    	 <div><?php echo $order->pad_address?></div>
                    	 <div><?php echo $order->pad_locality?> <?php echo $order->pad_city;?>- <?php echo $order->pad_pincode;?></div>
                     	
                    	</div>
                    	<div class="orderInfo-block last-child"><div class="orderInfo-heading"> Payment Mode: </div><div> <?php echo $order->ord_payment_mode_name?></div>
                    </div>
                    <div>
                    	<div class="order-items-title">Items in this order</div>
                    	           <?php 
                     

            foreach ($orderProducts as $ordersProductKey)
             {
                
              ?> 
                      <div class="prod-set">
                       <div class="prod-item">
                          <div class="col1">
                            <img src="<?php echo base_url().CHILD_FOLDER.PRODUCT_SMALL_IMAGE_PATH.$ordersProductKey->img_path?>" alt="<?php echo $ordersProductKey->prd_name ;?>" width="86" height="118">
                          </div> 
                          <div class="col2">
                            <div class="row m0">
                                <div class="col-md-7 col-lg-8 col-sm-12">
                                    <div class="prod-name"><?php echo $ordersProductKey->prd_name ;?></div>  
                                    <div class="flavour-qty-wrap ptb5">
                                      <div class="flavour-qty">
                                          <span class="flv-drop" >
                                             <span>Flavour: </span> 
                                              <span><?php echo $ordersProductKey->prd_flavour ;?> </span> 
                                             
                                          </span>
                                          <span class="qty-drop" >
                                             <span>Qty: </span> 
                                              <span><?php echo $ordersProductKey->odp_quantity ;?> </span> 
                                             </span>
                                      </div>
                                          <div class="prod-name"><?php echo $ordersProductKey->prd_status ;?> (<?php echo date("M d, Y", strtotime( $ordersProductKey->odp_date))?>)</div>    
                                    </div>
                                    
                                </div>
                                 <div class="col-md-4 col-lg-4 col-sm-12">
                                    <div class="prod-price">Rs. <?php echo $ordersProductKey->odp_total_amt ;?> </div> 
                                </div>
                                
                            </div>
                         </div>
                       </div> 
                        </div>
                    <?php 
                }
                    ?>
                    </div>

                    </div>
                   
                </div>
                <?php 
            }
            else {
            		echo '<h5 class="text-center">Something went wrong</h5>'; 
            }
            ?>
            </div>
        </div>
	
		<!-- End Brand Area -->
	<?php $this->load->view('footer');?>
    </body>
</html>
