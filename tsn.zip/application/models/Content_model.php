<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Content_model extends CI_Model 
{

  function __construct()
  {
  	require_once(APPPATH . "/config/mail_template.php");
    parent::__construct();
    $this->load->model('Content_model');
  }
  public function getContent($event,$receiver_data,$content_data) {
  	$mail_subject = '';
$mail_body='';
$msg_body='';
if($event == 'user_order_placed')
	{
		$mail_subject = USER_ORDER_PLACED_SUBJECT; 
		$mail_subject = str_replace('%ORDER_NO%',$content_data->ord_reference_no, $mail_subject);
		$mail_body = USER_ORDER_PLACED_BODY;
		$mail_body = str_replace('%RECEIVER_NAME%',$receiver_data['name'], $mail_body);
		$mail_body = str_replace('%ORDER_NUMBER%',$content_data->ord_reference_no, $mail_body);
		$mail_body = str_replace('%AMOUNT%',$content_data->ord_total_amt, $mail_body);
		$mail_body = str_replace('%CUSTOMER_NAME%',$content_data->pad_name, $mail_body);
		$mail_body = str_replace('%LOCALITY%',$content_data->pad_locality, $mail_body);
		$mail_body = str_replace('%ADDRESS%',$content_data->pad_address, $mail_body);
		$mail_body = str_replace('%CITY%',$content_data->pad_city, $mail_body);
		$mail_body = str_replace('%PINCODE%',$content_data->pad_pincode, $mail_body);
		$mail_body = str_replace('%WEBSITE_NAME%',WEBSITE_NAME, $mail_body);
		$msg_body = ORDER_PLACED_USER_MSG; 
		$msg_body = str_replace('%ORDER_NO%',$content_data->ord_reference_no, $msg_body);
		$msg_body = str_replace('%RECEIVER_NAME%',$receiver_data['name'], $msg_body);
		
	}
	if($event == 'admin_order_placed')
	{
		$mail_subject = ADMIN_ORDER_PLACED_SUBJECT; 
		$mail_subject = str_replace('%ORDER_NO%',$content_data->ord_reference_no, $mail_subject);
		$mail_body = ADMIN_ORDER_PLACED_BODY;
		$mail_body = str_replace('%ORDER_NUMBER%',$content_data->ord_reference_no, $mail_body);
		$mail_body = str_replace('%ORDER_LINK%',APP_LINK.'orders'.$content_data->ord_reference_no, $mail_body);
		$msg_body = ORDER_PLACED_ADMIN_MSG; 
		$msg_body = str_replace('%ORDER_NO%',$content_data->ord_reference_no, $msg_body);
		
	}
	$msg = array("mail_subject"=> $mail_subject, "mail_body"=>$mail_body, "msg_body" =>$msg_body );
	return $msg;
  }
}
?>