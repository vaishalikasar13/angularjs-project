<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Order_model extends CI_Model 
{

  function __construct()
  {
    parent::__construct();
    $this->load->model('content_model');
  }
  public function place_order($ord_reference_no,$ord_update_sent_mobile)
  {
  	// $this->db->trans_start(TRUE);
  	//Person Order
   $prs_id = $this->session->userdata(PROJECT_SESSION_ID);
  	$order_sub_total = $this->cart->total();
  	$order_grand_total = $this->cart->total()+ORDER_DELIVER_CHARGE;
  	$order_data = array();
    $order_data['ord_reference_no'] = $ord_reference_no;
  	$order_data['ord_prs_id'] = $prs_id;
  	$order_data['ord_delivery_adddress'] = $this->input->post('ord_deliver_address');
    $order_data['ord_payment_mode'] = $this->input->post('ord_payment_mode');
    $order_data['ord_sub_total'] = $order_sub_total;
  	$order_data['ord_shipping_charges'] = $this->input->post('ord_shipping_charges');
    $order_data['ord_update_sent_mobile'] = $ord_update_sent_mobile;
    $order_data['ord_update_sent_email'] = $this->session->userdata(PROJECT_SESSION_EMAIL);
    $order_data['ord_total_amt'] = $order_grand_total;
  	$order_data['ord_date'] = date('Y-m-d');
  	$order_data['ord_status'] = ORDER_STATUS_PLACED;
    $order_data['ord_crtd_dt'] = date('Y-m-d H:i:s');
     $order_data['ord_crtd_by'] =$prs_id;
  	// print_r($order_data);
	$ord_id = $this->home_model->insert('person_order',$order_data);

	if($ord_id != '-1')
	{
		// Person Order Products
		 foreach ($this->cart->contents() as $items)
	     {
        $last_number=$this->home_model->getLastInvoiceNumber();
        if(empty( $last_number)) {
          $odp_invoice_number = INVOICE_NUMBER_STARTS;
        } else {
           $odp_invoice_number=   $last_number->odp_invoice_number + 1;
        }
			 $ord_product_data = array(
				'odp_ord_id'=>$ord_id,
        'odp_invoice_number'=> $odp_invoice_number,
				'odp_prd_id'=>$items['id'],
        'odp_flavour'=>$items['flavour'],
				'odp_quantity'=>$items['qty'],
				'odp_amt'=>$items['price'],
				'odp_total_amt'=>$items['subtotal'],
				'odp_status'=>ORDER_STATUS_PLACED,
				'odp_date'=>date('Y-m-d'),
        'odp_crtd_dt'=>date('Y-m-d H:i:s'),
        'odp_crtd_by'=>$prs_id
         );
      $this->db->insert('person_order_products', $ord_product_data);
       $order_product_status_data = array();
      $order_product_status_data['ops_status'] = ORDER_STATUS_PLACED;
         $order_product_status_data['ops_ord_id'] = $ord_id;
      $order_product_status_data['ops_prd_id'] = $items['id'];
      $order_product_status_data['ops_crtd_dt']   = date('Y-m-d H:i:s');
        $order_product_status_data['ops_crtd_by']   =$prs_id;
    $ord_sts_id = $this->home_model->insert('person_order_product_status',$order_product_status_data);
		}	

	$order_status_data = array();
	  	$order_status_data['ods_status'] = ORDER_STATUS_PLACED;
	  	$order_status_data['ods_ord_id'] = $ord_id;
	  	$order_status_data['ods_date']   = date('Y-m-d');
		$ord_sts_id = $this->home_model->insert('order_status',$order_status_data);

  

    $this->load->library('cart');
    $this->cart->destroy();
	}
  	
  	return $ord_id;
  }
   public function getOrderData($ord_id,$field_name='')
  {
    $sql="SELECT *,
    (SELECT prs_mob from person where prs_id=ord_prs_id LIMIT 1) ord_prs_mob,
    (SELECT prs_email from person where prs_id=ord_prs_id LIMIT 1) ord_prs_email,
    (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ord_payment_mode and gen_prm.gnp_group='payment_mode') ord_payment_mode_name,
    (SELECT (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ods_status and gen_prm.gnp_group='order_status') from order_status where ods_ord_id=ord_id ORDER BY ods_crtd_dt DESC LIMIT 1) order_status_name
     FROM `person_order` where ";
     if($field_name !='')
      {
        $sql.=" ord_reference_no ='".$ord_id."'" ;
      }else
      {
        $sql.="ord_id='".$ord_id."'";
      }   
    $query=$this->db->query($sql);
    $row=$query->row();
    return $row;
  }
   public function getOrderProducts($ord_id)
  {
    $sql="SELECT *,
    (SELECT prd_name from products where prd_id=odp_prd_id) prd_name,
     (select  images.img_path from images where images. img_type_id=odp_prd_id and  img_type=".PRODUCT_IMG_TYPE."  limit 1) as img_path
     FROM `person_order_products` where odp_ord_id='".$ord_id."'";
    $query=$this->db->query($sql);
    $result=$query->result();
    return $result;
  }
  public function getOrderListData()
  {
    $prs_id = $this->session->userdata(PROJECT_SESSION_ID);
    if($prs_id != '')
    {
         $sql="SELECT *,
        (SELECT prs_mob from person where prs_id=ord_prs_id LIMIT 1) ord_prs_mob,
        (SELECT prs_email from person where prs_id=ord_prs_id LIMIT 1) ord_prs_email,
        (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ord_payment_mode and gen_prm.gnp_group='payment_mode') ord_payment_mode_name,
        (SELECT (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ods_status and gen_prm.gnp_group='order_status') from order_status where ods_ord_id=ord_id ORDER BY ods_crtd_dt DESC LIMIT 1) order_status_name
         FROM `person_order` where ord_prs_id='".$prs_id."'  and ord_status = ".ORDER_STATUS_PLACED." order by  ord_crtd_dt desc";
        $query=$this->db->query($sql);
        $result=$query->result();
        return $result;
    }
   }
    public function getOrderDetail($ord_reference_no)
  {
   $sql="SELECT *,
        (SELECT prs_name from person where prs_id=ord_prs_id LIMIT 1) ord_prs_name,
        (SELECT prs_mob from person where prs_id=ord_prs_id LIMIT 1) ord_prs_mob,
        (SELECT prs_email from person where prs_id=ord_prs_id LIMIT 1) ord_prs_email,
        (SELECT COUNT(*) from person_order_products where odp_ord_id=ord_id ) ord_prd_count,
        (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ord_payment_mode and gen_prm.gnp_group='payment_mode') ord_payment_mode_name,
        (SELECT (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ods_status and gen_prm.gnp_group='order_status') from order_status where ods_ord_id=ord_id ORDER BY ods_crtd_dt DESC LIMIT 1) order_status_name
         FROM `person_order` left join person_addresses on person_addresses.pad_id = person_order.ord_delivery_adddress   where ord_prs_id='".$this->session->userdata(PROJECT_SESSION_ID)."' and ord_reference_no='".$ord_reference_no."'  order by  ord_crtd_dt desc";
        $query=$this->db->query($sql);
        return $query->row();
       }

     public function getOrderAllProducts($ord_id = false)
  {
    $sql="SELECT *,
    (select flv_name from product_flavours where flv_id = odp_flavour) prd_flavour,
    (SELECT prd_name from products where prd_id=odp_prd_id) prd_name,
    (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=odp_status and gen_prm.gnp_group='order_status') prd_status,
    (select  product_flavor_images.pfi_img from product_flavor_images where product_flavor_images.pfi_prd_id=person_order_products.odp_prd_id  limit 1) as img_path

     FROM `person_order_products`";
     if($ord_id) {
    $sql.= " where odp_ord_id = ".$ord_id."";
     }
    $query=$this->db->query($sql);
    $result=$query->result();
    return $result;
  }
     public function getOrderAllProductsStatus($ord_id = false)
  {
    $sql="SELECT *,
    (select gen_prm.gnp_name from  gen_prm where gen_prm. gnp_value=ops_status and gen_prm.gnp_group='order_prd_status') prd_status FROM `person_order_product_status`";
     if($ord_id) {
    $sql.= " where ops_ord_id = ".$ord_id."";
     }
    $query=$this->db->query($sql);
    $result=$query->result();
    return $result;
  }
  public function getOrderProductStatus($ops_prd_id, $ord_id)
  {
    $sql="SELECT ops_status, ops_crtd_dt, (SELECT gen_prm.gnp_name FROM gen_prm WHERE gen_prm.gnp_value = person_order_product_status.ops_status and gen_prm.gnp_group = 'order_prd_status') as status, 'completed' as class FROM `person_order_product_status` WHERE `ops_prd_id` = ".$ops_prd_id." and ops_ord_id=".$ord_id."
UNION 
SELECT gnp_value, '' as ops_crtd_dt, gnp_name as status,'' as class from gen_prm WHERE gnp_group = 'order_prd_status' and gnp_status = 1 and gnp_value NOT in (SELECT ops_status FROM `person_order_product_status` WHERE `ops_prd_id` = ".$ops_prd_id." and ops_ord_id=".$ord_id." )";
     
    $query=$this->db->query($sql);
   return $query->result();
    }
  public function updateOrderStatus($ord_reference_no,$status)
  {
    $orderData = array();
      $orderData['ord_status'] = $status;
     return $this->home_model->update('ord_reference_no',$ord_reference_no,$orderData,'person_order');
  }
  public function sendOrderSuccessMail($ord_reference_no)
  {
    if($ord_reference_no != '')
    {
      $ord_data = $this->getOrderDetail($ord_reference_no);
      if($ord_data != '')
      { 
        $customerOrderSuccess = array();
            // Customer Email
         $receiver_data = array(
                   'email' =>  $this->session->userdata(PROJECT_SESSION_EMAIL),
                    'name' =>  $ord_data->pad_name,
                    'mobile' =>  $ord_data->pad_mobile,
                    'alt_mobile' => $ord_data->pad_alt_phone,
                    );
          $mailData =  $this->content_model->getContent('user_order_placed', $receiver_data, $ord_data);
         $this->home_model->sendMail($ord_data->ord_prs_email, $mailData);
        $this->home_model->SendMessage( $mailData['msg_body'],$ord_data->ord_prs_mob);
         $mailData =  $this->content_model->getContent('admin_order_placed', '', $ord_data);
         $this->home_model->sendMail(ADMIN_EMAIL_VALUE, $mailData);
        $this->home_model->SendMessage( $mailData['msg_body'],ADMIN_SMS_VALUE);
          
      }
    }
  }

}