<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Home_model extends CI_Model 
{
  function __construct()
  {
    parent::__construct();
      $this->load->library('email');
      require_once(APPPATH . "/config/mail_template.php");
  }
   public function getBannerImages($type)
   {
      $sqlQuery = "Select * from gallery_set where gls_status = '".ACTIVE_STATUS."' and gls_type = '".$type."' ";    
     $query = $this->db->query($sqlQuery);
     $result = $query->result();
	  return $result;
  }
  function insert($table, $array){
    $this->db->insert($table, $array);
    $id = $this->db->insert_id();
    return $id;
  }
    public function getGenPrmResultByGroup($gpm_group)
    {
      $sqlQuery   = "SELECT  gnp_value as f1,gnp_name as f2  FROM gen_prm where gnp_group ='".$gpm_group."' and gnp_status='".ACTIVE_STATUS."' order by gnp_order"; 
     $query = $this->db->query($sqlQuery);
     $result = $query->result();
     return $result;
    }
    public function getStateDropdown()
  {
    $sqlQuery = "SELECT  stm_id as f1,stm_name as f2 FROM state_master where stm_status='".ACTIVE_STATUS."' ORDER by stm_id ASC";
     $query = $this->db->query($sqlQuery);
     $result = $query->result();
     return $result;
  }
  function update($field, $id, $array, $table)
  {
      $this->db->where($field, $id);
      $this->db->update($table, $array);
      return $id;
  }
  public function sendMail($email,$email_data)
   {
        $email_notifiy=$this->getBusinessParamData('email');
        if(!empty($email_notifiy) && $email_notifiy->bpm_value)
        {
          log_message('error','Sending Email to ' .$email. ' || Subject: ' .$email_data['mail_subject']. '||  Message: '.$email_data['mail_body']);
            log_message('error','Email configurations -- ' .EMAIL_PROTOCOL. ' -- ' .EMAIL_HOST. ' -- '.EMAIL_USERNAME. ' -- '.EMAIL_PASSWORD. ' -- ' .EMAIL_TYPE. ' -- ' .EMAIL_CHARSET. ' -- ' .EMAIL_WORDWRAP);
         
            if($email != '')
            {
                        $email_config = Array(
                'protocol' => EMAIL_PROTOCOL,
                'smtp_host' => EMAIL_HOST,
                'smtp_port' => EMAIL_PORT,
                'smtp_user' => EMAIL_USERNAME,
                'smtp_pass' => EMAIL_PASSWORD,
                'mailtype'  => EMAIL_TYPE, 
                'charset'   => EMAIL_CHARSET,
                'wordwrap' => EMAIL_WORDWRAP
              );
                      
                $this->email->initialize($email_config);
                $this->email->clear(TRUE);
                $this->email->set_newline("\r\n");
               $this->email->from(EMAIL_USERNAME,'TSN');
                $this->email->subject($email_data['mail_subject']);
                $this->email->message($email_data['mail_body']);
                $this->email->to($email);
               log_message('error','CRIMINAL SUBJECT'.$email_data['mail_subject'].' || MESSAGE : '.$email_data['mail_body']);
               log_message('error','CRIMINAL EMAIL'.json_encode($email));
                 if(!$this->email->send())
                {
                   // echo $this->email->print_debugger();
                   log_message('error','error occured in people insert Communication_model/send_mail'.$this->email->print_debugger());
                   //show_error($this->email->print_debugger());
                }
            }
          return true;
        }
    }
     public function getBusinessParamData($busParamname)
    {
        $businessParamSql = "SELECT * FROM bsn_prm where bpm_status = '".ACTIVE_STATUS."' and bpm_name='".$busParamname."' ";
       $query = $this->db->query($businessParamSql);
       $row = $query->row();
        return $row;
    }
      public function getLastInvoiceNumber()
    {
        $businessParamSql = "SELECT odp_invoice_number FROM person_order_products order by odp_id desc limit 1";
       $query = $this->db->query($businessParamSql);
       return $query->row();
      }
    function generateRandomStringNum($length)
    {
        $characters = '0123456789';
        $randomNo = '';
        for ($i = 0; $i < $length; $i++) {
          $randomNo .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomNo;
      }
      public function SendMessage($message,$mobile_no)
    {
            $sms_notifiy=$this->getBusinessParamData('sms');
            if(!empty($sms_notifiy))
            {
              // log_message('error','>>mobile no = '.$mobile_no);
             $ch = curl_init();
             curl_setopt($ch,CURLOPT_URL,  "http://api.msg91.com/api/sendhttp.php?");
             curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
             curl_setopt($ch, CURLOPT_POST, 1);
             curl_setopt($ch, CURLOPT_POSTFIELDS,"?country=91&sender=MSGIND&route=4&mobiles=$mobile_no&authkey=243235A5ebDlzp5bc72911&message=$message");
             $buffer = curl_exec($ch);
              // log_message('error','>>mobile no = '.$mobile_no);
             return true;
            }
      
    }
    public function dateinmysql($datefromuser='')
  {
    if (empty($datefromuser)) {
      return '0000-00-00';
    }
    else{
      $date = str_replace('/', '-', $datefromuser);
      return date('Y-m-d', strtotime($date));
    }
    
  }
  public  function getNewCode($data)
    {
        $type = $this->getBusinessParamData($data['type']);
        if (!isset($type->bpm_name)) return '';
         $column_prefix = explode('_', $data['column']) [0];
         $code = 0;
        if (isset($type->bpm_default_value) && $type->bpm_default_value != '')
        {
            $code = $type->bpm_default_value;
        }
          $sqlQuery = "select IFNULL(" . $data['column'] . ",0) newcode from " . $data['table'] . " where " . $column_prefix . "_status = '" . ACTIVE_STATUS . "'";
            if (isset($data['where']) && $data['where'] != '') $sqlQuery.= " and " . $data['where'];
            $sqlQuery.= " order by " . $column_prefix . "_id desc limit 1";
            $query = $this->db->query($sqlQuery);
             $result = $query->row();
             $code = $type->bpm_value.$code;
             // echo 'new code : '.$result->newcode.' || code : '.$code;
            if (!empty($result) && $result->newcode >= $code)
            {
               $code = $result->newcode;
             $generated_code =  $type->bpm_value.str_pad((str_replace($type->bpm_value, '', $code) + 1) , 4, '0', 0);
            }
            else
            {
              $generated_code = $code;
            }
        return $generated_code;
    }
  
    public function check_ord_txn_bsnprm($data = array())
  {

    $this->db->from('bsn_prm');
    
    if(isset($data['PAYTM_PAY_STATUS']) && $data['PAYTM_PAY_STATUS'] != '')
    {
      $this->db->where('bpm_name','PAYTM_PAY_STATUS');
      $this->db->where('bpm_value',$data['PAYTM_PAY_STATUS']);
    }
    
    if(isset($data['PAYTM_PAY_RESPONSE_CODE']) && $data['PAYTM_PAY_RESPONSE_CODE'] != '')
    {
      $this->db->where('bpm_name','PAYTM_PAY_RESPONSE_CODE');
      $this->db->where('bpm_value',$data['PAYTM_PAY_RESPONSE_CODE']);
    }
    
    $query = $this->db->get();
    
    if ($query->num_rows() > 0)
    {
      $result = $query->result();
      return $result[0]->bpm_id;
    }
    return false;

  }
}