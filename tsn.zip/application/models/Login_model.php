<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model 
{

  function __construct()
  {
    parent::__construct();
  }
  public function checkLogin($arrData=array())
  {
  	$user_data = '';
    $pswd='';
  	 if(isset($arrData['usr_username']) and !empty($arrData['usr_username']))
    {
      switch ($arrData['usr_username']) {
        case is_numeric($arrData['usr_username']):
                $condition = ' prs_mob = "'.$arrData['usr_username'].'" ';
          break;
        case filter_var($arrData['usr_username'], FILTER_VALIDATE_EMAIL):
                $condition = ' prs_email = "'.$arrData['usr_username'].'" ';
          break;
        default:
                $condition = ' prs_username = "'.$arrData['usr_username'].'" ';
          break;
      }
      if(isset($arrData['usr_password']) and !empty($arrData['usr_password']))
      {
        $pswd = ' and prs_password ="'.$arrData['usr_password'].'" ';
      }
      $sqlQuery = 'select * from person where  '.$condition.'  '.$pswd.' and prs_status = "'.ACTIVE_STATUS.'"';
		 $query=$this->db->query($sqlQuery);
		 $user_data=$query->row();
    }
    return $user_data;
  }
      public function checkPersonContact($prs_type,$prs_value,$prs_id='')
    {
        log_message('error','person_model::checkPersonContact >>');

        $sqlQuery = "SELECT COUNT(*) as count,prs_id,prs_mob FROM person where prs_status='".ACTIVE_STATUS."' and ".$prs_type."='".$prs_value."' ";
        if($prs_id != '')
        {
           $sqlQuery .=" and prs_id !='".$prs_id."'";
        }
        log_message('error',' sqlQuery : '.$sqlQuery);
		 $query=$this->db->query($sqlQuery);
		 $user_data=$query->row();
        log_message('error',' row : '.json_encode($user_data));
        log_message('error','person_model::checkPersonContact <<');
        return $user_data;
    }
    public function registerCustomer()
    {
    	$prsData = array();
    	$prsData['prs_name'] 	   = $this->input->post('prs_name');
      $prsData['prs_email'] 	 = $this->input->post('prs_email');
    	$prsData['prs_mob'] 	   = $this->input->post('prs_mob');
    	$prsData['prs_password'] = $this->url_encrypt->encrypt_openssl($this->input->post('prs_password'));
      $prsData['prs_status']   = ACTIVE_STATUS;
    	$prsData['prs_mob_verification']   = OTP_VERIFICATION_PENDING;
    	$prs_id = $this->home_model->insert('person',$prsData);
    	return $prs_id;

    }
    public function sendMailForPasswordReset($person_data = array())
    {
      $subject                            = 'TSN | Reset Password Notification';
      $emaildata['people']                = $person_data;
      $emaildata['email']                 = $person_data->prs_email;
      $emaildata['subject']               = $subject;
      $emaildata['message']               = '';
      $emaildata['link']                  = $person_data->link;
      $emaildata['template']              = 'email_template/forget_password_mail';
      $emaildata['email_cc']              = '';
     $email = $this->home_model->sendMail($emaildata);
      return true;
    }
     public function getForgotpswdTransaction($fpt_prs_id,$fpt_code)
  {
    $sql = "SELECT * FROM `forgot_password_transaction` WHERE  fpt_prs_id= '".$fpt_prs_id."' and fpt_code = '".$fpt_code."' and fpt_status='".ACTIVE_STATUS."' and  NOW() <= DATE_ADD(fpt_crtd_dt, INTERVAL ".FPT_LINK_VALIDITY_TIME.") ORDER BY fpt_id DESC LIMIT 1";
      $query = $this->db->query($sql);
      $row = $query->row();
      return $row;
  }
  public function checkOtp($otp_code)
  {
    $checkSql = "SELECT otp_prs_id,count(*) res_count,otp_mob from otp_transaction where otp_code='".$otp_code."' and otp_status='".ACTIVE_STATUS."' ORDER BY otp_crtd_dt DESC LIMIT 1";
      $query = $this->db->query($checkSql);
      $row = $query->row();
      return $row;
  }
   public function discard_otp($otp_prs_mob)
  {
    $checkSql = "UPDATE otp_transaction set otp_status='".OTP_VERIFICATION_DISCARD."' where otp_mob='".$otp_prs_mob."' ";
      $query = $this->db->query($checkSql);
      return true;
  }
    public function generateOtp($prs_id,$prs_mob)
  {
          $discard_otp = $this->login_model->discard_otp($prs_mob);
    $otp_code = $this->home_model->generateRandomStringNum(4);
         $otp_data = array();
       $otp_data['otp_prs_id']  = $prs_id;
       $otp_data['otp_mob']     = $prs_mob;
       $otp_data['otp_code']    = $otp_code;
       $otp_data['otp_status']  = ACTIVE_STATUS;
       $otp_data['otp_crtd_dt'] = date('Y-m-d H:i:s');
       $otp_id = $this->home_model->insert('otp_transaction',$otp_data);
        //send OTP
      $otp_msg = "Hello from TSN ! Your One Time Password for account verification is ".$otp_code.". Please keep it confidential and do not share it with anyone.";
       $otp_send = $this->home_model->SendMessage($otp_msg,$otp_data['otp_mob']);
   return $otp_id;
  }
}
